"""Isolated experimental YouTube -> Codex draft jobs; never import automatically.

No API keys, browser cookies, browser automation, or user grammar storage is
handled by this module. yt-dlp and Codex are separate local child processes.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
import re
import shutil
from datetime import datetime
import subprocess
import sys
from pathlib import Path
from threading import Lock, Thread
from time import monotonic
from typing import Any

from v7_annotations import validate_v7

VIDEO_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
MAX_DRAFT_BYTES = 5_000_000
PROGRESS_PREFIX = "@@AUTO_PROGRESS@@"


class AutoGrammarManager:
    def __init__(self, application: Path, data_dir: Path):
        self.application = Path(application)
        self.outdir = Path(data_dir) / "auto_codex"
        self.lock = Lock()
        self.jobs: dict[str, dict[str, Any]] = {}

    def _check_video(self, vid: str) -> str:
        if not isinstance(vid, str) or not VIDEO_RE.fullmatch(vid):
            raise ValueError("Ongeldige YouTube-video-ID")
        return vid

    def _folder(self, vid: str) -> Path:
        return self.outdir / self._check_video(vid)

    def _draft_file(self, vid: str) -> Path:
        return self._folder(vid) / f"{vid}_codex_VOLLEDIG_NIET_GECONTROLEERD.json"

    def read_draft(self, vid: str) -> tuple[dict, str]:
        filename = self._draft_file(vid)
        if not filename.is_file() or filename.stat().st_size > MAX_DRAFT_BYTES:
            raise ValueError("Nog geen volledig gegenereerd concept voor deze video")
        data = filename.read_bytes()
        root = validate_v7(json.loads(data.decode("utf-8")))
        if root.get("source", {}).get("video_id") != vid:
            raise ValueError("Het concept hoort bij een andere video")
        digest = hashlib.sha256(data).hexdigest()
        return root, digest

    def _preview(self, vid: str) -> dict:
        try:
            root, digest = self.read_draft(vid)
        except (ValueError, OSError, KeyError, TypeError, json.JSONDecodeError):
            return {"available": False}
        segments = root["segments"]
        audit_file = self._folder(vid) / "genormaliseerde_zinnen.json"
        info = {}
        if audit_file.is_file():
            try:
                obj = json.loads(audit_file.read_text(encoding="utf-8"))
                info = obj.get("audit", {})
            except (ValueError, OSError, TypeError):
                pass
        return {"available": True, "hash": digest, "count": len(segments),
                "estimated_times": info.get("estimated_segments", 0),
                "warnings": (info.get("warnings", []) or [])[:12],
                "samples": [{"start": s["start"], "text": s["text"],
                             "nl_natural": s.get("nl_natural", "")}
                            for s in segments[:10]],
                "source_status": root.get("status", "")}

    def status(self, vid: str) -> dict:
        self._check_video(vid)
        with self.lock:
            state = copy.deepcopy(self.jobs.get(vid, {}))
        if not state:
            state = {"phase": "idle", "log": []}
        # A monotonic clock makes long Codex calls observable even when they
        # emit no output. This is a heartbeat of the server, not of Codex.
        if state.get("phase") == "running":
            now = monotonic()
            state["running_seconds"] = max(0, int(now-state.get("started_at", now)))
            state["quiet_seconds"] = max(0, int(now-state.get("last_output_at", now)))
        state["draft"] = self._preview(vid)
        state["video_id"] = vid
        state["has_vtt"] = (self._folder(vid) / (vid + ".ru.vtt")).is_file()
        state["has_preview"] = (self._folder(vid) / "zinnenoverzicht.md").is_file()
        return state

    def read_full_log(self, vid: str) -> str:
        """Read the local run log (including lines no longer visible in status).

        Limit read size for stability, and omit internal machine progress events.
        Do not include rejected JSON files or Codex prompt contents.
        """
        logfile = self._folder(vid) / "integratie_laatste_run.log"
        try:
            with logfile.open("rb") as stream:
                stream.seek(0, os.SEEK_END)
                size = stream.tell()
                stream.seek(max(0, size - 512_000))
                content = stream.read().decode("utf-8", errors="replace")
        except FileNotFoundError:
            return "Nog geen verwerkingslog voor deze video."
        if size > 512_000:
            content = "[Begin van de log ingekort — laatste 512 KB]\n" + content.split("\n", 1)[-1]
        return "\n".join(line for line in content.splitlines()
                         if not line.startswith(PROGRESS_PREFIX))

    def start(self, vid: str, *, mode: str, title: str, refresh: bool = False,
              retry: bool = False) -> None:
        self._check_video(vid)
        if mode not in ("prepare", "run"):
            raise ValueError("Ongeldige actie voor automatisch grammatica genereren")
        if not isinstance(refresh, bool):
            raise ValueError("Ongeldige vernieuw-optie")
        if not isinstance(retry, bool) or (retry and mode != "run"):
            raise ValueError("Ongeldige optie om Codex opnieuw te analyseren")
        with self.lock:
            if any(j.get("phase") == "running" for j in self.jobs.values()):
                raise ValueError("Er is al een automatische verwerking bezig. Hervat na afloop.")
            job = {"phase": "running", "mode": mode,
                   "progress": {"stage": "starting", "completed": 0, "total": 0,
                                "current": 0, "cached": 0},
                   "log": ["Gestart: " + ("transcript ophalen" if mode == "prepare" else "volledige Codex-analyse")],
                   "started_at": monotonic(), "last_output_at": monotonic(),
                   "error": ""}
            self.jobs[vid] = job
        thread = Thread(target=self._worker, args=(vid, mode, title, refresh, retry), daemon=True)
        thread.start()

    def _worker(self, vid: str, mode: str, title: str, refresh: bool,
                retry: bool = False) -> None:
        cmd = [sys.executable, "-u", str(self.application / "auto_grammar_cli.py"),
               "--prepare" if mode == "prepare" else "--run",
               "--url", f"https://www.youtube.com/watch?v={vid}",
               "--title", title.strip()[:160] or f"YouTube-video {vid}",
               "--output-dir", str(self.outdir)]
        if refresh:
            cmd.append("--refresh")
        if retry and mode == "run":
            cmd.append("--retry")
        outfolder = self._folder(vid)
        outfolder.mkdir(parents=True, exist_ok=True)
        log_file = outfolder / "integratie_laatste_run.log"
        try:
            if retry:
                # Forced re-analysis can replace prior batch hashes and drafts.
                # Store an independent snapshot before launching any subprocess.
                archive = outfolder / "backup_runs" / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
                archive.mkdir(parents=True, exist_ok=False)
                for old_file in (self._draft_file(vid), outfolder / "rapport.md"):
                    if old_file.is_file():
                        shutil.copy2(old_file, archive / old_file.name)
                batch_dir = outfolder / "codex_batches"
                if batch_dir.is_dir():
                    shutil.copytree(batch_dir, archive / "codex_batches")
            env = os.environ.copy()
            env["PYTHONUNBUFFERED"] = "1"
            # No shell and no stdout echoed to the network; only a short status tail.
            with log_file.open("w", encoding="utf-8") as log:
                proc = subprocess.Popen(cmd, cwd=self.application, env=env,
                                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                        text=True, encoding="utf-8", errors="replace", bufsize=1)
                assert proc.stdout is not None
                for line in proc.stdout:
                    line = line.rstrip("\n")
                    log.write(line + "\n")
                    log.flush()
                    with self.lock:
                        self.jobs[vid]["last_output_at"] = monotonic()
                    if line.startswith(PROGRESS_PREFIX):
                        try:
                            event = json.loads(line[len(PROGRESS_PREFIX):])
                            if not isinstance(event, dict):
                                raise ValueError("Ongeldig voortgangsbericht")
                            stage = event.get("stage")
                            if stage not in {"prepared", "batches_ready", "parallel_ready", "batch_started",
                                             "batch_completed", "batch_failed", "repairing", "finalizing", "done"}:
                                raise ValueError("Onbekende voortgangsstap")
                            for key in ("completed", "total", "current", "cached"):
                                val = event.get(key, 0)
                                if not isinstance(val, int) or isinstance(val, bool) or val < 0:
                                    raise ValueError("Ongeldig voortgangsaantal")
                            if event.get("completed", 0) > event.get("total", 0) and event.get("total", 0):
                                raise ValueError("Voltooid groter dan totaal")
                            with self.lock:
                                self.jobs[vid]["progress"] = event
                            continue
                        except (json.JSONDecodeError, ValueError, TypeError):
                            # Keep unexpected output visible for diagnostics.
                            pass
                    with self.lock:
                        self.jobs[vid]["log"].append(line[-320:])
                        self.jobs[vid]["log"] = self.jobs[vid]["log"][-24:]
                code = proc.wait()
            if code:
                with self.lock:
                    self.jobs[vid]["phase"] = "error"
                    self.jobs[vid]["error"] = ("Genereren onderbroken; reeds opgeslagen Codex-batches "
                                                  "blijven bruikbaar. Klik opnieuw op Start / hervat.")
                return
            if mode == "run":
                # The full draft must exist and pass the actual player validator.
                self.read_draft(vid)
            with self.lock:
                self.jobs[vid]["phase"] = "ready" if mode == "run" else "prepared"
        except Exception as exc:
            with self.lock:
                self.jobs[vid]["phase"] = "error"
                self.jobs[vid]["error"] = f"{type(exc).__name__}: {exc}"

    def import_confirmed(self, vid: str, expected_hash: str, *, overwrite: bool,
                         currently_selected: str, target: Path) -> dict:
        self._check_video(vid)
        if vid != currently_selected:
            raise ValueError("Geselecteerde video is tussentijds gewijzigd")
        if not isinstance(expected_hash, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_hash):
            raise ValueError("Ongeldige conceptcontrole; open de voorbeeldweergave opnieuw")
        if not isinstance(overwrite, bool):
            raise ValueError("Bevestiging ontbreekt")
        with self.lock:
            job = self.jobs.get(vid, {})
            if job.get("phase") == "running":
                raise ValueError("Wacht tot Codex is gestopt voordat je importeert")
        root, actual_hash = self.read_draft(vid)
        if actual_hash != expected_hash:
            raise ValueError("Het concept is inmiddels veranderd. Bekijk het opnieuw voordat je importeert")
        if target.exists() and not overwrite:
            raise ValueError("Er bestaat al grammatica. Bevestig expliciet dat je die wilt vervangen")
        root = copy.deepcopy(root)
        # Older standalone v1.1 batches can have mixed feature codes. Normalize
        # the import copy without altering the user's saved Codex draft/cache.
        from auto_grammar_cli import normalize_codex_segment
        for seg in root["segments"]:
            for word in seg.get("words", []):
                word.setdefault("features", {})
        root["segments"] = [normalize_codex_segment(seg) for seg in root["segments"]]
        validate_v7(root)
        root.setdefault("source", {})["video_id"] = vid
        root["status"] = "Codex-concept — geïmporteerd na handmatige bevestiging; inhoudelijk niet gegarandeerd"
        target.parent.mkdir(parents=True, exist_ok=True)
        # Preserve the old reviewed transcript before replacing it.
        if target.exists():
            import datetime
            import shutil
            stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            shutil.copy2(target, target.with_name(f"{vid}.backup-{stamp}.json"))
        temporary = target.with_suffix(".tmp")
        temporary.write_text(json.dumps(root, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(target)
        return root
