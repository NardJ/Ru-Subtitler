"""Word-by-word Russian→Dutch annotation using local Ollama or OpenAI.

The optional Ollama backend runs locally, without an API key.
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Any

MAX_ARROWS = 12

SYSTEM_PROMPT = """Je maakt INTERLINEAIRE Russische taalleerondertitels, GEEN natuurlijke Nederlandse vertaling.
Geef uitsluitend één geldig JSON-object met sleutel 'sentences', een lijst. Bij elke aangeleverde zin:
- behoud exact dezelfde id;
- geef 'nl': exact één korte, zo letterlijk mogelijke Nederlandse betekenis per RUSSISCH token,
  in EXACT DEZELFDE VOLGORDE als de lijst 'tokens'. Geen extra 'een', 'de', 'haar', enz.
  Voeg geen nieuwe tokens toe. Als 1 woord omschreven moet worden, mag die cel meerdere Nederlandse woorden bevatten.
- geef 'endings': lijst van {"i": index, "suffix": "..."} alleen voor opzichtige verbuigingen
  ten opzichte van de Russische woordenboekvorm (bij zelfstandige/bijvoeglijke naamwoorden,
  voornaamwoorden) of vrouwelijke verleden tijd werkwoord -а. 'suffix' is het VERANDERDE,
  aan het einde geschreven deel van het originele token: voor младшему → ему, магазине → е,
  книгу → у, новую → ую, дала → а. Geef nooit gehele woord als suffix.
- geef 'arrows': lijst {"from": index, "to": index, "label": "...", "side": "top"}.
  Pijlen alleen als een ander woord een aantoonbare grammaticale vormeigenschap van het DOEL
  bepaalt. Voorbeelden: мама → vrouwelijke verleden tijd -а in дала ('F'), брату → младшему
  ('D'), в → магазинЕ ('P'), книгу → новую ('F,A'), чашку → чая ('G') als genitief
  van hoeveelheid / inhoud. Bij onderwerp→werkwoord alleen voor geslachts-/getalsovereenkomst.
  Geen pijlen van het werkwoord naar voorwerpen of ontvangers wegens selectie van A/D;
  behalve als de gebruiker expliciet andere constructies wil. Het DOEL moet een suffix hebben.
  Gebruik labels N, G, D, A, I, P (naamvallen), F/M (geslacht) en PL (meervoud),
  met komma bij meerdere eigenschappen. Alle labels kort houden.
- geef 'tags': lijst {"i": index, "label":"N|G|D|A|I|P"} voor duidelijke
  naamvallen op zelfstandige naamwoorden (niet op werkwoorden).
- indien onduidelijk, laat pijl/uitgang weg, geen analyse verzinnen.
Maak een grammaticale analyse van de EXACT aangeleverde tokens. Verander ze niet, voeg ze niet samen en splits ze niet.
Maak GEEN grammaticale pijlen enkel omdat een zelfstandig naamwoord een argument is van een werkwoord.
Als een Russische persoonsvorm een vrouwelijke verledentijduitgang -а heeft, markeer die als een overeenstemming met een vrouwelijk onderwerp.
Vertaal ALLE Russische tokens, ook voorzetsels, zonder Nederlandse lidwoorden in te voegen.
Kies korte zinsdelen en wees extra zorgvuldig bij identieke naamvalsvormen.
Elk element moet exact id, nl, endings, arrows en tags bevatten.
"""


def empty_annotation(s: dict, note: str = "") -> dict:
    """Never pretend unprocessed captions have a Dutch translation."""
    return {**s, "nl": ["·"] * len(s["tokens"]), "endings": [],
            "arrows": [], "tags": [], "pending": True, "note": note}


def sanitize_annotation(source: dict, response: dict) -> dict:
    """Enforce token alignment and physically valid arrow/underline targets."""
    tokens = source["tokens"]
    n = len(tokens)
    nl = response.get("nl", [])
    if not isinstance(nl, list) or len(nl) != n or any(not isinstance(t, str) for t in nl):
        raise ValueError(f"Vertaling voor zin {source['id']} heeft niet {n} woordcellen")

    endings = []
    changed: set[int] = set()
    for item in response.get("endings", []):
        if not isinstance(item, dict):
            continue
        i, suffix = item.get("i"), item.get("suffix")
        if (isinstance(i, int) and not isinstance(i, bool) and 0 <= i < n
                and isinstance(suffix, str) and suffix and tokens[i].lower().endswith(suffix.lower())
                and len(suffix) < len(tokens[i])):
            if i not in changed:
                endings.append({"i": i, "suffix": suffix})
                changed.add(i)

    arrows = []
    for item in response.get("arrows", []):
        if not isinstance(item, dict):
            continue
        a, b = item.get("from"), item.get("to")
        label = str(item.get("label", "")).upper()[:12]
        side = item.get("side", "top")
        if (isinstance(a, int) and not isinstance(a, bool) and isinstance(b, int)
                and not isinstance(b, bool) and 0 <= a < n and 0 <= b < n and a != b
                and b in changed and label and len(arrows) < MAX_ARROWS):
            arrows.append({"from": a, "to": b, "label": label,
                           "side": side if side in ("top", "bottom") else "top"})

    tags = []
    for item in response.get("tags", []):
        if not isinstance(item, dict):
            continue
        i, label = item.get("i"), str(item.get("label", "")).upper()
        if isinstance(i, int) and not isinstance(i, bool) and 0 <= i < n and label in ("N", "G", "D", "A", "I", "P"):
            tags.append({"i": i, "label": label})
    return {**source, "nl": [x.strip() or "·" for x in nl],
            "endings": endings, "arrows": arrows, "tags": tags, "pending": False}


def annotate_batch(segments: list[dict], api_key: str, model: str = "gpt-4.1-mini") -> list[dict]:
    from openai import OpenAI

    api = OpenAI(api_key=api_key, timeout=90, max_retries=2)
    payload = [{"id": s["id"], "text": s["text"], "tokens": s["tokens"]}
               for s in segments]
    response = api.chat.completions.create(
        model=model,
        temperature=0,
        response_format={"type": "json_object"},
        messages=[{"role": "system", "content": SYSTEM_PROMPT},
                  {"role": "user", "content": json.dumps({"sentences": payload}, ensure_ascii=False)}],
    )
    content = response.choices[0].message.content
    if not content:
        raise ValueError("Lege analyse van taalmodel")
    parsed: dict[str, Any] = json.loads(content)
    returned = {x.get("id"): x for x in parsed.get("sentences", []) if isinstance(x, dict)}
    return [sanitize_annotation(s, returned[s["id"]]) for s in segments]


# Ollama's local REST API is reachable only via loopback by default.
# Users must explicitly install and download a model. This app never downloads
# a model, silently switches to cloud processing or sends Google credentials.
DEFAULT_OLLAMA_URL = "http://127.0.0.1:11434"
DEFAULT_OLLAMA_MODEL = "qwen2.5:7b"


def available_ollama_models(base_url: str = DEFAULT_OLLAMA_URL) -> list[str]:
    """Return locally installed Ollama models; don't trigger a model download."""
    base = base_url.rstrip("/")
    if base not in ("http://127.0.0.1:11434", "http://localhost:11434",
                    "http://[::1]:11434"):
        raise ValueError("Ollama-server moet lokaal zijn (127.0.0.1:11434)")
    with urllib.request.urlopen(base + "/api/tags", timeout=2) as response:
        payload = json.load(response)
    return [m["name"] for m in payload.get("models", []) if isinstance(m, dict) and isinstance(m.get("name"), str)]


def model_is_installed(model: str, names: list[str]) -> bool:
    """Ollama model names may omit the implicit :latest tag."""
    return model in names or model + ":latest" in names


def select_provider(provider: str = "auto", *, api_key: str = "",
                    ollama_model: str = DEFAULT_OLLAMA_MODEL,
                    ollama_url: str = DEFAULT_OLLAMA_URL) -> tuple[str, str]:
    """Select a backend and a clear, actionable Dutch status message."""
    if provider not in {"auto", "ollama", "openai", "off"}:
        raise ValueError("Onbekende backend")
    if provider == "off":
        return "off", "Alleen Russische ondertitels (--provider off)"
    if provider in ("auto", "ollama"):
        try:
            models = available_ollama_models(ollama_url)
            if model_is_installed(ollama_model, models):
                return "ollama", f"Lokale analyse via Ollama ({ollama_model})"
            error = f"Ollama-model ontbreekt. Voer uit: ollama pull {ollama_model}"
        except (OSError, TimeoutError, ValueError, json.JSONDecodeError) as exc:
            error = f"Ollama niet bereikbaar ({type(exc).__name__}). Installeer/start Ollama en voer uit: ollama pull {ollama_model}"
        if provider == "ollama":
            return "off", error
    if api_key and provider in ("auto", "openai"):
        return "openai", "Analyse via OpenAI API"
    if provider == "openai":
        return "off", "OPENAI_API_KEY ontbreekt; voer een geldige API-sleutel in"
    return "off", f"Geen NL/grammatica: {error} (of stel OPENAI_API_KEY in)"


def annotate_batch_ollama(segments: list[dict], model: str = DEFAULT_OLLAMA_MODEL,
                          base_url: str = DEFAULT_OLLAMA_URL, timeout: int = 240) -> list[dict]:
    """Generate word-aligned Dutch annotations with locally running Ollama."""
    # Validate URL once: avoid arbitrary remote requests with full transcripts.
    if base_url.rstrip("/") not in ("http://127.0.0.1:11434",
                                   "http://localhost:11434", "http://[::1]:11434"):
        raise ValueError("Alleen lokale Ollama-server ondersteund")
    payload = [{"id": s["id"], "text": s["text"], "tokens": s["tokens"]} for s in segments]
    query = {
        "model": model, "stream": False, "format": "json",
        "system": SYSTEM_PROMPT,
        "prompt": "Antwoord met uitsluitend een JSON-object. Analyseer:\n" +
                  json.dumps({"sentences": payload}, ensure_ascii=False),
        "options": {"temperature": 0, "num_predict": 2400},
    }
    request = urllib.request.Request(
        base_url.rstrip("/") + "/api/generate",
        data=json.dumps(query, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(request, timeout=timeout) as response:
        result = json.load(response)
    content = result.get("response")
    if not isinstance(content, str) or not content.strip():
        raise ValueError("Geen tekst ontvangen van Ollama")
    parsed = json.loads(content)
    if not isinstance(parsed, dict):
        raise ValueError("Ollama heeft geen JSON-object teruggegeven")
    returned = {}
    for item in parsed.get("sentences", []):
        if not isinstance(item, dict):
            continue
        try:
            returned[int(item.get("id"))] = item
        except (ValueError, TypeError):
            continue
    return [sanitize_annotation(s, returned[s["id"]]) for s in segments]
