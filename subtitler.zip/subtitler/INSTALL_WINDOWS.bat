@echo off
cd /d "%~dp0"
echo Virtuele Python-omgeving installeren...
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m venv .venv
) else (
  python -m venv .venv
)
if errorlevel 1 (
 echo Kon .venv niet maken. Controleer Python installatie.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
 echo Installeren van Python pakketten mislukt.
 pause
 exit /b 1
)
echo Klaar! Dubbelklik START_WINDOWS.bat.
pause
