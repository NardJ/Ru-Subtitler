"""Controleer het complete bestand met voorbereide Russische v7-annotaties.

Gebruik:
  python controleer_russisch_v7.py [cache/grammar_v7/sF20z8jY1yU.json]

Vereist alleen de Python-standaardbibliotheek.
"""
from __future__ import annotations
import json
import sys
from pathlib import Path

CASES={'N','G','D','A','I','P'}


def check(filename: str) -> None:
    path=Path(filename)
    root=json.loads(path.read_text(encoding='utf-8'))
    assert root['schema_version']==7, 'schema_version is niet 7'
    assert isinstance(root['segments'],list) and root['segments'], 'Geen segmenten'
    assert len({s['id'] for s in root['segments']})==len(root['segments']), 'Dubbele segment-ids'
    relations_total=0
    shown_total=0
    for s in root['segments']:
        toks=s['tokens']
        n=len(toks)
        assert s['start']<s['end'], f"Ongeldige tijdcode in zin {s['id']}"
        assert len(s['nl'])==n, f"NL-cellen niet 1:1 in zin {s['id']}"
        assert len(s['words'])==n, f"Woordrecords niet 1:1 in zin {s['id']}"
        for i,w in enumerate(s['words']):
            assert w['i']==i, f"Onjuiste index bij {s['id']}:{i}"
            assert w['form']==toks[i], f"Afwijkend Russisch token bij {s['id']}:{i}"
            assert w['nl']==s['nl'][i], f"NL niet gelijk bij {s['id']}:{i}"
            assert w['lemma'] and w['pos'], f"Ontbrekende lemma/woordsoort bij {s['id']}:{i}"
            feats=w.get('features',{})
            assert feats.get('case') in CASES | {None}, f"Ongeldige naamval bij {s['id']}:{i}"
            infl=w.get('inflection',{})
            suffix=infl.get('surface_suffix')
            if suffix is not None:
                assert isinstance(suffix,str) and toks[i].lower().endswith(suffix.lower()), f"Uitgang past niet bij {s['id']}:{i}"
            elif infl:
                assert infl.get('type')=='zero_change', f"Lege uitgang zonder zero_change bij {s['id']}:{i}"
        rels=s['relations']
        ids={r['id'] for r in rels}
        assert len(ids)==len(rels), f"Dubbele relationele ids in {s['id']}"
        for r in rels:
            assert isinstance(r['from'],int) and isinstance(r['to'],int),f"Geen index bij {s['id']}"
            assert 0<=r['from']<n and 0<=r['to']<n and r['from']!=r['to'], f"Ongeldige pijl in {s['id']}"
            assert r['label'] and r['explanation'], f"Leeg label/uitleg in {s['id']}"
            assert all(k in ids and k!=r['id'] for k in r.get('depends_on',[])), f"Onbekende afhankelijke relatie in {s['id']}"
            relations_total+=1
            shown_total+=int(r['show_by_default'])
        # Verifieer dat afhankelijkheidsrelaties geen cycli vormen.
        graph={r['id']:r.get('depends_on',[]) for r in rels}
        def visit(key, trail):
            assert key not in trail, f"Cyclische oorzaak in zin {s['id']}: {key}"
            for other in graph[key]:visit(other, trail|{key})
        for key in ids:visit(key,set())
    print(f"OK: {len(root['segments'])} zinnen, {sum(len(s['words']) for s in root['segments'])} woordanalyses, "
          f"{relations_total} relaties, waarvan {shown_total} standaard zichtbaar.")
    print('Opmerking: dit controleert de structuur; niet automatisch de Russische taalkundige juistheid.')

if __name__=='__main__':
    check(sys.argv[1] if len(sys.argv)>1 else str(Path(__file__).parent / 'cache' / 'grammar_v7' / 'sF20z8jY1yU.json'))
