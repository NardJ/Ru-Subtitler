/* v7.15 Russian → Dutch interlinear player. Backward compatible with v6.
   Handles manually reviewed word features, dependency links, and legacy grammar arrows.
   Loaded by local player or offline demo.
   No browser extension, cross-origin request, or DOM access from Python required. */
(() => {
  'use strict';
  if (window.top !== window || window.__russianOverlayInstalled) return;
  window.__russianOverlayInstalled = true;

  const CSS = `
    :host { all: initial; position: fixed; left: 6%; top: 62%; width: min(88vw, 1200px);
      z-index: 2147483647; color: #f7f9fd; font-family: Inter, system-ui, Arial, sans-serif;
      box-sizing: border-box; user-select: none; }
    :host([data-mode="dock"]) { position: relative; display:block; inset:auto;width:100%;
      height:100%;min-height:0;z-index:3; }
    :host([data-mode="dock"]) .shell { border-radius:0;box-shadow:none;border-inline:0;
      border-bottom:0;backdrop-filter:none;height:100%;display:flex;flex-direction:column; }
    :host([data-mode="dock"]) .drag { cursor: default; }
    /* Word explanations replace the diagram temporarily, not the video's space. */
    :host([data-mode="dock"]) .detail { position:absolute;top:0!important;bottom:32px!important;
      left:0;width:100%;max-height:none;height:auto;overflow:auto;border-radius:0;z-index:5; }
    *, *::before, *::after { box-sizing: border-box; }
    .shell { --panelAlpha: .76; --fontScale: 24px; border-radius: 15px;
      background: rgba(13,18,28,var(--panelAlpha)); color: #f7f9fd;
      border: 1px solid rgba(192,209,244,.3); box-shadow: 0 14px 40px rgba(0,0,0,.5);
      overflow: hidden; backdrop-filter: blur(8px); }
    .toolbar { display:flex; align-items:center; gap:6px; min-height: 32px; padding: 5px 9px; flex-wrap:wrap;
      background:rgba(17,26,40,.85); font: 12px/1.4 system-ui, sans-serif;
      flex-wrap:nowrap; overflow-x:auto; scrollbar-width:thin; }
    .drag { cursor:grab; flex:1 1 auto; min-width:92px; display:flex; align-items:center; gap:8px;
      font-weight:700; white-space:nowrap; }
    .drag:active { cursor: grabbing; }
    .status { font-size:11px; color:#a6bad9; overflow:hidden; text-overflow:ellipsis;
      max-width: 290px; white-space:nowrap; font-weight:400; }
    .toolbar button { border:1px solid #52657f; border-radius:6px; padding:2px 6px;
      background:#27364b; color:white; font: 12px system-ui; cursor:pointer; }
    .toolbar button.active { background:#446ca5; border-color:#8db6ff; }
    .toolbar button:hover { background:#405672; }
    .toolbar button:disabled { opacity:.45;cursor:not-allowed; }
    .toolbar label { white-space:nowrap; color:#bdcce1; }
    .toolbar select { border:1px solid #6682aa; border-radius:6px; padding:2px 5px;
      background:#27364b; color:#fff; font:12px system-ui; cursor:pointer;
      max-width:158px; flex:0 0 auto; }
    .toolbar select:focus-visible { outline:2px solid #a1c6ff; outline-offset:2px; }
    input[type=range] { width:70px; cursor:pointer; accent-color:#93b6ec; }
    /* The scaled diagram is laid out as one centered unit. Its word columns stay aligned. */
    .reading-row { display:flex; align-items:stretch; flex:1 1 auto; min-height:0; min-width:0; }
    .sentence-nav { flex:0 0 78px; min-width:0; cursor:pointer; border:0;
      border-inline:1px solid rgba(125,163,215,.24); border-radius:0;
      background:rgba(38,61,95,.42); color:#e1eeff;
      display:flex; flex-direction:column; align-items:center; justify-content:center;
      gap:4px; font:600 13px/1.25 system-ui,sans-serif; padding:6px 3px;
      z-index:4; }
    .sentence-nav .nav-icon { font-size:29px; line-height:1; }
    .sentence-nav:hover:not(:disabled),.sentence-nav:focus-visible {background:#355b8c;}
    .sentence-nav:focus-visible {outline:2px solid #a1c6ff;outline-offset:-3px;}
    .sentence-nav:disabled {opacity:.31;cursor:not-allowed;}
    .nav-sentence {background:rgba(53,91,142,.73);border-left:1px solid #6f99d2;}
    .nav-sentence:hover:not(:disabled){background:#4779ba;}
    @media (max-width:640px){.sentence-nav{flex-basis:49px;font-size:10px;}
      .sentence-nav .nav-icon{font-size:23px;}}
    .diagram-viewport { padding:0 10px; width:auto;min-width:0;flex:1 1 auto;overflow:hidden;
      display:flex;align-items:center;justify-content:center;cursor:pointer; }
    .diagram-viewport:focus-visible { outline:2px solid #9bbffd;outline-offset:-2px; }
    .stage-holder { position:relative;flex:0 0 auto;min-width:0;min-height:0; }
    :host([data-mode="dock"]) .diagram-viewport {height:auto!important;flex:1 1 auto;
      min-height:0;overflow:hidden; }
    .stage { position:absolute;top:0;left:0;height:90px;transform-origin:top left; }
    .words { position: absolute; top:0; left:0; display:flex; width:max-content; gap:18px; height:100%; }
    .word { flex-shrink:0; position:relative; display:flex; flex-direction:column; align-items:center;
      justify-content:flex-start; white-space:nowrap; font-family: 'DejaVu Sans', Arial, sans-serif;
      font-size: var(--fontScale); }
    .ru { position: relative; margin-top:var(--ruTop, 40px); color: #f6f8fb; line-height:1.28; }
    button.ru { display:block; appearance:none; border:0; background:none; font:inherit;
      color:inherit; padding:0; text-align:center; cursor:pointer; }
    button.ru:hover, button.ru:focus-visible { outline:2px solid #adcefa; outline-offset:5px;
      border-radius:3px; }
    .ru.is-v7 { color:#fff; }
    .suffix { border-bottom:3px solid #eab266; padding-bottom:1px; }
    .case { position:absolute; top:var(--caseTop, 75px); font:600 11px/1.2 ui-monospace, monospace;
      color:#b5c5d8; }
    .nl { position:absolute; top:var(--nlTop, 95px); color:#e1e7f0; line-height:1.24;
      font-size: calc(var(--fontScale) * .88); cursor:pointer; border-radius:3px; }
    .nl:hover, .nl:focus-visible { text-decoration:underline; text-decoration-color:#9cc7ff;
      text-underline-offset:4px;outline:2px solid #9bbffd;outline-offset:3px; }
    .diagram-svg { pointer-events:none; position:absolute; top:0; left:0;
      overflow:visible; z-index:2; }
    .diagram-svg path { stroke-linejoin:round; }
    .diagram-svg > path { fill:none; }
    .diagram-svg marker path { stroke:none; }

    .diagram-svg text { font:700 14px ui-monospace, monospace;
      paint-order:stroke fill; stroke:#151c27; stroke-width:4px; text-anchor:middle; }
    .empty { font:14px system-ui; color:#cad4e4; padding:22px 12px; }
    .detail { position:absolute; bottom:calc(100% + 6px); width:100%; z-index:3;
      border:1px solid #4a6588; border-radius:12px; padding:11px 15px 13px; background:rgba(9,15,27,.96);
      color:#d9e6f6;
      font:13px/1.5 system-ui,sans-serif; max-height:230px; overflow:auto; }
    .detail[hidden] { display:none; }
    .detail-head { display:flex; align-items:center; justify-content:space-between;
      gap:14px; margin-bottom:4px; }
    .detail-title { color:#fff; font-size:16px; font-weight:700; }
    .detail-close { color:white; border:1px solid #52657f; background:#293b56;
      border-radius:6px; padding:2px 8px; cursor:pointer; }
    .detail p { margin:5px 0; } .detail small {color:#afc6e4;}
    .detail .relation-detail {padding-top:5px; border-top:1px solid #30425a;}
    .detail h4 {font:700 13px system-ui,sans-serif;color:#d5e5fc;margin:12px 0 5px;}
    .detail .table-scroll {max-width:100%;overflow-x:auto;}
    .detail table {border-collapse:collapse;font:13px/1.35 system-ui,sans-serif;
      white-space:nowrap;min-width:265px;width:100%;margin-bottom:6px;}
    .detail th, .detail td {padding:4px 7px;text-align:left;border-bottom:1px solid #33455f;}
    .detail th {color:#accbf6;font-weight:600;}
    .detail tr.current-case {background:rgba(90,130,197,.27);}
    .detail tr.current-case th,.detail tr.current-case td {font-weight:700;color:#fff;}
    .detail .paradigm-note {font-size:11px;color:#aabfdf;}

    .legend, .foot { display:none; }
    .no-grammar .case,.no-grammar .diagram-svg { display:none; }
    .no-grammar .suffix { border-bottom: 0; padding:0; }
    .no-nl .nl { display:none; }
    .clock { color:#b5c6dd; font:11px ui-monospace,monospace; white-space:nowrap; }
    .closed .reading-row,.closed .diagram-viewport,.closed .foot,.closed .legend,.closed .detail { display:none; }
    .demo-label { color:#a9badd; font-size:11px; }
  `;
  const SVG_NS = 'http://www.w3.org/2000/svg';
  const settings = (() => {
    const defaults={size:24, alpha:.76, grammar:true, relationMode:'cases', dutch:true, x:6, y:34, mode:'dock'};
    try {
      const stored=JSON.parse(localStorage.getItem('ru-grammar-overlay-settings') || '{}');
      const result={...defaults, ...stored};
      result.mode=['dock','overlay'].includes(result.mode)?result.mode:'dock';
      result.relationMode=['cases','all'].includes(result.relationMode)?result.relationMode:'cases';
      return result;
    } catch (_) { return defaults; }
  })();
  let host, shadow, stage, stageHolder, words, svg, viewport, statusEl, positionEl, shell, clockEl, detailEl, replayButton, previousButton, nextButton, sentenceButton;
  let segments = [], version = 0, activeVideoId = null, currentSegment = -1, isCollapsed = false, isDragging = false;
  let currentData = null, lastLayoutMode = '';

  const save = () => {
    try { localStorage.setItem('ru-grammar-overlay-settings', JSON.stringify(settings)); } catch (_) {}
  };
  const node = (tag, className, text) => {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (text !== undefined) el.textContent = String(text);
    return el;
  };
  function getVideoTime() {
    if (typeof window.__roDemoTime === 'function') return window.__roDemoTime();
    const video = document.querySelector('video.html5-main-video') || document.querySelector('video');
    return video && Number.isFinite(video.currentTime) ? video.currentTime : -1;
  }
  function timeLabel(time) {
    if (time < 0) return '--:--';
    return String(Math.floor(time / 60)).padStart(2, '0') + ':' + String(Math.floor(time % 60)).padStart(2, '0');
  }
  function makeSVG(tag, attrs) {
    const el = document.createElementNS(SVG_NS, tag);
    for (const [key,value] of Object.entries(attrs || {})) el.setAttribute(key, value);
    return el;
  }
  function setParent() {
    if (!host) return;
    const dock = settings.mode === 'dock' && document.getElementById('subtitle-dock');
    // The parent owns fullscreen and allocates real, non-overlapping space for the subtitles.
    if (lastLayoutMode !== settings.mode) {
      if (typeof window.__roSetLayoutMode === 'function') window.__roSetLayoutMode(settings.mode);
      lastLayoutMode = settings.mode;
    }
    const fs = document.fullscreenElement;
    const newParent = dock || (fs && fs instanceof HTMLElement && fs.tagName !== 'VIDEO' ? fs : document.body);
    const mode = dock ? 'dock' : 'overlay';
    if (host.parentNode !== newParent || host.dataset.mode !== mode) {
      host.dataset.mode=mode;
      newParent.appendChild(host);
      host.style.position=mode==='dock' ? 'relative' : (newParent===document.body ? 'fixed' : 'absolute');
      host.style.left=mode==='dock' ? 'auto' : `${settings.x}%`;
      host.style.top=mode==='dock' ? 'auto' : `${settings.y}%`;
      host.style.width=mode==='dock' ? '100%' : '';
    }
  }
  function init() {
    if (host || !document.body) return;
    host = document.createElement('div');
    host.id = 'ru-grammar-overlay-host';
    shadow = host.attachShadow({mode:'open'});
    const style = node('style'); style.textContent = CSS; shadow.appendChild(style);
    shell = node('div','shell'); shadow.appendChild(shell);
    const toolbar = node('div','toolbar'); // Append below the grammar diagram.
    const handle = node('div','drag'); handle.title = 'Sleep om de ondertitels te verplaatsen';
    handle.appendChild(node('span','', '⠿ RU / NL'));
    statusEl = node('span','status','Transcript ophalen…'); handle.appendChild(statusEl);
    toolbar.appendChild(handle);
    function button(label, title, callback, active = false) {
      const b = node('button', active ? 'active' : '', label);
      b.title=title; b.addEventListener('click', () => {callback(b);save();});
      toolbar.appendChild(b); return b;
    }
    button(settings.mode==='dock'?'▣ Onder video':'▢ Over video',
      'Wissel tussen ondertitels onder de video en over het videobeeld',(b)=>{
        settings.mode = settings.mode==='dock'?'overlay':'dock';
        b.textContent = settings.mode==='dock'?'▣ Onder video':'▢ Over video';
        setParent();refreshCurrent();
      },settings.mode==='dock');
    button('−','Kleinere tekst',()=>{settings.size=Math.max(14,settings.size-2);refreshCurrent();});
    button('+','Grotere tekst',()=>{settings.size=Math.min(38,settings.size+2);refreshCurrent();});
    button('⇄ NL','Letterlijke vertaling aan/uit',(b)=>{
      settings.dutch=!settings.dutch; b.classList.toggle('active',settings.dutch);refreshCurrent();
    },settings.dutch);
    button('↗ Gram','Grammaticale pijlen aan/uit',(b)=>{
      settings.grammar=!settings.grammar;b.classList.toggle('active',settings.grammar);refreshCurrent();
    },settings.grammar);
    const relLabel=node('label','','Pijlen:');toolbar.appendChild(relLabel);
    const relSelect=node('select','relation-mode');
    relSelect.setAttribute('aria-label','Welke grammaticale verbanden tonen');
    relSelect.title='Naamvallen toont naamvalsregering en congruentie; Alle grammatica toont daarnaast ook onderwerp, werkwoorden, zinsbouw en betekenisrelaties.';
    for(const [value,text] of [['cases','Naamvallen'],['all','Alle grammatica']]){
      const option=node('option','',text);option.value=value;relSelect.appendChild(option);
    }
    relSelect.value=settings.relationMode;
    relSelect.addEventListener('change',()=>{
      settings.relationMode=relSelect.value;save();refreshCurrent();
    });
    toolbar.appendChild(relSelect);
    const label=node('label','','Achtergrond'); toolbar.appendChild(label);
    const input = node('input'); input.type='range'; input.min='10'; input.max='100';
    input.value=String(Math.round(settings.alpha*100)); input.title='Dekking van de achtergrond';
    input.addEventListener('input',()=>{settings.alpha=Number(input.value)/100;applySettings();save();});
    toolbar.appendChild(input);
    button('⇧ Transcript','Open het paneel voor handmatige transcriptinvoer',()=>{
      if(typeof window.__roTogglePanel==='function')window.__roTogglePanel('transcript');
      else if(statusEl)statusEl.textContent='Transcriptinvoer is alleen beschikbaar in de YouTube-speler.';
    });
    button('ⓘ Hulp','Bediening en informatie',()=>{
      if(typeof window.__roTogglePanel==='function')window.__roTogglePanel('help');
      else if(statusEl)statusEl.textContent='Gebruik de uitleg onder de offline demo.';
    });
    button('▁','Inklappen / uitklappen',()=>{isCollapsed=!isCollapsed;
      shell.classList.toggle('closed',isCollapsed);});

    const readingRow=node('div','reading-row');shell.appendChild(readingRow);
    function navigation(label, glyph, title, callback, className) {
      const b=node('button',`sentence-nav ${className}`);b.type='button';
      b.title=title;b.setAttribute('aria-label',label);
      b.appendChild(node('span','nav-icon',glyph));b.appendChild(node('span','',label));
      b.disabled=true;b.addEventListener('click',callback);return b;
    }
    previousButton=navigation('Vorige zin','⏮','Spring naar de vorige Russische zin',skipPreviousSentence,'nav-prev');
    replayButton=navigation('Herhaal','↺','Speel de huidige zin opnieuw vanaf de begintijd',replayCurrentSentence,'nav-replay');
    sentenceButton=navigation('Zin','ⓘ','Bekijk de Nederlandse zin en de Russische woordvolgorde',showSentenceDetail,'nav-sentence');
    nextButton=navigation('Volgende zin','⏭','Spring naar het begin van de volgende Russische zin',skipNextSentence,'nav-next');
    readingRow.appendChild(previousButton);
    readingRow.appendChild(replayButton);
    viewport=node('div','diagram-viewport');readingRow.appendChild(viewport);
    viewport.title='Klik op lege ruimte om de video te pauzeren of verder te spelen';
    viewport.tabIndex=0;
    viewport.setAttribute('aria-label','Pauzeer of hervat de video met een klik op de lege achtergrond');
    viewport.addEventListener('click',(event)=>{
      // The full Dutch translation row is clickable, including spaces between words.
      if(event.target.closest?.('button.ru'))return;
      const nlCell=settings.dutch && words?.querySelector('.nl');
      if(nlCell){
        const rect=nlCell.getBoundingClientRect();
        const range=stageHolder.getBoundingClientRect();
        if(rect.height>0 && event.clientY>=rect.top-3 && event.clientY<=rect.bottom+4
          && event.clientX>=range.left && event.clientX<=range.right){
          showSentenceDetail();return;
        }
      }
      if(typeof window.__roTogglePlayback==='function')window.__roTogglePlayback();
    });
    viewport.addEventListener('keydown',(event)=>{
      if(event.target!==viewport || ![' ','Enter'].includes(event.key))return;
      event.preventDefault();
      if(typeof window.__roTogglePlayback==='function')window.__roTogglePlayback();
    });
    readingRow.appendChild(sentenceButton);
    readingRow.appendChild(nextButton);
    stageHolder=node('div','stage-holder');viewport.appendChild(stageHolder);
    stage=node('div','stage');stageHolder.appendChild(stage);
    words=node('div','words');stage.appendChild(words);
    svg=makeSVG('svg',{class:'diagram-svg'});stage.appendChild(svg);
    detailEl=node('div','detail');detailEl.hidden=true;shadow.appendChild(detailEl);
    const legend=node('div','legend', 'Blauw: grammaticale regel · Paars gestreept: betekenis of constructie · Klik op een Russisch woord voor uitleg.');
    shell.appendChild(legend);
    const foot=node('div','foot');shell.appendChild(foot);
    foot.appendChild(node('span','', 'F vrouwelijk · M mannelijk · N nom. · G gen. · D dat. · A acc. · I instr. · P prep. · 3S/1S persoon enkelvoud'));
    clockEl = node('span','clock', '--:--');toolbar.appendChild(clockEl);
    shell.appendChild(toolbar); // Below the grammatical transcript in both modes.
    host.style.left=`${settings.x}%`;host.style.top=`${settings.y}%`;
    setParent();applySettings();

    handle.addEventListener('pointerdown', (ev)=>{
      if(ev.button!==0 || settings.mode==='dock') return;
      isDragging=true;ev.preventDefault();handle.setPointerCapture(ev.pointerId);
      const pr=(host.parentNode === document.body ? document.documentElement : host.parentNode).getBoundingClientRect();
      const rect=host.getBoundingClientRect();
      const offsetX=ev.clientX-rect.left,offsetY=ev.clientY-rect.top;
      const move=(e)=>{
        if(!isDragging) return;
        const left=Math.max(0,Math.min(pr.width-host.offsetWidth,e.clientX-pr.left-offsetX));
        const top=Math.max(0,Math.min(pr.height-host.offsetHeight,e.clientY-pr.top-offsetY));
        settings.x=left/pr.width*100;settings.y=top/pr.height*100;
        host.style.left=`${settings.x}%`;host.style.top=`${settings.y}%`;
      };
      handle.addEventListener('pointermove',move);
      handle.addEventListener('pointerup',()=>{
        isDragging=false;handle.removeEventListener('pointermove',move);save();
      },{once:true});
    });
    document.addEventListener('fullscreenchange',()=>{setParent();refreshCurrent();});
    window.addEventListener('resize',()=>{fit();});
  }
  function applySettings() {
    if (!shell) return;
    shell.style.setProperty('--panelAlpha',String(settings.alpha));
    shell.style.setProperty('--fontScale',`${settings.size}px`);
    shell.classList.toggle('no-grammar',!settings.grammar);
    shell.classList.toggle('no-nl',!settings.dutch);
  }
  const caseWords = {N:'nominatief',G:'genitief',D:'datief',A:'accusatief',
    I:'instrumentalis',P:'prepositioneel'};
  const featureWords = {F:'vrouwelijk',M:'mannelijk',N:'onzijdig',
    SG:'enkelvoud',PL:'meervoud',PRES:'tegenwoordige tijd',PAST:'verleden tijd',
    IMPERFECTIVE:'onvoltooid aspect',PERFECTIVE:'voltooid aspect',
    ANIMATE:'levend',INANIMATE:'levenloos'};
  function grammaticalLabel(word){
    const f=word?.features||{};
    const out=[];
    if(['NOUN','PRON','ADJ','DET'].includes(word?.pos)){
      if(f.gender && word?.pos!=='NOUN')out.push(f.gender);
      if(f.case)out.push(f.case);
    }
    return out.join(',');
  }
  function relationSemantic(r){
    return ['semantic_context','verb_preposition_frame','semantic_role',
      'existential_possession','location_question'].includes(r.type);
  }
  // v7.15: the display mode, not a Codex-generated boolean, chooses the links.
  // In particular, an explicit subject → verb relationship must be visible in 'all'.
  function relationVisibleForMode(r, mode){
    if(mode==='all')return true;
    return ['case_government','agreement','preposition_case',
      'adjective_noun_agreement'].includes(r.type);
  }
  function relationDiagramLabel(r){
    const raw=String(r.label||'');
    if(r.type==='subject_verb_agreement'){
      if(/(?:meervoud|plural|\bPL\b)/i.test(raw))return 'onderw. → mv.';
      if(/(?:enkelvoud|singular|\bSG\b|\b3S\b)/i.test(raw))return 'onderw. → ev.';
      return 'onderwerp → ww';
    }
    // The unabridged label and explanation remain available in the word detail.
    if(raw.length>31)return raw.slice(0,28).trimEnd()+'…';
    return raw;
  }
  function sentenceLabel(s){
    return (s.words?.length ? 'v7 · uitgebreide uitleg' : 'v6 · basispijlen');
  }
  function showDetail(content){
    // In the YouTube player, put every grammatical explanation in a consistent
    // video-centered dialog. The old shadow DOM detail remains for offline demos.
    if(typeof window.__roShowGrammarDetail==='function'){
      detailEl.hidden=true;
      if(window.__roShowGrammarDetail(content))return;
    }
    if(!detailEl)return;
    detailEl.replaceChildren();
    const header=node('div','detail-head');
    header.appendChild(node('span','detail-title',content.title));
    const close=node('button','detail-close','Sluiten');
    close.type='button';close.addEventListener('click',()=>{detailEl.hidden=true;});
    header.appendChild(close);detailEl.appendChild(header);
    for(const p of content.paragraphs){
      if(!p)continue;
      const el=node('p',p.kind==='relation'?'relation-detail':'',p.text);
      detailEl.appendChild(el);
    }
    for(const table of content.tables||[]){
      detailEl.appendChild(node('h4','',table.title));
      const scroller=node('div','table-scroll');
      const element=node('table');
      const head=node('thead'); const headrow=node('tr');
      for(const col of table.columns)headrow.appendChild(node('th','',col));
      head.appendChild(headrow);element.appendChild(head);
      const tbody=node('tbody');
      table.rows.forEach((values,rowIndex)=>{
        const row=node('tr', rowIndex===table.activeRow?'current-case':'');
        values.forEach((value,index)=>row.appendChild(node(index===0?'th':'td','',value)));
        tbody.appendChild(row);
      });
      element.appendChild(tbody);scroller.appendChild(element);detailEl.appendChild(scroller);
      if(table.note)detailEl.appendChild(node('p','paradigm-note',table.note));
    }
    detailEl.hidden=false;
    if(settings.mode==='dock'){
      detailEl.style.bottom='auto'; detailEl.style.top='auto';
      return;
    }
    const above=host.getBoundingClientRect().top > Math.min(235,window.innerHeight*.35);
    detailEl.style.bottom=above?'calc(100% + 6px)':'auto';
    detailEl.style.top=above?'auto':'calc(100% + 6px)';
  }
  function showSentenceDetail(){
    if(!currentData)return;
    const s=currentData;
    // Keep navigation/help instructions in the Hulp panel, not the Zin explanation.
    // Also hide stale boilerplate from already-imported earlier v7 JSON files.
    const note=(s.sentence_note||'').trim();
    const isBoilerplate=note.startsWith('Naamval, verbuiging en de relatie tussen onderwerp')
      || note.startsWith('Klik op een Russisch woord');
    showDetail({title:s.text||'Zinsverklaring',paragraphs:[
      {text:s.nl_natural?`Nederlandse zin: ${s.nl_natural}`:''},
      {text:s.word_order_note?`Waarom deze Russische woordvolgorde? ${s.word_order_note}`:''},
      {text:isBoilerplate?'':note}
    ]});
  }
  const caseCodes=['N','G','D','A','I','P'];
  const comparisonNouns={
    M:['стол','стола','столу','стол','столом','столе'],
    F:['комната','комнаты','комнате','комнату','комнатой','комнате'],
    N:['окно','окна','окну','окно','окном','окне']
  };
  function declensionTables(w){
    const paradigm=w.paradigm;
    if(!paradigm)return [];
    const active=caseCodes.indexOf(w.features?.case);
    const tables=[];
    if(paradigm.kind==='noun'||paradigm.kind==='pronoun'){
      tables.push({title:`NGDAIP — ${w.lemma} (${paradigm.scope||'enkelvoud'})`,
        columns:['Naamval',w.lemma],activeRow:active,
        rows:caseCodes.map(c=>[`${c} · ${caseWords[c]}`,paradigm.forms?.[c]||'—']),
        note:paradigm.kind==='pronoun'?'Na sommige voorzetsels verschijnt bij hij/zij de n- (него, ней, нём).':''});
      if(paradigm.kind==='noun'){
        tables.push({title:'M/V/O — vergelijking zelfstandige naamwoorden',
          columns:['Naamval','M · стол','V · комната','O · окно'],activeRow:active,
          rows:caseCodes.map((c,i)=>[c,comparisonNouns.M[i],comparisonNouns.F[i],comparisonNouns.N[i]]),
          note:'Dit zijn drie verschillende zelfstandige naamwoorden. Стол blijft mannelijk; zelfstandige naamwoorden veranderen niet van geslacht. Voorbeeldvormen zijn enkelvoud.'});
      }
    } else if(paradigm.kind==='agreement'){
      tables.push({title:'NGDAIP × M/V/O — bijvoeglijk/bezittelijk woord (enkelvoud)',
        columns:['Naamval','M','V','O'],activeRow:active,
        rows:caseCodes.map((c,i)=>[c,paradigm.rows?.[i]?.M||'—',paradigm.rows?.[i]?.F||'—',paradigm.rows?.[i]?.N||'—']),
        note:'Bij mannelijk accusatief geeft de schuine streep levenloos / levend aan. Deze woorden passen zich aan het zelfstandig naamwoord aan.'});
    }
    return tables;
  }
  function showWordDetail(index){
    const s=currentData, w=s?.words?.[index];
    if(!w){
      showBasicWordDetail(index);
      return;
    }
    const f=w.features||{}, infl=w.inflection||{};
    const features=[];
    if(f.gender)features.push(`geslacht: ${featureWords[f.gender]||f.gender}`);
    if(f.number)features.push(`getal: ${featureWords[f.number]||f.number}`);
    if(f.case)features.push(`naamval: ${caseWords[f.case]||f.case} (${f.case})`);
    if(f.person)features.push(`persoon: ${f.person}`);
    if(f.tense)features.push(featureWords[f.tense]||f.tense);
    if(f.aspect)features.push(featureWords[f.aspect]||f.aspect);
    if(f.governs_case)features.push(`kan naamval regeren: ${f.governs_case.join('/')}`);
    const paragraphs=[
      {text:`Woordenboekvorm: ${w.lemma} · Nederlands: ${w.nl}`},
      {text:[w.role?`Rol: ${w.role}`:'',features.join(' · ')].filter(Boolean).join(' · ')},
      {text:infl.pattern?`Vormverandering: ${infl.pattern}`:infl.type==='zero_change'?'Geen zichtbare vormverandering bij deze naamval.':''},
      {text:infl.explanation||''},
      {text:w.explanation||''}
    ];
    const rels=s.relations||[];
    for(const r of rels){
      if(r.to!==index && r.from!==index)continue;
      const from=s.tokens[r.from], to=s.tokens[r.to];
      const deps=(r.depends_on||[]).map(id=>rels.find(x=>x.id===id))
        .filter(Boolean).map(x=>`${s.tokens[x.from]} → ${s.tokens[x.to]} (${x.label})`);
      paragraphs.push({kind:'relation',text:`${from} → ${to} (${r.label}): ${r.explanation}` +
        (deps.length?` · Oorzaak: ${deps.join('; ')}`:'')});
    }
    showDetail({title:w.form,paragraphs,tables:declensionTables(w)});
  }
  function showBasicWordDetail(index){
    const s=currentData;
    if(!s || index<0 || index>=s.tokens.length)return;
    const tags=(s.tags||[]).filter(t=>t.i===index).map(t=>t.label);
    const suffix=(s.endings||[]).find(e=>e.i===index)?.suffix;
    const paragraphs=[
      {text:`Letterlijke Nederlandse vertaling: ${s.nl?.[index]||'nog niet beschikbaar'}`},
      {text:tags.length ? `Beschikbare naamvalsaanduiding: ${tags.map(x=>caseWords[x]||x).join(', ')} (${tags.join(', ')})` : ''},
      {text:suffix ? `Gemarkeerde woorduitgang: ${suffix}` : ''}
    ];
    for(const a of (s.arrows||[])){
      if(a.to!==index && a.from!==index)continue;
      const label=caseWords[a.label] ? `${caseWords[a.label]} (${a.label})` : a.label;
      paragraphs.push({kind:'relation',text:`Pijl: ${s.tokens[a.from]} → ${s.tokens[a.to]} (${label}).`});
    }
    paragraphs.push({text:'Dit is basisinformatie uit de bestaande ondertitels. Een uitgebreide verklaring, woordenboekvorm en verbuiging zijn voor dit woord nog niet afzonderlijk uitgewerkt.'});
    showDetail({title:s.tokens[index],paragraphs});
  }
  function jumpToSentence(segment){
    if(!segment || !Number.isFinite(Number(segment.start)))return;
    const seek=window.__roSeekSentence || window.__roReplaySentence;
    if(typeof seek === 'function'){
      try { seek(segment.start); }
      catch(err){ if(statusEl)statusEl.textContent=`Springen mislukt: ${err.message||err}`; }
    } else if(statusEl){
      statusEl.textContent='Springen is niet beschikbaar voor deze speler.';
    }
  }
  function replayCurrentSentence(){
    const index=findSegment(getVideoTime());
    if(index>=0) jumpToSentence(segments[index]);
  }
  function nextSentenceIndex(t){
    // Works in transcript gaps as well as during a sentence.
    return segments.findIndex(s=>Number(s.start)>t+0.02);
  }
  function previousSentenceIndex(t){
    const current=findSegment(t);
    if(current>=0)return current-1;
    for(let i=segments.length-1;i>=0;i--){
      if(Number(segments[i].start)<t-0.02)return i;
    }
    return -1;
  }
  function skipPreviousSentence(){
    const previous=previousSentenceIndex(getVideoTime());
    if(previous>=0)jumpToSentence(segments[previous]);
  }
  function skipNextSentence(){
    const next=nextSentenceIndex(getVideoTime());
    if(next>=0)jumpToSentence(segments[next]);
  }
  function renderSegment(s) {
    if(!stage) return;
    currentData=s;
    detailEl.hidden=true;
    if(typeof window.__roCloseGrammarDetail==='function')window.__roCloseGrammarDetail();
    words.replaceChildren();svg.replaceChildren();
    applySettings();
    const tokenEls=[];
    const measure=document.createElement('canvas').getContext('2d');
    const highlights=new Map((s.endings||[]).map(x=>[x.i,x.suffix]));
    const tags=new Map((s.tags||[]).map(x=>[x.i,x.label]));
    if(Array.isArray(s.words))for(const w of s.words){
      const suffix=w.inflection?.surface_suffix;
      if(suffix)highlights.set(w.i,suffix);
      const tag=grammaticalLabel(w);
      if(tag)tags.set(w.i,tag);
    }
    for(let i=0;i<s.tokens.length;i++){
      const cell=node('div','word');
      // Reserve the wider RU/NL word so the Dutch stays under the Russian token.
      if(measure){
        measure.font=`${settings.size}px Arial, sans-serif`;
        const ruWidth=measure.measureText(s.tokens[i]).width;
        measure.font=`${settings.size*.88}px Arial, sans-serif`;
        const nlWidth=measure.measureText(s.nl && s.nl[i] || '·').width;
        cell.style.minWidth=`${Math.ceil(Math.max(ruWidth,nlWidth)+12)}px`;
      }
      const isV7=Boolean(s.words?.[i]);
      const russian=node('button',isV7?'ru is-v7':'ru');
      russian.type='button';
      russian.title=isV7?`Grammaticale uitleg: ${s.tokens[i]}`:`Basisinformatie: ${s.tokens[i]}`;
      russian.setAttribute('aria-label',`Uitleg over ${s.tokens[i]}`);
      russian.addEventListener('click',(event)=>{event.stopPropagation();showWordDetail(i);});
      const value=s.tokens[i],suffix=highlights.get(i);
      let marker=null;
      if(suffix && value.toLowerCase().endsWith(suffix.toLowerCase()) && suffix.length<=value.length){
        russian.appendChild(document.createTextNode(value.slice(0,-suffix.length)));
        marker=node('span','suffix',value.slice(-suffix.length));
        russian.appendChild(marker);
      } else russian.textContent=value;
      cell.appendChild(russian);
      if(tags.has(i))cell.appendChild(node('span','case',tags.get(i)));
      const dutch=node('div','nl',s.nl && s.nl[i] || '·');
      dutch.title='Klik voor uitleg van de hele zin';
      dutch.tabIndex=0;
      dutch.setAttribute('role','button');
      dutch.setAttribute('aria-label','Zinsuitleg tonen');
      dutch.addEventListener('click',(event)=>{event.stopPropagation();showSentenceDetail();});
      dutch.addEventListener('keydown',(event)=>{
        if(!['Enter',' '].includes(event.key))return;
        event.preventDefault();event.stopPropagation();showSentenceDetail();
      });
      cell.appendChild(dutch);
      words.appendChild(cell);
      tokenEls.push({cell,russian,marker});
    }
    const arrows=Array.isArray(s.relations)
      ? s.relations.filter(r=>relationVisibleForMode(r,settings.relationMode)).map(r=>({
          from:r.from,to:r.to,label:relationDiagramLabel(r),
          kind:relationSemantic(r)?'semantic':'grammar',
          side:r.type==='case_government'||r.type==='preposition_case'?'bottom':'top',
          tooltip:`${r.label||''}: ${r.explanation||''}`
        })) : (s.arrows||[]).map(a=>({...a,kind:'grammar'}));
    const usedArrows=settings.grammar ? arrows : [];
    // The same case is not printed twice: an A/I/etc on an incoming arrow
    // replaces that part of the small label underneath its destination.
    const shownLabels=new Map();
    if(settings.grammar) for(const a of usedArrows){
      const to=tokenEls[a.to];
      if(!to || (!s.words && !to.marker))continue;
      const codes=(a.label||'').split(/[, /]+/).filter(Boolean);
      shownLabels.set(a.to,new Set([...(shownLabels.get(a.to)||[]),...codes]));
    }
    let anyTag=false;
    tokenEls.forEach(({cell},i)=>{
      const tag=cell.querySelector('.case');
      if(!tag)return;
      const shown=shownLabels.get(i)||new Set();
      const remaining=tag.textContent.split(',').map(x=>x.trim()).filter(x=>x && !shown.has(x));
      tag.textContent=remaining.join(',');
      tag.hidden=!remaining.length || !settings.grammar;
      if(!tag.hidden)anyTag=true;
    });
    stage.style.transform='none';
    const naturalWidth=Math.ceil(words.scrollWidth)+4;
    stage.style.width=`${naturalWidth}px`;
    const layout=layoutArrows(usedArrows,tokenEls,Boolean(s.words));
    const ruTop=settings.grammar && layout.topCount ? 20+layout.topCount*23 : 6;
    const ruHeight=Math.ceil(settings.size*1.28);
    const ruBottom=ruTop+ruHeight;
    const bottomLast=layout.bottomCount ? ruBottom+29+(layout.bottomCount-1)*24+18 : ruBottom;
    const caseBottom=anyTag ? ruBottom+19 : ruBottom;
    const nlTop=Math.max(caseBottom+5,bottomLast+9);
    const nlHeight=settings.dutch ? Math.ceil(settings.size*.88*1.24)+7 : 0;
    const naturalHeight=Math.ceil(settings.dutch ? nlTop+nlHeight : Math.max(bottomLast+8,caseBottom+8));
    stage.style.setProperty('--ruTop',`${ruTop}px`);
    stage.style.setProperty('--caseTop',`${ruBottom+4}px`);
    stage.style.setProperty('--nlTop',`${nlTop}px`);
    stage.style.height=`${naturalHeight}px`;
    svg.setAttribute('width',naturalWidth);svg.setAttribute('height',naturalHeight);
    svg.setAttribute('viewBox',`0 0 ${naturalWidth} ${naturalHeight}`);
    if(settings.grammar)drawArrows(layout,ruTop,ruBottom);
    fit();
  }
  function layoutArrows(arrows,els,isV7) {
    // Allocate just enough independent tracks for the current sentence.
    const lanes={top:[],bottom:[]};
    const prepared=[];
    for(const a of arrows){
      const from=els[a.from],to=els[a.to];
      if(!from||!to)continue;
      if(!isV7 && !to.marker)continue;
      const sourceX=from.cell.offsetLeft+from.cell.offsetWidth/2;
      const destX=isV7
        ? to.cell.offsetLeft+to.cell.offsetWidth/2
        : to.cell.offsetLeft+to.russian.offsetLeft+to.marker.offsetLeft+to.marker.offsetWidth/2;
      prepared.push({...a,sourceX,destX,span:Math.abs(sourceX-destX),
        side:a.side==='bottom'?'bottom':'top'});
    }
    prepared.sort((a,b)=>b.span-a.span);
    for(const a of prepared){
      const interval=[Math.min(a.sourceX,a.destX),Math.max(a.sourceX,a.destX)];
      let index=lanes[a.side].findIndex(group=>group.every(ex=>
        interval[0]>ex[1]+25 || interval[1]<ex[0]-25));
      if(index<0){index=lanes[a.side].length;lanes[a.side].push([]);}
      lanes[a.side][index].push(interval);
      a.lane=index;
    }
    return {prepared,topCount:lanes.top.length,bottomCount:lanes.bottom.length};
  }
  function drawArrows(layout,ruTop,ruBottom) {
    const defs=makeSVG('defs');
    for(const kind of ['grammar','semantic']){
      const color=kind==='semantic'?'#c3a8ff':'#8db4f6';
      const marker=makeSVG('marker',{id:`ru-arrow-${kind}`,markerWidth:'6',markerHeight:'6',
        refX:'5',refY:'3',orient:'auto'});
      marker.appendChild(makeSVG('path',{d:'M0,0 L6,3 L0,6 z',fill:color,stroke:'none'}));
      defs.appendChild(marker);
    }
    svg.appendChild(defs);
    for(const a of layout.prepared){
      const lineY=a.side==='top' ? 22+a.lane*23 : ruBottom+29+a.lane*24;
      const anchorY=a.side==='top' ? ruTop-7 : ruBottom+7;
      const kind=a.kind==='semantic'?'semantic':'grammar';
      const color=kind==='semantic'?'#c3a8ff':'#8db4f6';
      const p=makeSVG('path',{
        d:`M${a.sourceX.toFixed(1)} ${anchorY} V${lineY} H${a.destX.toFixed(1)} V${anchorY}`,
        stroke:color,'stroke-width':'2',fill:'none',
        'stroke-dasharray':kind==='semantic'?'5 4':'none',
        'marker-end':`url(#ru-arrow-${kind})`
      });svg.appendChild(p);
      svg.appendChild(makeSVG('circle',{cx:a.sourceX,cy:anchorY,r:2.4,fill:color}));
      const t=makeSVG('text',{
        x:(a.sourceX+a.destX)/2,
        y:a.side==='top'?lineY-7:lineY+16,
        fill:color
      });
      t.textContent=a.label||'';svg.appendChild(t);
    }
  }
  function fit() {
    if(!stage || !viewport || !currentData)return;
    stage.style.transform='none';
    const available=Math.max(1,viewport.clientWidth-20);
    const w=Number.parseFloat(stage.style.width)||available;
    const naturalHeight=Number.parseFloat(stage.style.height)||90;
    // In dock mode the *allocated* slot is fixed. Scale drawings inside it,
    // never resize the slot to accommodate a sentence or the word-detail card.
    const dock=settings.mode==='dock' && host?.dataset.mode==='dock';
    const availableHeight=dock ? Math.max(60,viewport.clientHeight-5) : Infinity;
    const ratio=Math.min(1,available/w,availableHeight/naturalHeight);
    stageHolder.style.width=`${w*ratio}px`;
    stageHolder.style.height=`${naturalHeight*ratio}px`;
    stage.style.transform=`scale(${ratio})`;
    viewport.style.height=dock ? '' : `${Math.ceil(naturalHeight*ratio+4)}px`;
    // Keep the panel inside the available screen even on small laptop displays.
    if(host && settings.mode==='overlay' && host.parentNode===document.body && !isDragging){
      const maxTop=Math.max(0,window.innerHeight-host.getBoundingClientRect().height-9);
      const requestedY=(settings.y/100)*window.innerHeight;
      host.style.top=requestedY>maxTop?`${maxTop}px`:`${settings.y}%`;
    }
  }
  function refreshCurrent() { if(currentData) renderSegment(currentData); }
  function findSegment(t) {
    let l=0,r=segments.length-1;
    while(l<=r){const mid=(l+r)>>1,s=segments[mid];
      if(t<s.start)r=mid-1;
      else if(t>=s.end)l=mid+1;
      else return mid; }
    return -1;
  }
  async function loadData(){
    if(typeof window.__roGetData!=='function')return;
    try{
      const data=await window.__roGetData(version);
      // Normal Chrome can navigate between videos without reloading the page.
      // Reset displayed data even if the two videos share the same version number.
      if(data && data.video_id && data.video_id!==activeVideoId){
        activeVideoId=data.video_id;
        version=-1;
        segments=[];
        currentSegment=-999;
        currentData=null;
      }
      if(data && data.version!==version){
        version=data.version;
        if(Array.isArray(data.segments)){segments=data.segments;currentSegment=-999;}
        if(data.status && statusEl){
          statusEl.textContent=data.status;
          statusEl.title=data.status;
        }
      }
    }catch(e){if(statusEl)statusEl.textContent=`Verbinding mislukt: ${String(e).slice(0,55)}`;}
  }
  function tick(){
    if(!document.body)return;
    if(!host)init();
    if(!host)return;
    setParent();
    const t=getVideoTime();
    if(clockEl)clockEl.textContent=timeLabel(t);
    const i=findSegment(t);
    const canSeek=typeof window.__roSeekSentence==='function' || typeof window.__roReplaySentence==='function';
    if(previousButton)previousButton.disabled=previousSentenceIndex(t)<0 || !canSeek;
    if(replayButton)replayButton.disabled=i<0 || !canSeek;
    if(nextButton)nextButton.disabled=nextSentenceIndex(t)<0 || !canSeek;
    if(sentenceButton)sentenceButton.disabled=i<0;
    if(i!==currentSegment){
      currentSegment=i;
      if(i>=0)renderSegment(segments[i]);
      else {currentData=null;words.replaceChildren();svg.replaceChildren();
        viewport.style.height=settings.mode==='dock'?'':'55px';}
    }
  }
  // YouTube changes pages without full navigation; keep overlay attached.
  const start=()=>{
    init();
    setInterval(tick,150);
    setInterval(loadData,1300);
    loadData();tick();
  };
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});
  else start();
})();
