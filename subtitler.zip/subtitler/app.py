#!/usr/bin/env python3
"""Russian interlinear YouTube player: Python + official IFrame Player API.

No Playwright, WebDriver, Chrome extension, remote debugging or embedded Google login.
The regular OS browser opens a Python-served page. YouTube playback happens
inside YouTube's supported iframe player. Sync uses player.getCurrentTime().
"""
from __future__ import annotations

import argparse
import copy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from threading import Lock, Thread
from urllib.parse import parse_qs, urlparse
import webbrowser

from captions import read_caption_file, read_caption_text, read_pasted_transcript
from linguistic import (annotate_batch, annotate_batch_ollama, empty_annotation,
                        select_provider, DEFAULT_OLLAMA_MODEL, DEFAULT_OLLAMA_URL)
from transcript import extract_video_id, fetch_subtitles, to_segments
from v7_annotations import bundled_v7, merge_v7, read_v7, validate_v7
from video_library import VideoLibrary
from auto_grammar_integration import AutoGrammarManager

HERE = Path(__file__).resolve().parent
CACHE_DIR = HERE / "cache"  # De meegeleverde voorbeeldvideo blijft beschikbaar.
def default_data_dir() -> Path:
    """Stable user-data location: an upgraded/unzipped app does not erase saved videos."""
    import sys
    if os.getenv("RUSSIAN_YOUTUBE_DATA_DIR"):
        return Path(os.environ["RUSSIAN_YOUTUBE_DATA_DIR"]).expanduser()
    if os.name == "nt":
        return Path(os.getenv("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))) / "russisch_youtube_grammatica"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "russisch_youtube_grammatica"
    return Path(os.getenv("XDG_DATA_HOME", str(Path.home() / ".local" / "share"))) / "russisch_youtube_grammatica"

USER_DATA_DIR = default_data_dir()
CACHE_VERSION = 5


def prepared_v7(video_id: str) -> dict | None:
    personal = USER_DATA_DIR / "grammar_v7" / (video_id + ".json")
    if personal.is_file():
        return read_v7(personal)
    return bundled_v7(video_id, CACHE_DIR)



def raw_cache_file(video_id: str) -> Path:
    return CACHE_DIR / "raw" / f"{video_id}.json"


def store_raw_captions(video_id: str, snippets: list[dict]) -> None:
    target = raw_cache_file(video_id)
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(".tmp")
    temp.write_text(json.dumps(snippets, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(target)


class DataState:
    def __init__(self) -> None:
        self._lock = Lock()
        self.version = 1
        self.status = "Russische ondertitels ophalen…"
        self.segments: list[dict] = []
        self.video_id = ""
        self.job_token = 0

    def new_job(self) -> int:
        with self._lock:
            self.job_token += 1
            return self.job_token

    def is_current(self, job_token: int | None) -> bool:
        with self._lock:
            return job_token is None or job_token == self.job_token

    def update(self, *, segments: list[dict] | None = None,
               status: str | None = None, job_token: int | None = None) -> None:
        with self._lock:
            if job_token is not None and job_token != self.job_token:
                return
            if segments is not None:
                self.segments = segments
            if status is not None:
                self.status = status
            self.version += 1

    def get(self, last_version: int = 0) -> dict:
        with self._lock:
            if self.version == last_version:
                return {"version": self.version, "video_id": self.video_id}
            return {"version": self.version, "video_id": self.video_id,
                    "status": self.status, "segments": copy.deepcopy(self.segments)}


def process_video(video_id: str, state: DataState, *, model: str,
                  provider: str = "auto", ollama_model: str = DEFAULT_OLLAMA_MODEL,
                  ollama_url: str = DEFAULT_OLLAMA_URL,
                  limit: int = 0, captions: str | None = None,
                  snippets: list[dict] | None = None,
                  job_token: int | None = None, annotations: str | None = None,
                  allow_fetch: bool = True) -> None:
    try:
        if annotations:
            root = read_v7(annotations)
            # An explicitly supplied, analysed transcript replaces the cache for this run.
            state.update(segments=[{**copy.deepcopy(s), 'grammar_schema': 7, 'pending': False}
                                   for s in root['segments']],
                         status=f"Klaar: {len(root['segments'])} v7-zinnen uit handmatig analysebestand",
                         job_token=job_token)
            return
        # Prefer the complete, manually reviewed v7 file for this specific video.
        # Imported video packages remain available after restarting the app.
        if snippets is None and not captions:
            reviewed = prepared_v7(video_id)
            if reviewed:
                state.update(segments=[{**copy.deepcopy(s), 'grammar_schema': 7, 'pending': False}
                                       for s in reviewed['segments']],
                             status=f"Klaar: {len(reviewed['segments'])} uitgebreide zinnen (lokaal bewaard)",
                             job_token=job_token)
                return
        # Complete, editor-reviewed overlays are usable offline; don't call YouTube
        # or any AI provider for this video unless new captions are explicitly imported.
        annotated_cache = CACHE_DIR / f"{video_id}.json"
        if snippets is None and not captions and annotated_cache.exists():
            try:
                ready = json.loads(annotated_cache.read_text(encoding="utf-8"))
                ready_segments = ready.get("segments", [])
                if (ready.get("version") == CACHE_VERSION and ready_segments
                        and all(not x.get("pending", False) for x in ready_segments)):
                    try:
                        reviewed = prepared_v7(video_id)
                        if reviewed:
                            ready_segments, n_v7 = merge_v7(ready_segments, reviewed)
                        else:
                            n_v7 = 0
                    except (OSError, ValueError, TypeError, KeyError) as exc:
                        print(f"[waarschuwing] v7-grammatica niet geladen: {exc}")
                        n_v7 = 0
                    state.update(segments=ready_segments,
                                 status=f"Klaar: {len(ready_segments)} zinnen, {n_v7} met uitgebreide v7-grammatica (offline)",
                                 job_token=job_token)
                    return
            except (OSError, TypeError, ValueError, KeyError):
                pass
        if snippets is None:
            if captions:
                snippets = read_caption_file(captions)
            elif raw_cache_file(video_id).exists():
                snippets = read_caption_file(str(raw_cache_file(video_id)))
            elif not allow_fetch:
                state.update(segments=[],
                             status="Nog geen geanalyseerd transcript. Open ⇧ Transcript en importeer ChatGPT v7-JSON.",
                             job_token=job_token)
                return
            else:
                snippets = fetch_subtitles(video_id)
                store_raw_captions(video_id, snippets)
        if not state.is_current(job_token):
            return
        segments = to_segments(snippets)
        if limit:
            segments = segments[:limit]
        if not segments:
            state.update(status="Geen Russische ondertitels; plak transcript met tijdcodes hieronder", job_token=job_token)
            return

        cache_path = CACHE_DIR / f"{video_id}.json"
        old = {}
        # Uploaded captions take precedence: don't reuse older annotations from another transcript.
        if cache_path.exists():
            try:
                obj = json.loads(cache_path.read_text(encoding="utf-8"))
                if obj.get("version") == CACHE_VERSION:
                    old = {s["id"]: s for s in obj.get("segments", [])}
            except (json.JSONDecodeError, OSError, TypeError, KeyError):
                pass

        prepared = []
        for segment in segments:
            cached = old.get(segment["id"])
            if (cached and cached.get("text") == segment["text"]
                    and cached.get("nl") and not cached.get("pending")):
                prepared.append(cached)
            else:
                prepared.append(empty_annotation(segment))
        state.update(segments=prepared, status=f"{len(prepared)} Russische fragmenten geladen", job_token=job_token)

        missing = [i for i, s in enumerate(prepared) if s.get("pending")]
        if not missing:
            state.update(status=f"Klaar: {len(prepared)} fragmenten uit cache", job_token=job_token)
            return

        api_key = os.getenv("OPENAI_API_KEY", "").strip()
        chosen, provider_status = select_provider(provider, api_key=api_key,
                                                   ollama_model=ollama_model, ollama_url=ollama_url)
        print("[taalverwerking]", provider_status)
        if chosen == "off":
            state.update(status=provider_status, job_token=job_token)
            return
        state.update(status=provider_status + "; bezig…", job_token=job_token)

        errors = 0
        # Small local batches help small models preserve strict word alignment.
        batch_size = 2 if chosen == "ollama" else 5
        for begin in range(0, len(missing), batch_size):
            ids = missing[begin:begin + batch_size]
            state.update(status=f"{provider_status} · {min(begin + batch_size, len(missing))}/{len(missing)}", job_token=job_token)
            try:
                if chosen == "ollama":
                    annotated = annotate_batch_ollama([segments[i] for i in ids],
                                                      model=ollama_model, base_url=ollama_url)
                else:
                    annotated = annotate_batch([segments[i] for i in ids], api_key, model)
                if not state.is_current(job_token):
                    return
                for i, item in zip(ids, annotated):
                    prepared[i] = item
                CACHE_DIR.mkdir(parents=True, exist_ok=True)
                temp_path = cache_path.with_suffix(".tmp")
                temp_path.write_text(json.dumps(
                    {"version": CACHE_VERSION, "segments": prepared},
                    ensure_ascii=False, indent=2), encoding="utf-8")
                temp_path.replace(cache_path)
            except Exception as exc:
                errors += len(ids)
                print(f"[waarschuwing] Analyse mislukte voor een batch: {type(exc).__name__}: {exc}")
                state.update(status=f"Fout in {chosen}: {type(exc).__name__}: {str(exc)[:100]}", job_token=job_token)
            state.update(segments=prepared, job_token=job_token)
        complete = sum(not s.get("pending") for s in prepared)
        state.update(status=f"{provider_status}. Gereed: {complete}/{len(prepared)} zinnen" +
                     (f"; {errors} mislukt — kijk in terminal" if errors else ""), job_token=job_token)
    except Exception as exc:
        print(f"[fout] Ondertekstverwerking: {type(exc).__name__}: {exc}")
        state.update(status=f"Transcript niet beschikbaar ({type(exc).__name__}); plak tekst met tijdcodes hieronder", job_token=job_token)


def handler_factory(state: DataState, video_id: str, *, model: str = "gpt-4.1-mini", limit: int = 0,
                    provider: str = "auto", ollama_model: str = DEFAULT_OLLAMA_MODEL,
                    ollama_url: str = DEFAULT_OLLAMA_URL, library: VideoLibrary | None = None,
                    auto_manager: AutoGrammarManager | None = None):
    class Handler(BaseHTTPRequestHandler):
        def read_json_request(self, max_bytes: int = 5_000_000):
            origin = self.headers.get("Origin")
            if origin not in (None, f"http://127.0.0.1:{self.server.server_port}"):
                raise PermissionError("Cross-origin verzoek geweigerd")
            if self.headers.get("Content-Type", "").split(";", 1)[0] != "application/json":
                raise ValueError("JSON vereist")
            size = int(self.headers.get("Content-Length", "-1"))
            if not (0 < size <= max_bytes):
                raise ValueError(f"Maximaal {max_bytes // 1_000_000} MB toegestaan")
            return json.loads(self.rfile.read(size).decode("utf-8"))

        def do_POST(self):
            req = urlparse(self.path)
            if req.path not in ("/api/import", "/api/videos", "/api/import-grammar",
                                "/api/auto/start", "/api/auto/import"):
                self.respond(b"Not found", "text/plain", 404)
                return
            try:
                payload = self.read_json_request()
                if not isinstance(payload, dict):
                    raise ValueError("Verwacht een JSON-object")
                if req.path == "/api/auto/start":
                    if auto_manager is None or library is None:
                        raise ValueError("Automatische grammatica is niet beschikbaar")
                    selected = state.video_id
                    if payload.get("video_id") != selected:
                        raise ValueError("De geselecteerde video is gewijzigd; herlaad de pagina")
                    entry = next((v for v in library.videos if v["id"] == selected), None)
                    if entry is None:
                        raise ValueError("Deze video staat niet in de bibliotheek")
                    auto_manager.start(selected, mode=payload.get("mode"),
                                       title=entry["title"], refresh=payload.get("refresh", False),
                                       retry=payload.get("retry", False))
                    self.send_json({"ok": True, "video_id": selected})
                    return
                if req.path == "/api/auto/import":
                    if auto_manager is None or library is None:
                        raise ValueError("Automatische grammatica is niet beschikbaar")
                    selected = state.video_id
                    if payload.get("video_id") != selected or library.selected != selected:
                        raise ValueError("De geselecteerde video is gewijzigd; herlaad de pagina")
                    target = USER_DATA_DIR / "grammar_v7" / (selected + ".json")
                    root = auto_manager.import_confirmed(selected, payload.get("hash"),
                                overwrite=payload.get("overwrite", False),
                                currently_selected=selected, target=target)
                    token = state.new_job()
                    state.update(segments=[{**copy.deepcopy(seg), "grammar_schema": 7, "pending": False}
                                           for seg in root["segments"]],
                                 status=(f"Codex-concept: {len(root['segments'])} fragmenten geïmporteerd "
                                         "na bevestiging — controleer de grammatica en tijdcodes"),
                                 job_token=token)
                    self.send_json({"ok": True, "count": len(root["segments"]),
                                    "video_id": selected, "saved": str(target)})
                    return
                if req.path == "/api/videos":
                    if library is None:
                        raise ValueError("Videobibliotheek niet beschikbaar")
                    action = payload.get("action")
                    if action == "add":
                        video_id_new = library.add(payload.get("url", ""), payload.get("title", ""))
                    elif action == "select":
                        video_id_new = payload.get("id", "")
                        library.choose(video_id_new)
                    elif action == "edit":
                        video_id_new = library.edit(payload.get("original_id", ""),
                                                     payload.get("url", ""), payload.get("title", ""))
                    else:
                        raise ValueError("Onbekende bibliotheekactie")
                    token = state.new_job()
                    with state._lock:
                        state.video_id = video_id_new
                    state.update(segments=[], status="Video openen…", job_token=token)
                    Thread(target=process_video, args=(video_id_new, state),
                           kwargs={"model": model, "job_token": token, "provider": provider,
                                   "ollama_model": ollama_model, "ollama_url": ollama_url,
                                   "allow_fetch": False}, daemon=True).start()
                    self.send_json({"ok": True, "id": video_id_new})
                    return
                if req.path == "/api/import-grammar":
                    if library is None:
                        raise ValueError("Videobibliotheek niet beschikbaar")
                    selected = state.video_id
                    root = validate_v7(payload.get("grammar"))
                    source_id = root.get("source", {}).get("video_id") if isinstance(root.get("source"), dict) else None
                    if source_id and source_id != selected:
                        raise ValueError("Dit JSON-bestand hoort bij video " + source_id +
                                         ", niet bij de geselecteerde video " + selected)
                    # Allow source.video_id to be absent, but store the association explicitly.
                    if not isinstance(root.get("source"), dict):
                        root["source"] = {}
                    root["source"]["video_id"] = selected
                    target = USER_DATA_DIR / "grammar_v7" / (selected + ".json")
                    target.parent.mkdir(parents=True, exist_ok=True)
                    temp = target.with_suffix(".tmp")
                    temp.write_text(json.dumps(root, ensure_ascii=False, indent=2), encoding="utf-8")
                    temp.replace(target)
                    token = state.new_job()
                    state.update(segments=[{**copy.deepcopy(s), 'grammar_schema': 7, 'pending': False}
                                           for s in root['segments']],
                                 status=f"Klaar: {len(root['segments'])} uitgebreide zinnen (lokaal opgeslagen)",
                                 job_token=token)
                    self.send_json({"ok": True, "count": len(root['segments']), "video_id": selected, "saved": str(target)})
                    return
                transcript = payload.get("text", "")
                fmt = payload.get("format", "paste")
                if not isinstance(transcript, str) or len(transcript) > 300_000:
                    raise ValueError("Transcripttekst te lang")
                if fmt == "paste":
                    snippets = read_pasted_transcript(transcript)
                elif fmt in ("srt", "vtt", "json"):
                    if fmt == "json":
                        candidate = json.loads(transcript)
                        if isinstance(candidate, dict) and candidate.get("schema_version") == 7:
                            raise ValueError("Dit is een v7-grammatica-JSON. Importeer dit via tab ① Grammatica-JSON, niet als ruw transcript.")
                    snippets = read_caption_text(transcript, f".{fmt}")
                else:
                    raise ValueError("Alleen transcript met tijdcodes, SRT, VTT of JSON")
                if len(snippets) > 15000:
                    raise ValueError("Te veel ondertitelregels")
                selected = state.video_id
                try:
                    store_raw_captions(selected, snippets)
                except OSError as exc:
                    print(f"[waarschuwing] Kon transcript niet lokaal opslaan: {exc}")
                token = state.new_job()
                state.update(segments=[], status=f"{len(snippets)} regels importeren…", job_token=token)
                Thread(target=process_video, args=(selected, state),
                       kwargs={"model": model, "limit": limit, "snippets": snippets,
                               "job_token": token, "provider": provider, "ollama_model": ollama_model,
                               "ollama_url": ollama_url}, daemon=True).start()
                self.send_json({"ok": True, "count": len(snippets)})
            except (ValueError, UnicodeError, TypeError, KeyError, OverflowError, OSError) as exc:
                self.send_json({"error": str(exc)}, 400)
            except PermissionError as exc:
                self.send_json({"error": str(exc)}, 403)

        def send_json(self, obj, status=200):
            self.respond(json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                         "application/json; charset=utf-8", status)

        def do_GET(self):
            req = urlparse(self.path)
            if req.path == "/":
                body = (HERE / "player.html").read_text(encoding="utf-8")
                body = body.replace("__VIDEO_ID__", state.video_id)
                self.respond(body.encode("utf-8"), "text/html; charset=utf-8")
            elif req.path == "/demo":
                self.respond((HERE / "demo_v7.html").read_bytes(), "text/html; charset=utf-8")
            elif req.path == "/overlay.js":
                self.respond((HERE / "overlay.js").read_bytes(), "application/javascript; charset=utf-8")
            elif req.path == "/FORMAT_GRAMMATICA_JSON_V7.md":
                self.respond((HERE / "FORMAT_GRAMMATICA_JSON_V7.md").read_bytes(),
                             "text/markdown; charset=utf-8")
            elif req.path == "/api/auto/status":
                if auto_manager is None:
                    self.send_json({"error": "Automatische grammatica niet beschikbaar"}, 503)
                else:
                    result = auto_manager.status(state.video_id)
                    target = USER_DATA_DIR / "grammar_v7" / (state.video_id + ".json")
                    result["would_overwrite"] = (target.exists() or
                        (CACHE_DIR / "grammar_v7" / (state.video_id + ".json")).exists())
                    self.send_json(result)
            elif req.path == "/api/auto/log":
                if auto_manager is None:
                    self.respond(b"Not found", "text/plain", 404)
                else:
                    data = auto_manager.read_full_log(state.video_id).encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "text/plain; charset=utf-8")
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.send_header("Content-Disposition", "attachment; filename=codex_log_" + state.video_id + ".txt")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
            elif req.path == "/api/auto/draft":
                if auto_manager is None:
                    self.respond(b"Not found", "text/plain", 404)
                else:
                    try:
                        auto_manager.read_draft(state.video_id)
                        blob = auto_manager._draft_file(state.video_id).read_bytes()
                        self.send_response(200)
                        self.send_header("Content-Type", "application/json; charset=utf-8")
                        self.send_header("Content-Disposition", 'attachment; filename="codex_concept_' + state.video_id + '.json"')
                        self.send_header("Content-Length", str(len(blob)))
                        self.send_header("Cache-Control", "no-store")
                        self.send_header("X-Content-Type-Options", "nosniff")
                        self.end_headers()
                        self.wfile.write(blob)
                    except (OSError, ValueError, TypeError, KeyError):
                        self.send_json({"error": "Geen geldig volledig concept beschikbaar"}, 404)
            elif req.path == "/api/videos":
                if library is None:
                    self.send_json({"selected": state.video_id, "videos": []})
                else:
                    self.send_json(library.get(USER_DATA_DIR, bundled_cache_dir=CACHE_DIR))
            elif req.path == "/api/data":
                try:
                    version = int(parse_qs(req.query).get("version", ["0"])[0])
                except (ValueError, OverflowError):
                    version = 0
                result = state.get(version)
                self.respond(json.dumps(result, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
            elif req.path == "/health":
                self.respond(b'{"ok":true}', "application/json")
            elif req.path == "/favicon.ico":
                self.respond(b"", "image/x-icon", 204)
            else:
                self.respond(b"Not found", "text/plain", 404)

        def respond(self, payload: bytes, content_type: str, status: int = 200):
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
            self.end_headers()
            self.wfile.write(payload)

        def log_message(self, fmt, *args):
            # Suppress repetitive caption polling logs, keep errors visible.
            if not self.path.startswith("/api/data"):
                super().log_message(fmt, *args)

    return Handler


def chrome_launch_commands(browser: str) -> list[tuple[list[str], str]]:
    """Discover Chrome/Chromium, including Flatpak (common on Linux Mint).

    Build argument arrays rather than shell strings. A Flatpak Chrome app is the
    same installed browser the user normally uses, with its regular profile.
    """
    commands: list[tuple[list[str], str]] = []
    if sys.platform == 'darwin':
        candidates = ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome']
    elif os.name == 'nt':
        candidates = []
        for base in (os.getenv('PROGRAMFILES'), os.getenv('PROGRAMFILES(X86)'),
                     os.getenv('LOCALAPPDATA')):
            if base:
                candidates.extend([
                    str(Path(base) / 'Google' / 'Chrome' / 'Application' / 'chrome.exe'),
                    str(Path(base) / 'Chromium' / 'Application' / 'chrome.exe'),
                ])
    else:
        candidates = ['google-chrome', 'google-chrome-stable', 'chrome',
                      'chromium', 'chromium-browser']

    for candidate in candidates:
        binary = shutil.which(candidate) or (candidate if Path(candidate).is_file() else None)
        if binary:
            commands.append(([binary], 'Chrome/Chromium'))

    # Linux Flatpak Chrome does not usually provide an executable named
    # `google-chrome` on PATH. `webbrowser.open` resolves its desktop launcher,
    # but will re-use an existing Chrome tab. Launch through `flatpak run`
    # explicitly and pass --app=URL instead.
    if not commands and os.name != 'nt' and sys.platform.startswith('linux'):
        flatpak = shutil.which('flatpak')
        if flatpak:
            try:
                installed = subprocess.run(
                    [flatpak, 'list', '--app', '--columns=application'],
                    capture_output=True, text=True, check=False, timeout=8,
                )
            except (OSError, subprocess.TimeoutExpired):
                installed = None
            if installed is not None and installed.returncode == 0:
                app_ids = {line.strip() for line in installed.stdout.splitlines()}
                for app_id in ('com.google.Chrome', 'com.google.ChromeBeta',
                               'com.google.ChromeDev', 'org.chromium.Chromium'):
                    if app_id in app_ids:
                        commands.append(([flatpak, 'run', app_id], f'{app_id} (Flatpak)'))
    return commands


def open_local_browser(url: str, browser: str = 'default') -> str:
    """Open the local UI. No YouTube scraping, Selenium or browser automation."""
    if browser == 'none':
        return 'niet geopend (--browser none)'
    if browser == 'default':
        webbrowser.open(url, new=1)
        return 'standaardbrowser'
    if browser in ('chrome', 'app'):
        # For app mode ONLY open an actual app window; never silently open a tab.
        for prefix, description in chrome_launch_commands(browser):
            command = prefix + ([f'--app={url}'] if browser == 'app' else [url])
            try:
                subprocess.Popen(command, stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL, start_new_session=True)
                return f'{description}: ' + ('appvenster' if browser == 'app' else 'browservenster')
            except OSError as exc:
                print(f'[waarschuwing] {description} kon niet starten: {exc}')
        print('[waarschuwing] Geen geïnstalleerde Chrome/Chromium gevonden via PATH of Flatpak.')
        print(f'Open desgewenst zelf: {url}')
        print('Controleer eventueel: flatpak list --app')
        print('Een gewone browsertab openen kan expliciet met --browser default.')
        return 'geen Chrome gevonden; geen browsertab geopend'
    raise ValueError(f'Onbekende browserkeuze: {browser}')


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(description="YouTube-player met Russische grammatica-overlay en optionele Codex-conceptgeneratie")
    parser.add_argument("url", nargs="?", help="Video-URL of video-ID")
    parser.add_argument("--demo", action="store_true", help="Start offline proefspeler met 28 geanalyseerde zinnen")
    parser.add_argument("--annotations", metavar="V7_JSON", help="Gebruik een door ChatGPT voorbereid v7-JSON met tijdcodes, vertaling en pijlen")
    parser.add_argument("--captions", metavar="BESTAND", help="Gebruik lokaal Russisch .srt/.vtt/.json transcript met tijdcodes")
    parser.add_argument("--limit", type=int, default=0, help="Verwerk maximaal N fragmenten om te testen")
    parser.add_argument("--port", type=int, default=0, help="Lokale serverpoort (0 = automatisch vrij)")
    parser.add_argument("--no-browser", action="store_true", help="Start alleen server (bestaande optie)")
    parser.add_argument("--browser", choices=("app", "default", "chrome", "none"), default="app",
                        help="Standaard een zelfstandig Chrome-appvenster; default = systeem-browser, chrome = gewone Chrome-tab, none = niet openen")
    parser.add_argument("--model", default=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
                        help="OpenAI-model, als OpenAI wordt gebruikt")
    parser.add_argument("--provider", choices=("auto", "ollama", "openai", "off"),
                        default="off", help="Taalanalyse: standaard uit; gebruik een vooraf gemaakt v7-JSON")
    parser.add_argument("--ollama-model", default=os.getenv("OLLAMA_MODEL", DEFAULT_OLLAMA_MODEL))
    args = parser.parse_args(argv)
    if args.limit < 0 or not (0 <= args.port <= 65535):
        parser.error("--limit en --port mogen niet negatief zijn; poort maximaal 65535")
    if args.annotations and not Path(args.annotations).is_file():
        parser.error(f"V7-annotaties niet gevonden: {args.annotations}")
    if args.captions and not Path(args.captions).is_file():
        parser.error(f"Ondertitelbestand niet gevonden: {args.captions}")

    library = VideoLibrary(USER_DATA_DIR / "videos.json")
    if not library.videos:
        library.add("sF20z8jY1yU", "Grootmoeder en haar slimme kat")
    if args.url and not args.demo:
        video_id = library.add(args.url)
    else:
        video_id = "sF20z8jY1yU" if args.demo else library.selected
    state = DataState()
    state.video_id = video_id
    auto_manager = AutoGrammarManager(HERE, USER_DATA_DIR)
    server = ThreadingHTTPServer(("127.0.0.1", args.port), handler_factory(state, video_id, model=args.model, limit=args.limit,
                             provider=args.provider, ollama_model=args.ollama_model, library=library,
                             auto_manager=auto_manager))
    url = f"http://127.0.0.1:{server.server_port}/{'demo' if args.demo else ''}"
    print("Offline grammaticademo" if args.demo else
          "YouTube-speler in een lokaal Chrome-appvenster (indien beschikbaar); geen browserautomatisering.")
    print("Videospeler:", url)
    print("Overlay is verplaatsbaar; gebruik de knop 'Volledig scherm' op onze pagina.")
    print("Ctrl+C sluit de lokale Python-server.")
    token = state.new_job()
    if args.demo:
        root = prepared_v7(video_id)
        if not root:
            parser.error("De offline demo heeft cache/grammar_v7/sF20z8jY1yU.json nodig")
        state.update(segments=[{**copy.deepcopy(s), 'grammar_schema': 7, 'pending': False}
                               for s in root['segments']],
                     status=f"Offline demo: {len(root['segments'])} gecontroleerde voorbeeldzinnen",
                     job_token=token)
    else:
        Thread(target=process_video, args=(video_id, state),
           kwargs={"model": args.model, "limit": args.limit, "captions": args.captions,
                   "job_token": token, "provider": args.provider, "ollama_model": args.ollama_model,
                   "annotations": args.annotations, "allow_fetch": False},
           daemon=True).start()
    browser_choice = 'none' if args.no_browser else args.browser
    print('Browser:', open_local_browser(url, browser_choice))
    try:
        server.serve_forever(poll_interval=.2)
    except KeyboardInterrupt:
        print("\nAfgesloten.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
