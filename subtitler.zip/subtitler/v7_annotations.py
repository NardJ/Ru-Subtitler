"""Load reviewed interlinear v7 grammar and merge it with older v6 segments.
No online service is involved. New v7 grammar only applies to matching source text.
"""
from __future__ import annotations
import copy
import json
from pathlib import Path


def read_v7(path: str | Path) -> dict:
    return validate_v7(json.loads(Path(path).read_text(encoding="utf-8")))


def validate_v7(root: dict) -> dict:
    if not isinstance(root, dict):
        raise ValueError("Het JSON-bestand moet een object zijn")
    if root.get('schema_version') != 7 or not isinstance(root.get('segments'), list):
        raise ValueError('Verwacht JSON met schema_version: 7 en segments[]')
    if not root['segments']:
        raise ValueError('Het v7-bestand bevat geen zinnen')
    if len(root['segments']) > 15000:
        raise ValueError('Te veel zinnen in het v7-bestand')
    ids = set()
    last_start = -1.0
    for segment in root['segments']:
        id_ = segment.get('id')
        if id_ in ids:
            raise ValueError(f'Dubbele zin-ID: {id_}')
        ids.add(id_)
        n = len(segment.get('tokens', []))
        if n < 1 or n != len(segment.get('nl', [])) or n != len(segment.get('words', [])):
            raise ValueError(f'Verkeerde woorduitlijning in zin {id_}')
        import math
        start, end = float(segment['start']), float(segment['end'])
        if not math.isfinite(start) or not math.isfinite(end) or start < 0 or start >= end:
            raise ValueError(f'Ongeldige tijdcodes in zin {id_}')
        if start < last_start:
            raise ValueError('De zinnen moeten op tijdcode zijn gesorteerd')
        last_start = start
        for i, word in enumerate(segment['words']):
            if word.get('i') != i or word.get('form') != segment['tokens'][i]:
                raise ValueError(f'Woorden komen niet overeen in zin {id_}, woord {i}')
        relation_ids = {r['id'] for r in segment.get('relations', [])}
        for rel in segment.get('relations', []):
            a, b = rel['from'], rel['to']
            if not isinstance(a,int) or not isinstance(b,int) or not (0 <= a < n and 0 <= b < n and a != b):
                raise ValueError(f'Ongeldige relatie in zin {id_}: {rel}')
            if any(dep not in relation_ids for dep in rel.get('depends_on', [])):
                raise ValueError(f'Onbekende oorzaakrelatie in zin {id_}')
    return root


def merge_v7(base_segments: list[dict], root: dict) -> tuple[list[dict], int]:
    """Keep all legacy sentences; replace exactly matching text/tokens with v7 records."""
    reviewed = {s['id']:s for s in root['segments']}
    result, applied = [], 0
    for original in base_segments:
        upgrade = reviewed.get(original.get('id'))
        if upgrade and (upgrade['text'] == original.get('text')
                        and upgrade['tokens'] == original.get('tokens')
                        and abs(float(upgrade['start']) - float(original['start'])) < .02
                        and abs(float(upgrade['end']) - float(original['end'])) < .02):
            replacement = copy.deepcopy(upgrade)
            replacement['pending'] = False
            replacement['grammar_schema'] = 7
            result.append(replacement)
            applied += 1
        else:
            result.append(copy.deepcopy(original))
    return result, applied


def bundled_v7(video_id: str, cache_dir: Path) -> dict | None:
    path = cache_dir / 'grammar_v7' / f'{video_id}.json'
    return read_v7(path) if path.is_file() else None
