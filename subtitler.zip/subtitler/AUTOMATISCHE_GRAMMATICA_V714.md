# Automatische YouTube → Codex grammatica in v7.14

De speler v7.14 bevat de experimentele knop **⚙ Auto grammatica**.
Hij gebruikt hetzelfde Nederlandse v7-grammaticaformaat en behoudt alle bestaande functies uit v7.12.

## Installatie of upgrade op Linux

1. Pak `russisch_youtube_grammatica_v7_14.zip` uit. Binnenin heet de programmamap **`russisch_youtube_grammatica`** (geen versienummer).
2. Open een terminal in die programmamap.
3. Gebruik bij voorkeur één virtuele omgeving voor alle afhankelijkheden:

   ```bash
   python3 -m venv .venv
   .venv/bin/python -m pip install -r requirements.txt
   ```

4. Controleer dat de standalone Codex CLI aanwezig en aangemeld is:

   ```bash
   ~/.local/bin/codex --version
   ~/.local/bin/codex login status
   ```

   Als de tweede opdracht niet wordt ondersteund, probeer `~/.local/bin/codex login`.
   Voor een al aangemelde Codex CLI is opnieuw inloggen niet nodig. Gebruik géén npm.
5. Start met `.venv/bin/python app.py`. Op Linux met Chrome als Flatpak opent de speler zijn bekende appvenster.

De download is gebaseerd op de **lokaal al geteste** yt-dlp-aanpak met `secretstorage` en het Chrome-Flatpak-profiel `~/.var/app/com.google.Chrome/`. De module laat `yt-dlp` de cookies lokaal lezen. Deel of exporteer die cookies niet. Het gebruik van YouTube-ondertitels kan door YouTube worden beperkt. Windows/macOS heeft mogelijk andere browsercookie-instellingen; deze automatische route is op Linux getest.

## Werkwijze in de speler

1. Kies een video, of voeg via **＋ Video** de YouTube-URL toe.
2. Klik bovenaan op **⚙ Auto grammatica**. Alternatief: **Transcript → ③ Automatisch (Codex)**.
3. Optioneel: **1. Transcript voorbereiden** haalt alleen de Russische ondertitels op en maakt een zinnenoverzicht. Nog geen Codex-aanroep.
4. Klik **2. Start / hervat Codex**. Een nog ontbrekend Russisch transcript wordt automatisch opgehaald. Een voortgangsbalk toont het aantal **afgeronde** batches, het percentage en welke batch nu bezig is. Tijdens downloaden of voorbereiden is het totale aantal nog onbekend; dan verschijnt een bewegend wachtsymbool. De gegenereerde analyse kan even duren, afhankelijk van het aantal fragmenten en de Codex-limieten.
5. Bekijk de eerste 10 zinnen in het venster en download desgewenst het **volledige JSON-concept** om ook de overige grammatica en tijdcodes te controleren.
6. Vink aan dat je het concept gecontroleerd hebt. Staat er al grammatica bij die video, bevestig ook dat die vervangen mag worden. Klik **Importeer dit concept als grammatica** en bevestig nogmaals.
7. Het grammatica-JSON wordt nu pas actief in de speler. Een eerder lokaal importbestand krijgt eerst een `backup-...json`-kopie.

**Belangrijk:** de structurele validator voorkomt een aantal fouten, maar bewijst niet dat de grammaticale toelichtingen taalkundig perfect zijn. Vooral schattingen van ondertitelgrenzen en uitzonderlijke Russische constructies moet je controleren. Automatische import gebeurt nooit op de achtergrond. De handmatige importtabs blijven intact.

## Na een onderbreking hervatten

Gebruik opnieuw **2. Start / hervat Codex**. De generator hergebruikt eerdere geldige batches; een afgeronde video hoeft niet opnieuw te worden geanalyseerd als het bestaande VTT en de prompt niet veranderen. Vink **Ondertitels opnieuw ophalen** alleen aan wanneer je een verse transcriptdownload wilt; nieuwe zinsindeling kan sommige cachebatches ongeldig maken.

De resultaten staan onder Linux in:

```
~/.local/share/russisch_youtube_grammatica/auto_codex/<video-id>/
```

Hier staan de oorspronkelijke VTT, `zinnenoverzicht.md`, `codex_batches/`, `rapport.md`, het concept-JSON en logbestanden. Ze blijven behouden bij het uitpakken van nieuwe spelerversies. De actieve grammatica staat apart in `~/.local/share/russisch_youtube_grammatica/grammar_v7/<video-id>.json`.

## Gebruik je eerdere 62-fragmenten-proef van Алексей opnieuw

Dat kan **zonder nieuwe Codex-analyse**. Kopieer de bestaande resultaten eenmalig naar de nieuwe persistente resultaatmap:

```bash
mkdir -p ~/.local/share/russisch_youtube_grammatica/auto_codex
cp -a ~/Downloads/youtube_codex_end_to_end/resultaten/QpQmw2rxxtQ \
  ~/.local/share/russisch_youtube_grammatica/auto_codex/
```

Selecteer in de speler de video `QpQmw2rxxtQ` (voeg hem zo nodig eerst toe via **＋ Video**). Open **⚙ Auto grammatica**. Het eerder gegenereerde volledige concept verschijnt direct ter controle. De speler normaliseert eventuele oude grammaticale codes **bij import**, zonder het oorspronkelijke concept te wijzigen.

De 13 oude `codex_batches/` blijven eveneens beschikbaar voor een hervatting. Voor deze video is de Codex-prompt bewust ongewijzigd gebleven, zodat de oude batch-hashes geldig blijven.

Heb je ooit `RUSSIAN_YOUTUBE_DATA_DIR` ingesteld? Gebruik die map in plaats van `~/.local/share/russisch_youtube_grammatica`.

## Geen Russisch ondertitelspoor of problemen met aanmelden?

Dan kan het automatisch genereren voor die video niet doorgaan. Je kunt nog steeds via **Transcript → ① Grammatica-JSON** handmatig een gecontroleerd grammatica-JSON importeren, of via **② Ruw transcript** een bestand of tekst met tijdcodes invoeren. De bestaande grammatica wordt door mislukte automatische pogingen **niet** verwijderd of aangepast.

## Technisch

- Geen npm, geen OpenAI-API-sleutel; Codex gebruikt je bestaande lokale login en abonnementsgrenzen.
- `auto_grammar_cli.py` is de aangepaste proefgenerator; direct gebruik via `.venv/bin/python auto_grammar_cli.py --help` is mogelijk.
- De server luistert uitsluitend op `127.0.0.1`, verwerkt JSON-aanroepen uit de eigen browserpagina en gebruikt geen externe service voor voortgang of cache.
- De speler zelf ontvangt geen Chrome-cookies. yt-dlp beheert zijn eigen lokale toegang.

## Nieuwe voortgangsbalk in v7.14

- Tijdens de VTT-download staat **Transcript ophalen / voorbereiden…** zonder kunstmatig percentage.
- Zodra de ondertitels zijn ingedeeld, zie je bijvoorbeeld **0 van 13 batches afgerond — Batch 1/13 wordt door Codex geanalyseerd**.
- Pas na valideren en opslaan van een batch loopt het percentage op. Geldige cachebatches tellen mee.
- Automatische herstelpogingen staan bij de betrokken batch.
- Na de laatste batch verschijnt eerst **grammatica-JSON controleren en opslaan**; pas als het complete concept geldig is verschijnt **100% — Volledig concept gereed**.
- Na een fout blijft het bereikte percentage staan en kun je veilig op **Start / hervat Codex** klikken.

**Upgrade terwijl Codex bezig is:** sluit de oude speler niet af voordat het proces klaar is als je een ononderbroken run wilt. Als de speler toch wordt gestopt, blijven reeds afgeronde batches veilig in `~/.local/share/russisch_youtube_grammatica/auto_codex/`. Hervat vervolgens vanuit v7.14.
