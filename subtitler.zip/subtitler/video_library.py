"""Persisted local video library, no YouTube scraping or cloud connection."""
from __future__ import annotations

import json
import re
from pathlib import Path
from threading import RLock

from transcript import extract_video_id

VIDEO_ID_RE = re.compile(r"^[a-zA-Z0-9_-]{11}$")


class VideoLibrary:
    def __init__(self, filename: Path):
        self.path = Path(filename)
        self._lock = RLock()
        self.videos = []
        self.selected = None
        if self.path.is_file():
            try:
                root = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(root.get("videos"), list):
                    for entry in root["videos"]:
                        if (isinstance(entry, dict) and VIDEO_ID_RE.fullmatch(str(entry.get("id", "")))
                            and isinstance(entry.get("title"), str)):
                            self.videos.append({"id": entry["id"], "title": entry["title"][:160]})
                selected = root.get("selected")
                if any(v["id"] == selected for v in self.videos):
                    self.selected = selected
            except (OSError, ValueError, TypeError):
                pass

    def _save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps({"videos": self.videos, "selected": self.selected},
                                   ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(self.path)

    def add(self, url_or_id: str, title: str = "", select: bool = True) -> str:
        video_id = extract_video_id(url_or_id)
        title = str(title).strip()[:160] or f"YouTube-video {video_id}"
        with self._lock:
            old = next((v for v in self.videos if v["id"] == video_id), None)
            if old and title != f"YouTube-video {video_id}":
                old["title"] = title
            elif not old:
                self.videos.append({"id": video_id, "title": title})
            if select:
                self.selected = video_id
            self._save()
        return video_id

    def edit(self, original_id: str, url_or_id: str, title: str) -> str:
        """Edit the selected entry. Transcripts are keyed by video ID and NEVER moved."""
        new_id = extract_video_id(url_or_id)
        title = str(title).strip()[:160]
        if not title:
            raise ValueError("Geef de video een naam")
        with self._lock:
            entry = next((v for v in self.videos if v["id"] == original_id), None)
            if entry is None:
                raise ValueError("De oorspronkelijke video is niet meer aanwezig")
            if new_id != original_id and any(v["id"] == new_id for v in self.videos):
                raise ValueError("De nieuwe URL hoort bij een video die al in je bibliotheek staat")
            # Old grammar stays with original_id, never attached to the new ID.
            entry.update({"id": new_id, "title": title})
            if self.selected == original_id:
                self.selected = new_id
            self._save()
        return new_id

    def choose(self, video_id: str):
        with self._lock:
            if not any(v["id"] == video_id for v in self.videos):
                raise ValueError("Deze video staat niet in je bibliotheek")
            self.selected = video_id
            self._save()

    def get(self, cache_dir: Path, *, bundled_cache_dir: Path | None = None) -> dict:
        with self._lock:
            return {
                "selected": self.selected,
                "videos": [
                    {**v, "url": f"https://www.youtube.com/watch?v={v['id']}",
                     "has_grammar": ((cache_dir / 'grammar_v7' / (v['id'] + '.json')).is_file() or
                                     (bundled_cache_dir is not None and
                                      (bundled_cache_dir / 'grammar_v7' / (v['id'] + '.json')).is_file()))}
                    for v in self.videos
                ],
            }
