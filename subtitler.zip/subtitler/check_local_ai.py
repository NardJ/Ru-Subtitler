#!/usr/bin/env python3
"""Controleer Ollama met één korte Russische zin, zonder YouTube."""
import argparse
from linguistic import (DEFAULT_OLLAMA_MODEL, select_provider,
                        annotate_batch_ollama)

parser=argparse.ArgumentParser(description='Controleer lokale RU-NL vertaling en grammatica')
parser.add_argument('--model', default=DEFAULT_OLLAMA_MODEL)
args=parser.parse_args()
backend, status=select_provider('ollama', ollama_model=args.model)
print(status)
if backend!='ollama':
    raise SystemExit(1)
sample={'id':0,'start':0.0,'end':4.0,
        'text':'Вчера мой брат купил в магазине новую книгу.',
        'tokens':['Вчера','мой','брат','купил','в','магазине','новую','книгу']}
print('Eén zin analyseren (dit kan op CPU even duren)...')
try:
    annotated=annotate_batch_ollama([sample], model=args.model)[0]
except Exception as exc:
    print('Modelantwoord mislukt:', type(exc).__name__, str(exc))
    raise SystemExit(2)
print('RUSSISCH:', ' / '.join(sample['tokens']))
print('NEDERLANDS:', ' / '.join(annotated['nl']))
print('VERANDERDE UITGANGEN:', annotated['endings'])
print('PIJLEN:', annotated['arrows'])
print('NAAMVALLEN:', annotated['tags'])
