# Specificatie grammaticale transcriptbestanden — schema v7

**Doel:** de lokale speler `russisch_youtube_grammatica` voorzien van Russische ondertitels met tijdcodes, letterlijk Nederlands, grammaticale eigenschappen, pijlen en woorduitleg. Deze beschrijving is gebaseerd op de daadwerkelijk gebruikte importvalidator (`v7_annotations.py`), de HTTP-import in `app.py` en de weergave in `overlay.js` (app v7.9).

> **Twee verschillende bestandstypen:** een *grammatica-JSON* is niet hetzelfde als een ruw transcript of een JSON met enkel tijdcodes. Gebruik in de speler **Transcript → ① Grammatica-JSON** voor dit formaat. Gebruik **② Ruw transcript** uitsluitend voor SRT, VTT, een ruwe tijdcode-JSON of geplakte transcripttekst. Ruwe transcriptbestanden bevatten nog geen gecontroleerde grammaticale uitleg.

## 1. De workflow

1. Sla de YouTube-video op via **＋ Video**.
2. Download het oorspronkelijke **Russische** transcript met tijdcodes (plakken, SRT of VTT); geef het samen met de YouTube-URL aan ChatGPT.
3. ChatGPT levert een UTF-8 JSON-bestand volgens dit document, inclusief dezelfde `source.video_id` als in de YouTube-URL.
4. Selecteer die video in de speler en open **Transcript → ① Grammatica-JSON**.
5. Selecteer het `.json`-bestand, druk op **Importeer grammatica-JSON** en wacht op **Import geslaagd** met het aantal zinnen.
6. De speler bewaart de inhoud blijvend in de persoonlijke gegevensmap onder `grammar_v7/<video_id>.json`. Een update van de programmamap wist die niet.

## 2. Hoofdstructuur

```json
{
  "schema_version": 7,
  "status": "Klaar: 1 grammaticaal geanalyseerde zin",
  "source": {
    "video_id": "abcdefghijk",
    "youtube_url": "https://www.youtube.com/watch?v=abcdefghijk",
    "title": "Voorbeeldvideo",
    "language": "ru"
  },
  "segments": []
}
```

De `segments`-lijst hierboven is **alleen schematisch**: een daadwerkelijk importeerbaar bestand moet ten minste één segment bevatten. Een compleet, geldig voorbeeld staat in paragraaf 5.

| Veld | Vereist | Betekenis |
|---|---|---|
| `schema_version` | Ja | Getal `7`. Niet de tekst `"7"`. |
| `segments` | Ja | Niet-lege lijst met zinnen/fragmenten; maximaal 15.000. |
| `source.video_id` | Sterk aanbevolen | De exacte YouTube-video-ID (11 tekens). Als dit veld bestaat, controleert de speler het tegen de geselecteerde video. Bij mismatch wordt de import geweigerd. |
| `source.youtube_url`, `source.title`, `source.language` | Nee | Bronadministratie. |
| `status`, `semantics` | Nee | Vrije beschrijvende velden. |

Het bestand bevat **maximaal 5 MB** aan JSON in de browserimport. Gebruik UTF-8, dus Russische letters rechtstreeks, niet een beschadigde tekenconversie.

## 3. Per segment (zin of gesproken fragment)

| Veld | Vereist | Betekenis |
|---|---|---|
| `id` | Ja | Unieke segment-ID (bijvoorbeeld `0`, `1`, `2`); geen duplicaten. |
| `start`, `end` | Ja | Start en einde in **seconden vanaf het begin van de video**. Bijvoorbeeld `83.5` voor 1:23,5. `0 <= start < end`. Beginmomenten oplopend sorteren. |
| `text` | Aanbevolen | De Russische gesproken zin zonder tijdcode. |
| `tokens` | Ja | Lijst Russische woorden in de oorspronkelijke volgorde. Interpunctie kan in `text` staan. |
| `nl` | Ja | Letterlijke Nederlandse woordvertalingen, **precies één per `tokens[i]`**. De indexen moeten identiek zijn. Meerwoordige Nederlandse equivalenten mogen koppeltekens gebruiken. |
| `words` | Ja | Lijst grammaticale woordobjecten, precies één per token. `words[i].i == i` en `words[i].form == tokens[i]`. |
| `relations` | Nee | Lijst met grammaticale pijlen; wordt voor deze trainer sterk aanbevolen. |
| `nl_natural` | Nee | Natuurlijk leesbare vertaling van de hele zin, naast het letterlijke Nederlands. |
| `sentence_note` | Nee | Korte grammaticale uitleg voor de hele zin. |
| `word_order_note` | Nee | **Waarom deze Russische woordvolgorde?** Nederlandse uitleg van de Russische volgorde tegenover de natuurlijke NL-volgorde. Benoem narratieve inversie, informatiestructuur, naamvallen of een weggelaten werkwoord alleen wanneer dit daadwerkelijk speelt. |

**Let op:** de validatie controleert lengte, tijdvolgorde en woordindexen, maar kan *geen taalkundige juistheid* bewijzen. Die moet je inhoudelijk controleren. Klemtoontekens zoals `а́` moeten identiek blijven in `tokens` en `words.form`.

## 4. Woorden, naamvallen, pijlen en tabellen

### Woordobject `words[i]`

- `i`: nulgebaseerde index in `tokens`.
- `form`: de exacte oppervlaktevorm in `tokens[i]`.
- `nl`: letterlijke vertaling van dat woord.
- `lemma`: woordenboekvorm, bijvoorbeeld `стол`.
- `pos`: woordsoort, bijvoorbeeld `NOUN`, `VERB`, `ADJ`, `DET`, `PRON`, `ADP`, `ADV`, `PART`.
- `features`: morfologische kenmerken. Bijvoorbeeld `{ "gender": "M", "number": "SG", "case": "I" }` of `{ "person": "3", "number": "SG", "tense": "PRES" }`.
- `role`, `explanation`: Nederlandstalige beschrijving en de reden voor de vorm.
- `inflection`: optioneel. Bijvoorbeeld `{ "surface_suffix": "ом", "pattern": "стол → столом", "explanation": "Instrumentalis enkelvoud." }`. Alleen een echt zichtbare uitgang als `surface_suffix` invullen.
- `paradigm`: optioneel. Hiermee maakt de speler de NGDAIP- en M/V/O-tabellen bij een aangeklikt woord.

**Naamvalcodes:** `N` nominatief, `G` genitief, `D` datief, `A` accusatief, `I` instrumentalis, `P` prepositioneel. **Geslacht:** `M` mannelijk, `F` vrouwelijk, `N` onzijdig. De `N` heeft dus een andere betekenis in `features.case` dan in `features.gender`. **Getal:** `SG`, `PL`. Bijvoorbeeld `PAST`, `PRES`, `PERFECTIVE`, `IMPERFECTIVE` zijn gangbare waarden voor werkwoorden.

### Grammaticale relatie `relations[]`

```json
{
  "id": "0-r3",
  "from": 2,
  "to": 3,
  "type": "case_government",
  "label": "I",
  "show_by_default": true,
  "depends_on": ["0-r2"],
  "explanation": "Na под met een vaste plaats staat hier instrumentalis."
}
```

- `from` en `to` verwijzen naar **woordindexen**, niet naar letters of JSON-IDs. Ze moeten binnen dezelfde zin liggen en verschillend zijn.
- `id` identificeert de relatie; `depends_on` verwijst naar bestaande relatie-IDs **uit dezelfde zin**.
- `type: "case_government"` tekent normaal een naamvalspijl **onder** de woorden.
- `type: "semantic_context"` (of `verb_preposition_frame`, `semantic_role`) tekent een semantische pijl **boven** de woorden.
- Andere typen, zoals `subject_verb_agreement`, `agreement`, `past_gender` en `negation`, kunnen ook worden gebruikt.
- `label` is het korte visuele opschrift, bijvoorbeeld `3S`, `F,N`, `G`, `I`, `richting` of `plaats`.
- `show_by_default: false` bewaart de verklaring zonder de pijl standaard te tekenen; de relatie blijft in de woorduitleg zichtbaar. In speler **v7.15** is dit een compatibiliteitsveld: de gebruikerskeuze **Naamvallen / Alle grammatica** bepaalt zichtbaarheidsfilters; in *Alle grammatica* wordt de relatie dus ook getoond wanneer dit veld `false` is.
- `explanation` moet de **oorzaak** beschrijven, niet alleen de naamval benoemen.

**Taalkundige ontwerpregel:** leg ook samengestelde oorzaken vast. Bij `Кот сидит под столом` geeft `сидит → под` de plaatsbetekenis en `под → столом` de instrumentalis. Bij `идёт в комнату` zou dezelfde logica tot accusatief leiden door een bestemming, niet simpelweg doordat het voorzetsel `в` aanwezig is.

### `paradigm` voor NGDAIP en M/V/O

Zelfstandig naamwoord:

```json
"paradigm": {
  "kind": "noun",
  "scope": "enkelvoud",
  "forms": {
    "N": "стол", "G": "стола", "D": "столу",
    "A": "стол", "I": "столом", "P": "столе"
  }
}
```

Bij een bezittelijk of bijvoeglijk woord gebruik je `kind: "agreement"` met **zes `rows`** in NGDAIP-volgorde. Iedere rij is een object met `M`, `F`, `N`, bijvoorbeeld nominatief `{ "M": "новый", "F": "новая", "N": "новое" }`. Dat levert de M/V/O-vergelijking in het klikvenster. Een naamwoord krijgt daarnaast de **vaste** vergelijking met `стол`, `комната` en `окно`; het woord verandert niet zelf van geslacht.

## 5. Volledig geldig voorbeeld (één zin)

Hieronder staat een *zelfstandig importeerbaar* voorbeeld. Vervang `abcdefghijk` door de ID van je eigen opgeslagen video voordat je het importeert.

```json
{
  "schema_version": 7,
  "source": {"video_id": "abcdefghijk", "language": "ru"},
  "segments": [
    {
      "id": 0,
      "start": 0.0,
      "end": 4.0,
      "text": "Кот сидит под столом.",
      "tokens": ["Кот", "сидит", "под", "столом"],
      "nl": ["Kat", "zit", "onder", "tafel"],
      "nl_natural": "De kat zit onder de tafel.",
      "sentence_note": "Statische plaats: сидит под + instrumentalis.",
      "words": [
        {
          "i": 0, "form": "Кот", "nl": "Kat", "lemma": "кот",
          "pos": "NOUN", "role": "onderwerp",
          "features": {"gender": "M", "number": "SG", "case": "N", "animacy": "ANIMATE"},
          "paradigm": {"kind": "noun", "scope": "enkelvoud", "forms": {"N": "кот", "G": "кота", "D": "коту", "A": "кота", "I": "котом", "P": "коте"}}
        },
        {
          "i": 1, "form": "сидит", "nl": "zit", "lemma": "сидеть",
          "pos": "VERB", "role": "persoonsvorm",
          "features": {"person": "3", "number": "SG", "tense": "PRES", "aspect": "IMPERFECTIVE"},
          "explanation": "Derde persoon enkelvoud bij кот."
        },
        {
          "i": 2, "form": "под", "nl": "onder", "lemma": "под",
          "pos": "ADP", "role": "voorzetsel", "features": {},
          "explanation": "Met een plaats gebruikt под hier instrumentalis."
        },
        {
          "i": 3, "form": "столом", "nl": "tafel", "lemma": "стол",
          "pos": "NOUN", "role": "plaatsbepaling",
          "features": {"gender": "M", "number": "SG", "case": "I", "animacy": "INANIMATE"},
          "inflection": {"surface_suffix": "ом", "pattern": "стол → столом", "explanation": "Instrumentalis enkelvoud."},
          "paradigm": {"kind": "noun", "scope": "enkelvoud", "forms": {"N": "стол", "G": "стола", "D": "столу", "A": "стол", "I": "столом", "P": "столе"}},
          "explanation": "De kat zit op een vaste plek: onder de tafel."
        }
      ],
      "relations": [
        {"id": "0-r1", "from": 0, "to": 1, "type": "subject_verb_agreement", "label": "3S", "show_by_default": true, "explanation": "Кот is de derde persoon enkelvoud."},
        {"id": "0-r2", "from": 1, "to": 2, "type": "semantic_context", "label": "plaats", "show_by_default": true, "explanation": "Сидит duidt op een vaste locatie."},
        {"id": "0-r3", "from": 2, "to": 3, "type": "case_government", "label": "I", "show_by_default": true, "depends_on": ["0-r2"], "explanation": "Под heeft bij deze plaatsbetekenis instrumentalis."}
      ]
    }
  ]
}
```

## 6. Ruwe transcriptformaten: **andere** import

Gebruik **tab ② Ruw transcript** voor:

- **SRT**: ondertitels met tijdcodes als `00:00:05,000 --> 00:00:08,000` gevolgd door Russische tekst.
- **VTT**: begint doorgaans met `WEBVTT`; tijdcodes met punten, bijvoorbeeld `00:05.000 --> 00:08.000`.
- **Ruwe tijdcode-JSON**: lijst `[{"start":5.0,"duration":3.0,"text":"Привет!"}]`; `end` kan in plaats van `duration` worden gebruikt.
- **Geplakte tekst**: bijvoorbeeld `0:05 Привет!` of op twee opeenvolgende regels `0:05` en `Привет!`.

Dit zijn **geen** grammatica-JSON's met `schema_version: 7`, `words` en `relations`. Een ruwe import kan voor een nieuwe video nog geen volledige grammaticale uitlegtabellen tonen. De aanbevolen route is: eerst Russisch transcript downloaden, daarna grammatica-JSON door ChatGPT laten maken.

## 7. Technische validatie en veelgemaakte fouten

- `source.video_id` verschilt van de gekozen video → import geweigerd.
- `schema_version` ontbreekt of is geen getal `7` → verkeerd JSON-type.
- `len(tokens) != len(nl) != len(words)` → woorduitlijning fout.
- `words[i].i != i` of `words[i].form != tokens[i]` → woordindex/tekst fout.
- `start >= end`, negatieve of teruglopende beginmomenten → ongeldige tijdcodes.
- Relatie `from/to` buiten indexbereik, of `depends_on` naar ontbrekende relatie → ongeldig.
- Onjuist maar *syntactisch geldig* taalkundig materiaal kan door de validator heen komen: controleer naamvallen, uitgangsveranderingen en betekenispijlen inhoudelijk.

Een bestaand bestand is lokaal te controleren met:

```bash
python3 controleer_russisch_v7.py mijn_grammatica.json
```

De speler gebruikt bij import de ingebouwde `validate_v7()`; het controlescript geeft aanvullende kwaliteitswaarschuwingen. Na een geslaagde import meldt de dialoog expliciet hoeveel zinnen geladen zijn. De video hoeft niet opnieuw in de terminal te worden opgegeven.

## 7. Nieuw in v7.9: woordvolgorde

Bij een zin mag `word_order_note` staan, bijvoorbeeld:

```text
"word_order_note": "Het werkwoord стал staat in deze sprookjeszin voorop om de nieuwe handeling te introduceren. Дед blijft het onderwerp; de accusatief репку duidt het object aan. Тянуть is de infinitief bij стал."
```

De speler toont deze verklaring bij **Zin**. Zonder dit optionele veld toont hij geen verzonnen woordvolgorde-uitleg. Importbestanden zonder dit veld blijven compatibel.


## 8. Inhoudsregel voor zinsuitleg (v7.10)

Gebruik `sentence_note` voor **concrete grammaticale informatie over de zin** en
`word_order_note` voor **de reden van de Russische woordvolgorde**. Vermijd
in beide velden generieke instructies als ‘Naamvallen worden per woord uitgelegd’
of ‘Klik op een Russisch woord’. Die horen in **Hulp** en worden door de speler
niet meer in het zinsvenster weergegeven. De gewone natuurlijke vertaling staat
uitsluitend in `nl_natural`.
