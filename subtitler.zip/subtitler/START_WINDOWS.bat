@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Voer eerst INSTALL_WINDOWS.bat uit.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" app.py
pause
