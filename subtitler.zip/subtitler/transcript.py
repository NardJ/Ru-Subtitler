"""YouTube URL validation and subtitle grouping (no audio downloading)."""
from __future__ import annotations

import re
from urllib.parse import parse_qs, urlparse

TOKEN_RE = re.compile(r"[^\W\d_]+(?:[-’'][^\W\d_]+)*", re.UNICODE)
SENTENCE_END = re.compile(r"[.!?…]+[\"»”’)]*$")


def extract_video_id(url_or_id: str) -> str:
    value = url_or_id.strip()
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", value):
        return value
    parsed = urlparse(value)
    host = (parsed.hostname or "").lower()
    if host in ("youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com"):
        if parsed.path == "/watch":
            video_id = parse_qs(parsed.query).get("v", [""])[0]
        elif parsed.path.startswith(("/shorts/", "/live/", "/embed/")):
            video_id = parsed.path.split("/")[2]
        else:
            raise ValueError("Geen ondersteunde YouTube-video-URL")
    elif host in ("youtu.be", "www.youtu.be"):
        video_id = parsed.path.lstrip("/").split("/")[0]
    else:
        raise ValueError("Voer een YouTube-URL of video-ID in")
    if not re.fullmatch(r"[A-Za-z0-9_-]{11}", video_id):
        raise ValueError("Geen geldige YouTube-video-ID")
    return video_id


def russian_tokens(text: str) -> list[str]:
    # Hidden zero-width characters occur inside Russian words in some copied
    # transcripts; treating them as word breaks produces "гото вит" instead
    # of "готовит" and destroys translation alignment.
    text = text.translate({ord(ch): None for ch in ("\u200b", "\u200c", "\u200d", "\u2060", "\ufeff", "\u00ad")})
    return TOKEN_RE.findall(text)


def fetch_subtitles(video_id: str) -> list[dict]:
    """Fetch manually or automatically created RU captions if publicly accessible."""
    from youtube_transcript_api import YouTubeTranscriptApi

    fetched = YouTubeTranscriptApi().fetch(video_id, languages=["ru", "ru-RU"])
    return fetched.to_raw_data()


def to_segments(snippets: list[dict], max_words: int = 13, max_seconds: float = 8) -> list[dict]:
    """Join caption fragments into readable units with approximate ranges.

    Timestamps supplied by YouTube are not always word-precise. Each joined
    segment extends from the start of its first fragment to the end of its last.
    """
    result: list[dict] = []
    parts: list[str] = []
    start = end = 0.0

    def flush() -> None:
        nonlocal parts
        text = " ".join(parts).strip()
        if text and russian_tokens(text):
            result.append({"id": len(result), "start": round(start, 3),
                           "end": round(max(end, start + .15), 3),
                           "text": text, "tokens": russian_tokens(text)})
        parts = []

    for s in snippets:
        text = str(s.get("text", ""))
        text = text.translate({ord(ch): None for ch in ("\u200b", "\u200c", "\u200d", "\u2060", "\ufeff", "\u00ad")})
        text = re.sub(r"\s+", " ", text).strip()
        if not text or (text.startswith("[") and text.endswith("]")):
            continue
        s_start = float(s.get("start", 0))
        s_end = s_start + max(float(s.get("duration", 0)), .1)
        if parts and s_start - end > 1.5:
            flush()
        if not parts:
            start = s_start
        parts.append(text)
        end = s_end
        combined = " ".join(parts)
        if (SENTENCE_END.search(text) or
            len(russian_tokens(combined)) >= max_words or
            end - start >= max_seconds):
            flush()
    if parts:
        flush()
    return result
