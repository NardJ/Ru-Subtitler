# Russische grammatica + YouTube — versie 7.17

## Nieuw in v7.17: betrouwbaar bij songteksten

Begrenzing op 22 woorden per fragment, tijdregistratie tijdens Codex en markering van geschatte fragmenttijden.

## Nieuw in v7.16: automatische Russische ondertitels

Ook automatisch gegenereerde Russische captions worden geprobeerd met
`--write-auto-subs` en `--remote-components ejs:github`. Beide eerder
problematische covers zijn hiermee in de praktijk gedownload. Controleer bij
gezongen tekst de transcriptkwaliteit voordat je Codex start. De vorige versie
van de speler had nog geen ondersteuning voor deze automatische captions.

## Nieuw in v7.15: pijlen Naamvallen / Alle grammatica

In de onderste RU/NL-balk staat naast **↗ Gram** een keuzelijst **Pijlen:**
met **Naamvallen** (naamval en congruentie) en **Alle grammatica**
(ook onderwerp–werkwoord, verleden-tijdsvormen, infinitieven, vaste
constructies en betekenisgroepen). De keuze blijft opgeslagen. De knop
**↗ Gram** kan alle pijlen nog steeds aan- of uitzetten.

Bij v7-JSON worden alle bestaande relaties in de stand *Alle grammatica*
getekend, ook als Codex ze ooit `show_by_default: false` heeft gegeven.
Geen nieuwe Codex-run nodig voor geïmporteerde video's. Voor nieuwe video's
vraagt de generator explicieter naar complete grammaticale relaties; de
herkende oude batchbestanden blijven bruikbaar en worden niet opnieuw
gedownload of geanalyseerd.

**Updaten vanaf v7.14:** rond een lopende Codex-analyse af, sluit de speler,
kopieer alleen `overlay.js`, `player.html` en `auto_grammar_cli.py` uit de
update-ZIP over de bestaande bestanden en start `.venv/bin/python app.py`.


De YouTube-speler toont Russische zinnen met woord-voor-woord Nederlands, naamvallen,
vervoegingen, grammaticale pijlen en NGDAIP-tabellen. De voorbeeldvideo heeft 28
uitgewerkte zinnen. **Een YouTube-URL op de commandoregel is niet meer nodig.**

## Nieuw in v7.14: automatische YouTube-grammatica (Codex CLI)

Gebruik **⚙ Auto grammatica** om voor een geselecteerde video automatisch een
Russisch VTT-transcript op te halen en via de aangemelde Codex CLI uitgebreide
Nederlandse grammatica als **controleerbaar concept** te genereren. Bestaande
transcripten worden **nooit automatisch** vervangen. Linux-gebruikers installeren
`yt-dlp` en `secretstorage` via `requirements.txt`; npm is niet nodig.

**Lees voor de nieuwe functie eerst `AUTOMATISCHE_GRAMMATICA_V713.md`.**
De onderstaande historische hoofdstukken beschrijven ook de handmatige werkwijze
van eerdere versies; die blijft als terugvaloptie beschikbaar.

## Starten

Pak de ZIP uit. De map heet `russisch_youtube_grammatica` (zonder versienummer).

Linux / macOS (in die map):

```bash
python3 app.py
```

Windows: dubbelklik na installatie via `INSTALL_WINDOWS.bat` op `START_WINDOWS.bat`.

Met `python3 app.py --demo` gebruik je alleen de offline proefspeler zonder audio.

## Nieuw in versie 7.8: transcriptimport

De importdialoog heeft sinds v7.13 drie tabs (waarvan de derde automatisch genereert). **① Grammatica-JSON (aanbevolen)** laat alleen het analyseresultaat van ChatGPT (.json) kiezen en meldt duidelijk of dit bij de geselecteerde video is opgeslagen en hoeveel zinnen geladen zijn. **② Ruw transcript** accepteert .srt, .vtt, tijdcode-.json of geplakte Russische ondertitels. Ruwe import maakt niet vanzelf volledige grammaticale verklaringen. De actuele JSON-specificatie staat in **`FORMAT_GRAMMATICA_JSON_V7.md`**, tevens via de dialoog te downloaden.

## Nieuwe video toevoegen en later terugvinden

1. Klik bovenaan op **＋ Video**, plak een YouTube-URL, geef eventueel een titel.
2. Kies opgeslagen video's in de lijst **Video**; ze blijven beschikbaar na herstart.
3. Een nieuwe video heeft nog geen uitgewerkt transcript. Open de knop **⇧ Transcript** in de onderste RU/NL-balk.
4. Download zelf het **Russische transcript met tijdcodes** als SRT/VTT of kopieer tijdcode + Russische tekst. Geef **het bestand en de bijbehorende YouTube-URL** aan ChatGPT met de vraag een **v7-JSON met Nederlandse woordvertalingen, woordvormen, NGDAIP en grammaticale afhankelijkheden** te maken. Verwijs eventueel naar het voorbeeldbestand `cache/grammar_v7/sF20z8jY1yU.json`.
5. Download het door ChatGPT gemaakte JSON-bestand. Kies in de app de juiste video; klik **⇧ Transcript → ① Grammatica-JSON**, kies het JSON-bestand en druk op **Importeer grammatica-JSON**. Controleer de groene succesmelding.
6. De vertaling en grammatica verschijnen direct en blijven lokaal bewaard. Je hoeft het JSON na herstart niet opnieuw te importeren.

**Belangrijk:** het importvak voor een **ruw** SRT/VTT-transcript maakt niet automatisch gecontroleerde v7-grammatica. Gebruik voor het eindresultaat altijd **① Grammatica-JSON**. Het JSON moet `schema_version: 7`, `segments`, per segment `start`, `end`, `tokens`, `nl`, `words` en `relations` bevatten. Voor de juiste videokoppeling zet je de YouTube-video-ID in `source.video_id`. Onjuiste tijdcodes of woorduitlijning worden afgewezen.

Zie **`FORMAT_GRAMMATICA_JSON_V7.md`** voor de volledige en actuele specificatie (ook te downloaden via de importdialoog).

## Waar worden de video's opgeslagen?

Gegevens blijven *buiten* de map van het programma bewaard. Daarmee blijven ze ook bij
het uitpakken van een volgende programmaversie bestaan.

- Linux: `~/.local/share/russisch_youtube_grammatica/`
- Windows: `%LOCALAPPDATA%\russisch_youtube_grammatica\`
- macOS: `~/Library/Application Support/russisch_youtube_grammatica/`

Daar staan `videos.json` (de videobibliotheek) en `grammar_v7/<video-id>.json`
(de geïmporteerde grammatica). Maak voor een back-up een kopie van deze map.
Eventueel kun je deze locatie instellen via omgevingsvariabele `RUSSIAN_YOUTUBE_DATA_DIR`.
Het aangeleverde voorbeeldbestand staat nog in `cache/grammar_v7/` binnen de applicatie.

## Nieuwe zin-knoppen

- **⏮ Vorige zin**: naar het begin van de vorige zin.
- **↺ Herhaal**: huidige zin opnieuw.
- **⏭ Volgende zin**: naar het begin van de volgende zin.
- Klik op de lege achtergrond van het grammaticale blok: pauzeer/hervat.
- Klik op een Russisch woord: uitleg en, waar beschikbaar, verbuigingstabellen.

De speler gebruikt de officiële YouTube IFrame Player API. Hij probeert niet de
YouTube-botbeveiliging te omzeilen. Sommige video's verbieden insluiten.
De Russische grammaticale annotaties zijn opgesteld op basis van tekst en bestaande
tijdcodes, niet onafhankelijk tegen alle YouTube-audio gecontroleerd.

## Testen

```bash
python3 -m unittest discover -s tests -v
python3 controleer_russisch_v7.py cache/grammar_v7/sF20z8jY1yU.json
```


### Nieuw in v7.9
- **✎ Bewerken** bij de videolijst: naam en YouTube-URL wijzigen zonder opnieuw toe te voegen. Als het YouTube-ID verandert, blijft het oude grammatica-JSON bij het oude ID bewaard; importeer een nieuw bestand voor de nieuwe URL.
- Transcript, Hulp en Video sluiten allemaal met de knop **Sluiten** rechtsboven.
- `word_order_note` in schema v7 is een optionele uitleg over Russische vs. Nederlandse woordvolgorde bij **Zin**.
- Standaard opent `python3 app.py` een **zelfstandig Chrome-appvenster**, zonder tabbladen of adresbalk. Chrome/Chromium wordt via het systeem of Flatpak gezocht. Als geen browser beschikbaar is, verschijnt alleen de lokale URL in de terminal (geen onverwacht tabblad). `--browser default` opent de normale browser, `--browser chrome` opent Chrome als gewone tab, en `--no-browser` start alleen de server. De spelermodus gebruikt nog steeds de YouTube IFrame API; de afzonderlijke v7.14-Codex-workflow kan op aanvraag Russische ondertitels ophalen.

### Nieuw in v7.10: zinsuitleg en woordvolgorde

- **Zin** toont alleen de natuurlijke Nederlandse vertaling, een verklaring van de
  Russische woordvolgorde en eventuele inhoudelijke grammaticale zinsinformatie.
  De generieke instructies zijn verplaatst naar **Hulp**. Standaardteksten uit
  eerder geïmporteerde bestanden worden in het Zin-venster verborgen.
- Vier bijgewerkte importbestanden staan in `voorbeeld_transcripten/` (drie losse
  JSON's) en `cache/grammar_v7/` (het origineel *Бабушка и кот*). De download
  `grammatica_woordvolgorde_alle_videos_v7_10.zip` bevat alle vier bij elkaar.
- Heb je eerder een video-JSON geïmporteerd? **Importeer het vernieuwde JSON opnieuw**
  via **Transcript → Grammatica-JSON**; de bibliotheek bewaart eerder geïmporteerde
  grammatica buiten de programmamap, zodat een update die niet overschrijft.
- Sinds v7.11 opent de speler standaard Chrome met `--app=URL`. Dit is een apart
  browservenster zonder browserwerkbalk (geen in Python ingebedde browser). Het
  verandert niets aan YouTube-transcriptbeperkingen.

### Zinsuitleg v7.11
Klik op een Nederlands woord of de grote knop **Zin** naast **Volgende zin**. De uitleg van de hele zin, met woordvolgorde, wordt midden boven het videobeeld geopend. Ook de uitleg van Russische woorden verschijnt in dit venster, inclusief NGDAIP/M/V/O-tabellen waar beschikbaar. **Sluiten** of **Escape** sluit het venster.

### Chrome als Flatpak (v7.12)

Op Linux kan Chrome via Flatpak geïnstalleerd zijn en daardoor niet voorkomen als
`google-chrome` op PATH. De speler zoekt nu ook naar `com.google.Chrome` en
`org.chromium.Chromium` (plus Chrome Beta/Dev) via `flatpak list --app` en
start met `flatpak run com.google.Chrome --app=http://127.0.0.1:<poort>/`.
Dit opent een Chrome-appvenster zonder adresbalk of tabbladen, ook wanneer een
gewone Chrome-sessie al open staat. Sinds v7.13 kan de speler optioneel Russische VTT-ondertitels ophalen via yt-dlp en Codex-concepten genereren.

Bij problemen met de start: controleer `flatpak list --app` en test vanuit
de terminal `flatpak run com.google.Chrome --app=http://127.0.0.1:<poort>/`
(met de poort die de speler op het scherm toont).
Gebruik `python3 app.py --browser default` uitsluitend als je bewust het normale
browservenster wilt gebruiken.
