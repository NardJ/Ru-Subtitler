#!/usr/bin/env python3
"""YouTube -> Russische VTT -> normalisatie/zinnen -> Codex CLI -> v7-concept.

Onafhankelijke proef: wijzigt de YouTube-speler niet, importeert niets en
kopieert noch exporteert Chrome-cookies. Gebruik alleen met toegestane toegang.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
from time import monotonic
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import textwrap
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from v7_annotations import validate_v7

BASE = Path(__file__).resolve().parent
DEFAULT_URL = "https://www.youtube.com/watch?v=QpQmw2rxxtQ"
VERSION = "e2e-v1.0"  # Bewust ongewijzigd: bestaande geslaagde batches blijven bruikbaar
# Approx. equal-looking Latin glyphs in Cyrillic words; also accented Latin glyphs.
SAFE_LATIN_TO_RU = {"A":"А", "B":"В", "C":"С", "E":"Е", "H":"Н", "K":"К", "M":"М", "O":"О", "P":"Р", "T":"Т", "X":"Х", "Y":"У",
                    "a":"а", "c":"с", "e":"е", "k":"к", "o":"о", "p":"р", "x":"х", "y":"у"}
CYR = re.compile(r"[\u0400-\u052f]")
LATIN = re.compile(r"[A-Za-z\u00c0-\u024f]")
TOKEN_PATTERN = re.compile(r"(?:[^\W_]|[\u0300-\u036f])+(?:[-‑](?:[^\W_]|[\u0300-\u036f])+)*", re.UNICODE)
TIMECODE = re.compile(r"(?:(\d+):)?(\d{2}):(\d{2})\.(\d{3})")
END_SENTENCE = re.compile(r"(?<=[.!?…])\s+(?=[«\"„А-ЯЁ])")
# Never offer Codex a whole song as one grammatical sentence.
# A long cue can also be split; internal timestamps are explicitly approximate.
MAX_WORDS_PER_FRAGMENT = 22
MAX_MERGE_SECONDS = 60.0


def vid_from_url(url: str) -> str:
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", url):
        return url
    u = urlparse(url)
    if u.hostname in ("youtu.be", "www.youtu.be"):
        vid = u.path.strip("/").split("/")[0]
    elif u.hostname in ("youtube.com", "www.youtube.com", "m.youtube.com"):
        vid = parse_qs(u.query).get("v", [None])[0]
        if not vid and u.path.startswith("/shorts/"):
            vid = u.path.split("/")[2]
    else:
        vid = None
    if not vid or not re.fullmatch(r"[A-Za-z0-9_-]{11}", vid):
        raise ValueError("Gebruik een geldige YouTube-URL (of video-ID van 11 tekens)")
    return vid


def stamp_to_float(value: str) -> float:
    m = TIMECODE.fullmatch(value.strip())
    if not m:
        raise ValueError(f"Ongeldige VTT-tijd: {value!r}")
    h, minutes, seconds, ms = m.groups()
    return (int(h or 0)*3600 + int(minutes)*60 + int(seconds) + int(ms)/1000)


def normalize_text(raw: str) -> tuple[str, list[str]]:
    """Keep Russian source intact except HTML entities and safe Latin homoglyphs.

    Does not add accent marks or invent punctuation. Logs any replacements.
    """
    text = html.unescape(raw).replace("\u00a0", " ").replace("\u200b", "")
    text = re.sub(r"<[^>]+>", "", text)
    text = " ".join(text.split())
    notes: list[str] = []
    # Treat non-space word+accent runs, not entire text. Unicode NFD exposes é -> e + acute.
    for match in reversed(list(re.finditer(r"[^\s\.,:;!?«»()\[\]/]+", text))):
        original = match.group()
        if not CYR.search(original):
            continue
        decomposed = unicodedata.normalize("NFD", original)
        fixed = "".join(SAFE_LATIN_TO_RU.get(c, c) for c in decomposed)
        fixed = unicodedata.normalize("NFC", fixed)
        if fixed != original:
            text = text[:match.start()] + fixed + text[match.end():]
            notes.append(f"Latijn/Cyrillisch: {original} → {fixed}")
    text = unicodedata.normalize("NFC", text)
    return text, list(reversed(notes))


@dataclass
class Cue:
    start: float
    end: float
    text: str
    index: int


def parse_vtt(body: str, audit_fixes: list[str] | None = None) -> list[Cue]:
    lines = body.replace("\ufeff", "").splitlines()
    cues: list[Cue] = []
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if "-->" not in line:
            i += 1
            continue
        # Handle optional VTT positioning metadata after timestamp.
        fields = [s.strip().split()[0] for s in line.split("-->")]
        if len(fields) != 2:
            i += 1
            continue
        try:
            start, end = stamp_to_float(fields[0]), stamp_to_float(fields[1])
        except ValueError:
            i += 1
            continue
        i += 1
        parts = []
        while i < len(lines) and lines[i].strip():
            # Accept regular VTT <c> tags and entities.
            parts.append(lines[i].strip())
            i += 1
        text, changes = normalize_text(" ".join(parts))
        if 0 <= start < end and text:
            cues.append(Cue(start, end, text, len(cues)))
            if audit_fixes is not None:
                audit_fixes.extend(f"Cue {len(cues)}: {change}" for change in changes)
        i += 1
    if not cues:
        raise ValueError("Geen bruikbare ondertitels met tijdcodes gevonden in VTT")
    for a, b in zip(cues, cues[1:]):
        if b.start < a.start:
            raise ValueError("VTT-regels hebben niet-oplopende tijdcodes")
    return cues


def is_title(text: str, start: float, video_id: str | None = None) -> bool:
    if video_id not in (None, "QpQmw2rxxtQ"):
        return False
    return start < 8 and bool(re.search(r"(?i)^(?:алексей\s*:\s*семья|.+:\s*семья\s+и\s+родные)", text))


def split_long_piece(text: str) -> list[str]:
    """Bound auto-captions without punctuation at complete token boundaries.

    Retain every source word and the original character order. Split tokens in
    the middle of a cue only when necessary; their times will be estimated.
    """
    matches=list(TOKEN_PATTERN.finditer(text))
    if len(matches) <= MAX_WORDS_PER_FRAGMENT:
        return [text]
    parts=[]
    start=0
    for at in range(MAX_WORDS_PER_FRAGMENT, len(matches), MAX_WORDS_PER_FRAGMENT):
        split_at=matches[at].start()
        parts.append(text[start:split_at].strip())
        start=split_at
    parts.append(text[start:].strip())
    return [p for p in parts if p]


def split_cue(cue: Cue) -> list[dict]:
    sentence_pieces = [x.strip() for x in END_SENTENCE.split(cue.text) if x.strip()]
    pieces = [small for piece in sentence_pieces for small in split_long_piece(piece)]
    if len(pieces) <= 1:
        return [{"start": cue.start, "end": cue.end, "text": cue.text, "cues": [cue.index], "estimated": False}]
    # Character-proportional timing is provisional; signal review for every split.
    lengths = [max(1, len(x)) for x in pieces]
    result = []
    begin = cue.start
    for j, part in enumerate(pieces):
        end = cue.end if j == len(pieces)-1 else round(begin + (cue.end-begin)*lengths[j]/sum(lengths[j:]), 3)
        if end <= begin:
            raise ValueError(f"Te korte VTT-regel om {len(pieces)} fragmenten te timen")
        result.append({"start": round(begin, 3), "end": round(end, 3), "text":part,
                       "cues": [cue.index], "estimated": True})
        begin = end
    return result


def should_join(prev: dict, curr: dict) -> bool:
    gap = curr["start"] - prev["end"]
    if gap < -0.2 or gap > 2.5:
        return False
    # Songs and auto-captions often have no punctuation at all. Never merge
    # 20 consecutive cues into a massive, impractical Codex sentence.
    if len(tokenize(prev["text"])) + len(tokenize(curr["text"])) > MAX_WORDS_PER_FRAGMENT:
        return False
    if curr["end"] - prev["start"] > MAX_MERGE_SECONDS:
        return False
    if re.search(r"[.!?…][»\"]?$", prev["text"]):
        return False
    if prev["text"].endswith(","):
        return True
    # Lowercase continuation is usually a broken sentence across captions.
    first = curr["text"].split()[0].strip("«„\"'(") if curr["text"].split() else ""
    return bool(first) and first[0].islower() and gap <= 2.0


def tokenize(text: str) -> list[str]:
    return TOKEN_PATTERN.findall(text)


def classify(text: str) -> str:
    if re.search(r"[.!?…]$", text.strip()) or re.search(r"[.!?…][»\"]$", text.strip()):
        return "zin"
    if text.count("/"):
        return "woordenschat/alternatieven"
    return "woordgroep of zinsfragment"


def prepare_vtt(vtt: Path, video_id: str | None = None) -> tuple[list[dict], dict]:
    raw = vtt.read_text(encoding="utf-8-sig")
    fixes: list[str] = []
    cues = parse_vtt(raw, fixes)
    title_skips = [cue.text for cue in cues if is_title(cue.text,cue.start,video_id)]
    pieces = [p for cue in cues if not is_title(cue.text,cue.start,video_id) for p in split_cue(cue)]
    output = []
    merge_count = 0
    for p in pieces:
        if output and should_join(output[-1], p):
            prev = output[-1]
            prev["text"] = prev["text"].rstrip() + " " + p["text"].lstrip()
            prev["end"] = p["end"]
            prev["cues"] += p["cues"]
            prev["estimated"] = prev["estimated"] or p["estimated"]
            merge_count += 1
        else:
            output.append(p)
    analysis = []
    for i, p in enumerate(output):
        toks = tokenize(p["text"])
        if not toks:
            raise ValueError(f"Fragment {i+1} heeft geen losse woorden: {p['text']!r}")
        analysis.append({"id": i, "start": p["start"], "end": p["end"], "text":p["text"],
                         "tokens": toks, "kind":classify(p["text"]), "cues":p["cues"],
                         "estimated_times":p["estimated"]})
    # Reconstitute all non-title Russian tokens to check nothing silently disappeared.
    original_tokens = [t for c in cues if not is_title(c.text,c.start,video_id) for t in tokenize(c.text)]
    joined_tokens = [t for s in analysis for t in s["tokens"]]
    if original_tokens != joined_tokens:
        raise ValueError("Woordbehoudcontrole mislukt: zinsindeling heeft woorden veranderd of verloren")
    warnings = []
    if any(len(s["cues"]) > 1 for s in analysis):
        warnings.append("Sommige ondertitelregels zijn samengevoegd; controleer de zinsgrenzen.")
    if any(len(s["tokens"]) >= MAX_WORDS_PER_FRAGMENT for s in analysis):
        warnings.append("Langere automatische ondertitelreeksen zijn begrensd op maximaal "
                        f"{MAX_WORDS_PER_FRAGMENT} woorden per analysefragment; "
                        "een grens kan midden in een grammaticale zin vallen.")
    for s in analysis:
        if LATIN.search(s["text"]) and CYR.search(s["text"]):
            warnings.append(f"Fragment {s['id']+1}: mogelijke gemengde schriften: {s['text'][:100]}")
        if s["estimated_times"]:
            warnings.append(f"Fragment {s['id']+1}: VTT-tijdcode proportioneel gesplitst; controleer synchronisatie")
        if len(s["tokens"]) > 34:
            warnings.append(f"Fragment {s['id']+1}: veel woorden ({len(s['tokens'])}); mogelijk andere indeling gewenst")
    report = {"input_cues":len(cues), "segments":len(analysis), "words":len(joined_tokens),
              "title_skipped":title_skips, "merged":merge_count,
              "estimated_segments":sum(s["estimated_times"] for s in analysis),
              "html_nbsp_count":raw.count("&nbsp;") + raw.count("\u00a0"),
              "warnings":warnings, "fixes":fixes}
    return analysis, report


def which_codex(requested: str) -> str:
    if requested != "codex":
        p = Path(requested).expanduser()
        if p.is_file() and os.access(p, os.X_OK):
            return str(p.resolve())
        found = shutil.which(requested)
        if found:
            return found
        raise RuntimeError(f"Codex CLI niet gevonden: {requested}")
    found = shutil.which("codex")
    if found:
        return found
    for p in (Path.home()/".local/bin/codex", Path.home()/"bin/codex"):
        if p.is_file() and os.access(p, os.X_OK):
            return str(p)
    raise RuntimeError("Codex CLI niet gevonden. Controleer met: ~/.local/bin/codex --version")


def yt_download(url: str, dest: Path, *, refresh: bool) -> Path:
    videoid = vid_from_url(url)
    result = dest/f"{videoid}.ru.vtt"
    if result.is_file() and not refresh:
        print(f"Bestaand VTT hergebruikt: {result}", flush=True)
        return result
    dest.mkdir(parents=True,exist_ok=True)
    # Only existing Chrome Flatpak profile; no cookie file is created or shared.
    profile = Path.home()/".var/app/com.google.Chrome/"
    print("Russische VTT van YouTube ophalen via yt-dlp (alleen ondertitels)...",flush=True)
    # Download to an isolated temporary folder: an old VTT is never mistaken
    # for a fresh success and never overwritten if YouTube blocks a refresh.
    with tempfile.TemporaryDirectory(prefix="vtt_download_",dir=dest) as td:
        tmp_dir=Path(td)
        fresh=tmp_dir/f"{videoid}.ru.vtt"
        # v7.16: also request YouTube's automatically generated Russian captions.
        # Some music videos expose captions to Chrome but not as manual subtitles.
        # EJS is needed for some contemporary YouTube JavaScript challenges;
        # yt-dlp fetches the official EJS solver distribution from GitHub on demand.
        # We use --skip-download: video/audio is never downloaded.
        cmd = [sys.executable, "-m", "yt_dlp", "--no-playlist",
               "--cookies-from-browser", f"chrome:{profile}",
               "--remote-components", "ejs:github",
               "--ignore-no-formats-error", "--write-subs", "--write-auto-subs",
               "--sub-langs", "ru", "--sub-format", "vtt", "--skip-download",
               "-o", str(tmp_dir/"%(id)s.%(ext)s"), url]
        try:
            done = subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=240)
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError("yt-dlp liep vast (timeout 240 seconden)") from exc
        (dest/"yt_dlp_log.txt").write_text(done.stdout,encoding="utf-8")
        if done.returncode != 0 or not fresh.exists() or fresh.stat().st_size < 50:
            details = done.stdout or ""
            if "There are no subtitles for the requested languages" in details:
                raise RuntimeError(
                    "Geen Russische YouTube-ondertitels gevonden, ook geen automatische. "
                    "Bekijk yt_dlp_log.txt. Je kunt het transcript handmatig importeren "
                    "via Transcript → ② Ruw transcript.")
            if "secretstorage" in details.lower() and (
                    "not installed" in details.lower() or "no module named" in details.lower()):
                raise RuntimeError(
                    "Chrome-cookies zijn niet leesbaar: installeer secretstorage in de "
                    "Python-omgeving van de speler en probeer opnieuw; zie yt_dlp_log.txt.")
            raise RuntimeError(
                "Russische VTT-download mislukt; zie yt_dlp_log.txt. "
                "Controleer de yt-dlp-waarschuwingen en of Russische ondertitels "
                "voor deze video beschikbaar zijn.")
        # Reject empty/non-Russian files before publishing them as successful.
        try:
            test=parse_vtt(fresh.read_text(encoding="utf-8-sig"))
            if not any(CYR.search(c.text) for c in test):
                raise ValueError("Er staan geen Russische letters in het VTT")
        except ValueError as exc:
            raise RuntimeError(f"Gedownload VTT is niet bruikbaar: {exc}") from exc
        fresh.replace(result)
    print(f"Download gelukt: {result}",flush=True)
    return result


def json_schema() -> dict:
    string={"type":"string"}
    nullable={"type":["string","null"]}
    def obj(props: dict, allow_null: bool=False) -> dict:
        form={"type":"object", "properties":props, "required":list(props), "additionalProperties":False}
        return {"anyOf":[form,{"type":"null"}]} if allow_null else form
    f=obj({k:nullable for k in ("case","gender","number","person","tense","aspect","animacy","mood")})
    inf=obj({"surface_suffix":nullable,"pattern":string,"explanation":string,"type":nullable},True)
    forms=obj({x:string for x in "NGDAIP"})
    row=obj({x:string for x in "MFN"})
    paradigm=obj({"kind":string,"scope":string,"forms":forms,"rows":{"type":"array","items":row}},True)
    word=obj({"i":{"type":"integer"},"form":string,"nl":string,"lemma":string,"pos":string,
              "role":string,"explanation":string,"features":f,"inflection":inf,"paradigm":paradigm})
    rel=obj({"id":string,"from":{"type":"integer"},"to":{"type":"integer"},"type":string,
             "label":string,"show_by_default":{"type":"boolean"},
             "depends_on":{"type":"array","items":string},"explanation":string})
    seg=obj({"id":{"type":"integer"},"start":{"type":"number"},"end":{"type":"number"},
             "text":string,"tokens":{"type":"array","items":string},
             "nl":{"type":"array","items":string},"nl_natural":string,
             "sentence_note":string,"word_order_note":string,
             "words":{"type":"array","items":word},"relations":{"type":"array","items":rel}})
    return obj({"segments":{"type":"array","items":seg}})


def legacy_codex_prompt(batch: list[dict], video_id: str = "QpQmw2rxxtQ") -> str:
    source=[{key:s[key] for key in ("id","start","end","text","tokens","kind")} for s in batch]
    prompt = textwrap.dedent("""\
    Je bent een specialist Russische grammatica voor een Nederlandse leerspeler.
    Analyseer ALLE Russische bronfragmenten hieronder. Lever uitsluitend JSON dat voldoet
    aan de opgegeven schema. Verzin nooit gesproken woorden, namen, zinnen of tijdcodes.

    De bron is een transcript van een Russische B1-les, inclusief LOSSE woordgroepen,
    titelwoorden en slash-alternatieven. Behandel een woordgroep als woordgroep!
    Leg geen niet-bestaand onderwerp/werkwoord of zinsvolgorde uit. Gebruik bij
    losse fragmenten een korte, duidelijke uitleg van het patroon.

    EISEN:
    - Kopieer id/start/end/text/tokens PRECIES; wijzig niets aan Russische woorden.
    - Geef voor elk token precies één letterlijke NL-vertaling, behoud woordvolgorde.
      words[i].nl moet exact nl[i] zijn. nl_natural als natuurlijk Nederlandse zin/woordgroep.
    - Schrijf inhoudelijk correct Nederlands voor lemma, case, geslacht, tijd, aspect,
      grammaticale rol, waarom een specifieke vorm gebruikt wordt, en woordvolgorde.
      Naamvallen N G D A I P; geslacht M F N; aantal SG PL; onbekend = null.
    - Leg dubbelzinnigheden uit. Behandel bv leeftijd met D, werken als I wanneer
      een beroepsnaam zonder voorzetsel volgt; na bepaalde voorzetsels verschilt
      naamval per betekenis. Dit zijn algemene didactische principes, GEEN
      antwoordsleutel voor specifieke fragmenten. Bepaal het juiste geval zelfstandig.
    - Bij NOUN en PROPN volledige NGDAIP-enkelvoudstabellen, `kind: noun`, `forms`
      met zes ingevulde strings, `rows: []`. Bij niet-verbuigbare woorden: leg dat uit.
    - Bij ADJ, DET en bezittelijke voornaamwoorden: waar passend M/F/N-vervoeging in zes
      NGDAIP-rijen, `kind: agreement`, lege forms-strings. Negeer uitzonderingen niet.
    - Bij andere pos mag paradigm null zijn. Alle overige niet-toepasselijke features null.
    - inflection=null indien geen aantoonbare zichtbare uitgang. Anders geef
      `surface_suffix` als ECHT suffix in zichtbaar token, met `pattern`, `explanation`;
      `type=null`. Verzin geen morfeemgrenzen of oppervlakkige uitgangen.
    - Neem relevante pijlen van type case_government, agreement, past_gender,
      subject_verb_agreement en semantic_context, met korte labels, specifieke
      oorzaakverklaringen en unieke ids. Wees selectief met zichtbare pijlen:
      maximaal ca. drie per zin standaard tonen, de rest in detail bewaren.
    - Behandel slash-alternatieven (zoals 'родиться/он родился') als aparte tokens
      zonder de tussenliggende '/' als grammaticaal woord te analyseren.
    - Controleer je output intern: alle paradigmatabellen, alle Nederlandse betekenissen,
      alle naamvallen en indexen. Geen generieke spelerinstructies in sentence_note.
    - Geen markdown; alleen het uitvoer-JSON-object.

    Russische invoer:
    """)
    if video_id != "QpQmw2rxxtQ":
        prompt = prompt.replace(
            "De bron is een transcript van een Russische B1-les, inclusief LOSSE woordgroepen,",
            "De bron is een transcript van een Russische video, mogelijk met LOSSE woordgroepen,")
    return prompt + json.dumps(source,ensure_ascii=False,indent=2)


def codex_prompt(batch: list[dict], video_id: str = "QpQmw2rxxtQ") -> str:
    """v7.15 prompt: generate complete links; the overlay decides visibility.

    Older stored batches keep their own checksum via legacy_codex_prompt.
    """
    prompt=legacy_codex_prompt(batch,video_id)
    prompt=prompt.replace(
        "Wees selectief met zichtbare pijlen:\n  maximaal ca. drie per zin standaard tonen, de rest in detail bewaren.",
        "Maak voor ELK belangrijk syntactisch verband een relatie, ook als veel pijlen nodig "
        "zijn. Geef elk expliciet onderwerp een subject_verb_agreement-relatie naar "
        "ELK bijbehorend vervoegd werkwoord, ook wanneer meerdere werkwoorden het "
        "onderwerp delen. Voeg bij verleden tijd waar relevant past_gender toe. "
        "Leg werkwoord + infinitief, vaste werkwoord-voorzetselcombinaties, "
        "betekenisgroepen en naamvalsoorzaken vast als afzonderlijke relaties; "
        "verbind voorzetsel met naamwoord en waar zinvol werkwoord met voorzetsel. "
        "Gebruik beknopte pijllabels (bij voorkeur minder dan 20 tekens). "
        "De speler bepaalt zelf welke relaties zichtbaar zijn; "
        "show_by_default is uitsluitend een compatibiliteitsveld."
    )
    return prompt


# Canonieke waarden worden rechtstreeks door de v7.12-speler vertaald.
# Normaliseer achteraf: raak de Codex-prompt, versie en batch-hashes niet aan,
# zodat alle succesvolle v1.0/v1.1-batches uit cache bruikbaar blijven.
FEATURE_CODES = {
    "animacy": {
        "animate": "ANIMATE", "anim": "ANIMATE", "bezield": "ANIMATE",
        "inanimate": "INANIMATE", "inan": "INANIMATE", "onbezield": "INANIMATE",
        "levenloos": "INANIMATE", "niet-levend": "INANIMATE",
    },
    "tense": {
        "pres": "PRES", "prs": "PRES", "present": "PRES", "tegenwoordig": "PRES",
        "tegenwoordige tijd": "PRES", "past": "PAST", "pst": "PAST", "pret": "PAST", "preterite": "PAST", "verleden": "PAST",
        "verleden tijd": "PAST", "fut": "FUT", "future": "FUT", "toekomst": "FUT",
        "toekomend": "FUT", "toekomende tijd": "FUT", "toekomstig": "FUT",
        "toekomstige tijd": "FUT", "toekomsttijd": "FUT", "future tense": "FUT",
    },
    "aspect": {
        "imperfective": "IMPERFECTIVE", "ipfv": "IMPERFECTIVE", "impf": "IMPERFECTIVE",
        "imperfectief": "IMPERFECTIVE", "onvoltooid": "IMPERFECTIVE",
        "perfective": "PERFECTIVE", "pfv": "PERFECTIVE",
        "perfectief": "PERFECTIVE", "voltooid": "PERFECTIVE",
    },
    "mood": {
        "ind": "IND", "indicative": "IND", "indicatief": "IND",
        "aantonende wijs": "IND", "aantonend": "IND",
        "inf": "INF", "infinitief": "INF", "infinitive": "INF",
        "imperative": "IMP", "imperatief": "IMP", "imp": "IMP",
    },
}


def normalize_feature_codes(w: dict) -> None:
    """Zet vrij gegenereerde labels om naar vaste, voor de speler leesbare codes."""
    f=w["features"]
    for key, table in FEATURE_CODES.items():
        value=f.get(key)
        if value is None:
            continue
        if not isinstance(value,str):
            raise ValueError(f"Niet-tekstuele waarde voor {key} bij {w.get('form')!r}: {value!r}")
        canonical=table.get(value.casefold().strip())
        if canonical is None:
            raise ValueError(f"Onbekende {key}-waarde bij {w.get('form')!r}: {value!r}")
        f[key]=canonical
    # V1.1-Codex gaf bij een aantal losse infinitieven alleen aspect.
    # Vul uitsluitend aantoonbare infinitieven aan (nooit een vervoegde vorm).
    if (w.get("pos")=="VERB" and "mood" not in f and "tense" not in f
            and re.search(r"(?:ть|ти|чь|ться)$",w.get("form", "").casefold())):
        f["mood"]="INF"


def normalize_codex_segment(segment: dict) -> dict:
    s=json.loads(json.dumps(segment,ensure_ascii=False))
    for w in s["words"]:
        w["features"]={k:v for k,v in w["features"].items() if v is not None}
        normalize_feature_codes(w)
        infl=w.get("inflection")
        if infl is None or infl.get("surface_suffix") is None:
            w.pop("inflection",None)
        else:
            infl.pop("type",None) if infl.get("type") is None else None
        p=w.get("paradigm")
        if p is None:
            w.pop("paradigm",None)
        elif p.get("kind")=="noun":
            p.pop("rows",None)
        elif p.get("kind")=="agreement":
            p.pop("forms",None)
    # v7.15: Codex never determines which links the user sees.
    # Keep a deterministic legacy flag for older player versions only.
    for rel in s["relations"]:
        rel["show_by_default"] = rel.get("type") in (
            "case_government", "agreement", "preposition_case", "adjective_noun_agreement")
    return s


def suffix_is_visible(form: str, suffix: str) -> bool:
    """Verify a suffix without falsely rejecting an omitted acute stress mark.

    We only ignore combining Russian stress U+0301/U+0341. We do NOT equate
    е with ё, remove dashes, or accept a morpheme inside the word as a suffix.
    """
    if not isinstance(suffix, str) or not suffix.strip():
        return False
    def no_stress(value: str) -> str:
        decomposed = unicodedata.normalize("NFD", value)
        return unicodedata.normalize("NFC", "".join(
            c for c in decomposed if c not in ("\u0301", "\u0341")
        )).casefold()
    return no_stress(form).endswith(no_stress(suffix))


def correct_suffix_displays(segments: list[dict]) -> list[str]:
    """Repair *presentation* of a demonstrably invalid visible suffix locally.

    A suffix such as -ет in старается is a real person ending followed by -ся,
    but surface_suffix must end at the very end of the printed word. Extend it
    with the observed reflexive postfix; never fabricate a new surface form.
    If no literal suffix can be derived, omit only the inflection display and
    mark the word for human review. Never change Russian text, features,
    translations, paradigms or grammatical relations.
    """
    changes = []
    for segment in segments:
        for i, word in enumerate(segment.get("words", [])):
            inf = word.get("inflection")
            if not isinstance(inf, dict):
                continue
            form, suffix = word.get("form"), inf.get("surface_suffix")
            if not isinstance(form, str) or not isinstance(suffix, str) or not suffix.strip():
                continue
            if suffix_is_visible(form, suffix):
                continue
            for reflexive in ("ся", "сь"):
                if suffix_is_visible(form, suffix + reflexive):
                    inf["surface_suffix"] = suffix + reflexive
                    changes.append(
                        f"Fragment {segment['id']+1}, woord {i+1} ({form}): "
                        f"zichtbaar uiteinde {suffix!r} → {(suffix + reflexive)!r} "
                        f"(inclusief wederkerend postfix)"
                    )
                    break
            else:
                # There is no evidence for any replacement suffix. Dropping an
                # unreliable display is safer than inventing morphology or
                # spending multiple expensive AI calls on a single suffix.
                word["inflection"] = None
                note = "Suffixaanduiding uit de automatische analyse weggelaten; handmatig controleren."
                if note not in word.get("explanation", ""):
                    word["explanation"] = (word.get("explanation", "").rstrip() + " " + note).strip()
                changes.append(
                    f"Fragment {segment['id']+1}, woord {i+1} ({form}): "
                    f"onjuist suffix {suffix!r} weggelaten; handmatige controle nodig"
                )
    return changes


def recover_rejected_batch(directory: Path, prefix: str, digest: str,
                           chunk: list[dict], vid: str) -> tuple[list[dict], list[str], Path] | None:
    """Reuse a prior full rejected response only after strict revalidation.

    The prompt and cache digests remain unchanged. A saved response may include
    another previously unseen error; then it is rejected and the normal Codex
    generation path is used instead.
    """
    if not directory.is_dir():
        return None
    paths = sorted(directory.glob(f"{prefix}{digest}_poging*.json"),
                   key=lambda path: (path.stat().st_mtime_ns, path.name), reverse=True)
    for path in paths:
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
            candidate = value["segments"]
            if not isinstance(candidate, list):
                continue
            changes = correct_suffix_displays(candidate)
            validate_analysis(candidate, chunk, vid)
            return candidate, changes, path
        except (ValueError, TypeError, KeyError, IndexError, OSError, json.JSONDecodeError):
            continue
    return None


def validate_analysis(segments: list[dict], source: list[dict], vid: str, title: str = "Алексей: семья и родные") -> dict:
    if len(segments) != len(source):
        raise ValueError(f"Codex leverde {len(segments)} zinnen terwijl {len(source)} zijn gevraagd")
    checked=[]
    for result, orig in zip(segments,source):
        for field in ("id","start","end","text","tokens"):
            if result.get(field)!=orig[field]:
                raise ValueError(f"Zin {orig['id']}: bronveld {field} verschilt of is onjuist")
        if not isinstance(result.get("nl_natural"),str) or not result["nl_natural"].strip():
            raise ValueError(f"Zin {orig['id']}: ontbrekende natuurlijke NL-vertaling")
        if not isinstance(result.get("sentence_note"),str) or not result["sentence_note"].strip():
            raise ValueError(f"Zin {orig['id']}: ontbrekende grammaticale uitleg")
        if not isinstance(result.get("word_order_note"),str) or not result["word_order_note"].strip():
            raise ValueError(f"Zin {orig['id']}: ontbrekende woordvolgorde-uitleg")
        s=normalize_codex_segment(result)
        if (not isinstance(s.get("words"),list) or not isinstance(s.get("nl"),list)
                or len(s["words"]) != len(orig["tokens"]) or len(s["nl"]) != len(orig["tokens"])):
            raise ValueError(f"Zin {orig['id']}: onjuiste woorduitlijning")
        for i,w in enumerate(s["words"]):
            if not w.get("lemma") or not w.get("pos") or not w.get("explanation"):
                raise ValueError(f"Zin {orig['id']} woord {i}: lemma/woordsoort/uitleg ontbreekt")
            if w.get("nl")!=s["nl"][i]:
                raise ValueError(f"Zin {orig['id']} woord {i}: letterlijke NL-vertaling verschilt")
            features=w.get("features",{})
            for k, table in FEATURE_CODES.items():
                if features.get(k) is not None and features[k] not in set(table.values()):
                    raise ValueError(f"Zin {orig['id']} woord {i}: ongeldige {k}-code {features[k]!r}")
            if features.get("case") not in (None,"N","G","D","A","I","P"):
                raise ValueError(f"Zin {orig['id']} woord {i}: ongeldige naamval")
            if features.get("gender") not in (None,"M","F","N"):
                raise ValueError(f"Zin {orig['id']} woord {i}: ongeldig geslacht")
            if w["pos"] in ("NOUN","PROPN"):
                p=w.get("paradigm")
                if not p or p.get("kind")!="noun" or not all(p.get("forms",{}).get(k) for k in "NGDAIP"):
                    raise ValueError(f"Zin {orig['id']} woord {i}: NGDAIP-tabel ontbreekt")
            if w.get("paradigm",{}).get("kind")=="agreement" and len(w["paradigm"].get("rows",[]))!=6:
                raise ValueError(f"Zin {orig['id']} woord {i}: M/V/O-tabel onvolledig")
            infl=w.get("inflection")
            if infl and not suffix_is_visible(w["form"],infl["surface_suffix"]):
                raise ValueError(
                    f"Zin {orig['id']} woord {i}: suffix komt niet letterlijk voor "
                    f"(woord {w['form']!r}, gerapporteerd suffix {infl['surface_suffix']!r})"
                )
        checked.append(s)
    root={"schema_version":7,"source":{"video_id":vid,"youtube_url":f"https://www.youtube.com/watch?v={vid}","title":title,"language":"ru"},
          "status":"Codex-CONTROLEPROEF — grammatica nog NIET taalkundig goedgekeurd", "segments":checked}
    validate_v7(root)
    return root


def json_dump_atomic(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w",encoding="utf-8",dir=path.parent,delete=False,suffix=".tmp") as f:
        json.dump(obj,f,ensure_ascii=False,indent=2)
        tmp=Path(f.name)
    tmp.replace(path)


def call_codex(batch: list[dict], executable: str, workdir: Path, timeout: int,
               repair_context: str | None = None, video_id: str = "QpQmw2rxxtQ",
               log_tag: str | None = None) -> list[dict]:
    prompt=codex_prompt(batch, video_id)
    if repair_context:
        prompt += (
            "\n\nHERSTELPROEF: Je eerdere uitvoer is AFGEKEURD wegens deze validatiefout:\n"
            + repair_context
            + "\nGenereer ALLEEN de meegestuurde bronfragmenten opnieuw, met identieke "
              "id/start/end/text/tokens. Als een grammaticaal suffix niet echt op "
              "het eind van de zichtbare woordvorm staat, geef inflection=null "
              "of corrigeer suffix/patroon/uitleg inhoudelijk. Verzin geen "
              "woordvormen. Controleer het volledige antwoord.\n"
        )
    with tempfile.TemporaryDirectory(prefix="codex_ru_") as d:
        root=Path(d)
        schema=root/"schema.json"
        json_dump_atomic(schema,json_schema())
        output=root/"codex_answer.json"
        env=os.environ.copy()
        for key in ("OPENAI_API_KEY","CODEX_API_KEY","OPENAI_BASE_URL"):
            env.pop(key,None)
        args=[executable,"exec","--skip-git-repo-check","--sandbox","read-only",
              "--output-schema",str(schema),"--output-last-message",str(output),"-"]
        try:
            proc=subprocess.run(args,input=prompt,text=True,encoding="utf-8",
                                stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,cwd=root,timeout=timeout)
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError(f"Codex time-out na {timeout}s") from exc
        # Preserve diagnostics without dumping browser cookies or auth credentials.
        # Concurrente Codex-processen mogen elkaars foutlogs niet overschrijven.
        log=workdir/(f"codex_log_{log_tag}.txt" if log_tag else "codex_laatste_log.txt")
        log.write_text((proc.stdout or "")[-10000:]+"\n---- STDERR ----\n"+(proc.stderr or "")[-10000:],encoding="utf-8")
        if proc.returncode:
            raise RuntimeError(f"Codex CLI afgebroken (exit {proc.returncode}); zie {log}")
        if not output.exists():
            raise RuntimeError(f"Codex maakte geen JSON-output; zie {log}")
        try:
            answer=json.loads(output.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Codex gaf ongeldig JSON; zie {log}") from exc
        if not isinstance(answer,dict) or not isinstance(answer.get("segments"),list):
            raise RuntimeError("Codex gaf geen segments[] terug")
        return answer["segments"]


def write_report(path: Path, prep: dict, analyzed: list[dict], total: int, *, partial: bool, vid: str) -> None:
    lines=["# YouTube → Codex: proefrapport", "", f"Video: https://www.youtube.com/watch?v={vid}", "",
           f"VTT-fragmenten: **{prep['input_cues']}**",f"Genormaliseerde analysefragmenten: **{prep['segments']}**",
           f"Totaal Russische woorden: **{prep['words']}**",f"Verwerkte zinnen/woordgroepen: **{len(analyzed)}/{total}**",
           f"Samengevoegde cue-overgangen: **{prep['merged']}**",f"Tijdcodes geschat bij: **{prep['estimated_segments']}** fragmenten",
           f"Overgeslagen videotitel: **{', '.join(prep['title_skipped']) if prep['title_skipped'] else 'geen'}**",
           "", "**STATUS: CONCEPT — NIET TAALKUNDIG GOEDGEKEURD**",
           "", "Dit rapport bevestigt de structuur, maar is geen onafhankelijke toets op grammaticale juistheid.",
           "De video is niet gedownload, alleen het Russische transcript.", ""]
    if partial:
        lines.append("**DEELPROEF**: niet alle zinnen geanalyseerd. Geen volwaardig transcript voor de gehele video.")
        lines.append("")
    if prep["fixes"]:
        lines += ["## Unicode-normalisaties", *["- "+change for change in prep["fixes"]], ""]
    if prep["warnings"]:
        lines.append("## Punten voor handmatige transcriptcontrole")
        lines.extend("- "+x for x in prep["warnings"])
        lines.append("")
    lines.append("## Eerste analyses om gericht te controleren")
    for s in analyzed[:12]:
        lines.append(f"- {s['start']:.2f}s — {s['text']} — {s['nl_natural']}")
    lines.extend(["", "## Grammaticale review", "", "Controleer met name naamvalsgestuurde patronen, aspect, eigennaamvormen, NGDAIP/MVO-tabellen, en of woordgroepen niet als volledige zinnen worden uitgelegd.", ""])
    path.write_text("\n".join(lines),encoding="utf-8")


def print_preview(root: Path, prepared: list[dict], info: dict) -> None:
    json_dump_atomic(root/"genormaliseerde_zinnen.json",{"version":VERSION,"segments":prepared,"audit":info})
    lines=["# Genormaliseerde Russische ondertitels (nog geen AI-analyse)", "",
           f"Oorspronkelijke VTT-regels: {info['input_cues']}",f"Analysefragmenten: {len(prepared)}",
           f"Russische tokens: {info['words']}",f"Samengevoegde regels: {info['merged']}",
           f"Geschatte tijdcodes: {info['estimated_segments']}", ""]
    if info["title_skipped"]:
        lines += ["Videotitel overgeslagen uit de grammatica-analyse: "+", ".join(info["title_skipped"]),""]
    for s in prepared:
        lines.append(f"- **{s['id']:02d} [{s['start']:.2f}–{s['end']:.2f}]** ({s['kind']}): {s['text']}")
    if info["warnings"]:
        lines += ["", "## Aandachtspunten", *["- "+w for w in info["warnings"]]]
    if info["fixes"]:
        lines += ["", "## Automatisch herstelde tekens", *["- "+w for w in info["fixes"]]]
    (root/"zinnenoverzicht.md").write_text("\n".join(lines)+"\n",encoding="utf-8")


# Machine-readable status events allow the local player to show *completed* batches.
# The human-readable batch messages remain available for standalone use.
AUTO_PROGRESS_PREFIX = "@@AUTO_PROGRESS@@"


def report_progress(stage: str, **fields: object) -> None:
    print(AUTO_PROGRESS_PREFIX + json.dumps({"stage": stage, **fields}, ensure_ascii=False), flush=True)


def run(args: argparse.Namespace) -> int:
    vid=vid_from_url(args.url)
    out=args.output_dir.resolve()/vid
    out.mkdir(parents=True,exist_ok=True)
    if args.from_vtt:
        source_vtt=args.from_vtt.expanduser().resolve()
        if not source_vtt.is_file():
            raise ValueError(f"VTT niet gevonden: {source_vtt}")
        dest=out/f"{vid}.ru.vtt"
        if source_vtt != dest:
            shutil.copyfile(source_vtt,dest)
        vtt=dest
        print(f"Bestaand VTT gebruikt: {source_vtt}",flush=True)
    else:
        vtt=yt_download(args.url,out,refresh=args.refresh)
    prepared,info=prepare_vtt(vtt,video_id=vid)
    print_preview(out,prepared,info)
    report_progress("prepared", fragments=len(prepared), input_cues=info["input_cues"])
    print(f"Voorbereid: {info['input_cues']} VTT-regels → {len(prepared)} grammaticafragmenten ({info['words']} woorden)")
    print("Zinnenoverzicht:",out/"zinnenoverzicht.md")
    if args.prepare:
        print("Alleen voorbereid. Start de AI-proef met --run. Geen AI-kosten/limieten gebruikt.")
        return 0
    executable=which_codex(args.codex)
    if args.limit < 0:
        raise ValueError("--limit moet >= 0 zijn")
    if args.chunk_size < 1 or args.chunk_size > 10:
        raise ValueError("--chunk-size moet tussen 1 en 10 liggen")
    if not 0 <= getattr(args,"max_repairs",2) <= 5:
        raise ValueError("--max-repairs moet tussen 0 en 5 liggen")
    subset=prepared[:args.limit] if args.limit else prepared
    cache_dir=out/"codex_batches"
    cache_dir.mkdir(exist_ok=True)
    all_segments=[]
    repair_log=[]
    suffix_log=[]
    total_chunks=(len(subset)+args.chunk_size-1)//args.chunk_size
    report_progress("batches_ready", completed=0, total=total_chunks, cached=0)
    reused_chunks=0
    # Onafhankelijke batches hebben geen gedeelde context. Alleen wanneer er
    # minimaal drie batches zijn, loont het om parallelle CLI-processen te starten.
    # Laat de bestaande sequentiële route intact voor korte video's en legacy-tests.
    parallelism=getattr(args, "parallel", 3)
    if not 1 <= parallelism <= 3:
        raise ValueError("--parallel moet tussen 1 en 3 liggen")
    run_parallel=parallelism > 1 and total_chunks >= 3
    if run_parallel:
        effective_workers=min(parallelism,total_chunks)
        print(f"Versnelde analyse: {total_chunks} onafhankelijke batches, "
              f"maximaal {effective_workers} gelijktijdige Codex-processen.", flush=True)
        report_progress("parallel_ready", completed=0, total=total_chunks,
                        cached=0, workers=effective_workers, active=[])
        lock=Lock()
        state={"completed":0,"cached":0,"active":set()}
        results={}
        errors=[]
        all_repair_logs=[]
        all_suffix_logs=[]
        started_at=monotonic()

        def emit_parallel(stage: str, idx: int, **extra: object) -> None:
            with lock:
                completed=state["completed"]
                cached_count=state["cached"]
                active=sorted(state["active"])
                report_progress(stage, completed=completed, total=total_chunks,
                                current=idx, cached=cached_count, active=active,
                                workers=effective_workers, **extra)

        def message(line: str) -> None:
            with lock:
                print(line,flush=True)

        def analyze_batch(idx: int, chunk: list[dict]) -> tuple[list[dict], bool, list[str], list[str]]:
            batch_started=monotonic()
            prefix=f"{chunk[0]['id']:04d}-{chunk[-1]['id']:04d}_"
            serialized=VERSION+json.dumps(chunk,ensure_ascii=False,sort_keys=True)
            digest=hashlib.sha256((serialized+codex_prompt(chunk,vid)).encode()).hexdigest()[:16]
            cached=cache_dir/f"{prefix}{digest}.json"
            legacy_digest=hashlib.sha256((serialized+legacy_codex_prompt(chunk,vid)).encode()).hexdigest()[:16]
            old_cached=cache_dir/f"{prefix}{legacy_digest}.json"
            if not cached.exists() and old_cached.exists() and not args.retry:
                cached=old_cached
            is_cached=cached.exists() and not args.retry
            recovered=None if (is_cached or args.retry) else recover_rejected_batch(
                out/"afgekeurde_batches",prefix,digest,chunk,vid)
            reused=bool(is_cached or recovered)
            with lock:
                state["active"].add(idx)
            emit_parallel("batch_started",idx,from_cache=reused)
            local_suffix=[]
            local_repair=[]
            if is_cached:
                message(f"Batch {idx}/{total_chunks} uit cache: {cached.name}")
                candidate=json.loads(cached.read_text(encoding="utf-8"))["segments"]
                validate_analysis(candidate,chunk,vid)
            elif recovered is not None:
                candidate,fixes,rejected_path=recovered
                local_suffix.extend(fixes)
                json_dump_atomic(cached,{"segments":candidate})
                message(f"Batch {idx}/{total_chunks} lokaal hersteld uit {rejected_path.name} (zonder Codex).")
                for fix in fixes:
                    message(f"  Batch {idx}: {fix}")
            else:
                message(f"Batch {idx}/{total_chunks} via Codex: fragmenten "
                        f"{chunk[0]['id']+1}–{chunk[-1]['id']+1}...")
                candidate=call_codex(chunk,executable,out,args.timeout,
                                     video_id=vid,log_tag=f"batch_{idx:02d}")
                max_repairs=getattr(args,"max_repairs",2)
                for repair_nr in range(max_repairs+1):
                    fixes=correct_suffix_displays(candidate)
                    local_suffix.extend(fixes)
                    for fix in fixes:
                        message(f"  Batch {idx}, lokaal gecorrigeerd: {fix}")
                    try:
                        validate_analysis(candidate,chunk,vid)
                        break
                    except (ValueError,KeyError,TypeError,IndexError) as exc:
                        reason=str(exc)
                        rejected=out/"afgekeurde_batches"/(
                            f"{chunk[0]['id']:04d}-{chunk[-1]['id']:04d}_{digest}_poging{repair_nr+1}.json")
                        json_dump_atomic(rejected,{"validation_error":reason,"segments":candidate})
                        message(f"  Batch {idx}, Codex-uitvoer afgekeurd: {reason}; bewaard in {rejected}")
                        if repair_nr >= max_repairs:
                            raise ValueError(f"Batch {idx} blijft ongeldig na {max_repairs} herstelpogingen; zie {rejected}") from exc
                        emit_parallel("repairing",idx,repair=repair_nr+1)
                        match=re.search(r"Zin (\d+)(?: woord (\d+))?",reason)
                        affected_id=int(match.group(1)) if match else None
                        affected=next((x for x in chunk if x["id"]==affected_id),None)
                        if affected is None:
                            message(f"  Batch {idx}, herstelpoging {repair_nr+1}: gehele batch opnieuw...")
                            candidate=call_codex(chunk,executable,out,args.timeout,
                                repair_context=reason,video_id=vid,log_tag=f"batch_{idx:02d}")
                        else:
                            message(f"  Batch {idx}, herstelpoging {repair_nr+1}: "
                                    f"alleen fragment {affected_id+1} opnieuw...")
                            repaired=call_codex([affected],executable,out,args.timeout,
                                repair_context=reason,video_id=vid,log_tag=f"batch_{idx:02d}")
                            if len(repaired)!=1:
                                raise ValueError("Codex herstelde niet precies één fragment")
                            candidate=[repaired[0] if seg.get("id")==affected_id else seg for seg in candidate]
                        local_repair.append(f"Batch {idx}, poging {repair_nr+1}: {reason}")
                json_dump_atomic(cached,{"segments":candidate})
            elapsed=round(monotonic()-batch_started,1)
            message(f"Batch {idx}/{total_chunks} gevalideerd en opgeslagen ({elapsed:.1f} s; "
                    f"{'cache' if reused else 'Codex'}).")
            return candidate,reused,local_suffix,local_repair

        chunks=[(i,subset[k:k+args.chunk_size])
                for i,k in enumerate(range(0,len(subset),args.chunk_size),1)]
        with ThreadPoolExecutor(max_workers=effective_workers,thread_name_prefix="codex_batch") as pool:
            futures={pool.submit(analyze_batch,i,chunk):i for i,chunk in chunks}
            for future in as_completed(futures):
                idx=futures[future]
                try:
                    candidate,reused,fixes,repairs=future.result()
                except Exception as exc:
                    errors.append((idx,exc))
                    message(f"Batch {idx}/{total_chunks} mislukt: {type(exc).__name__}: {exc}")
                    with lock:
                        state["active"].discard(idx)
                    emit_parallel("batch_failed",idx)
                else:
                    results[idx]=candidate
                    all_suffix_logs.extend(fixes)
                    all_repair_logs.extend(repairs)
                    with lock:
                        state["active"].discard(idx)
                        state["completed"]+=1
                        state["cached"]+=int(reused)
                    emit_parallel("batch_completed",idx)
        if errors:
            failed=', '.join(str(idx) for idx,_ in sorted(errors))
            raise RuntimeError(f"Parallelle verwerking: batch(es) {failed} mislukt; "
                               "andere geslaagde batches blijven opgeslagen. "
                               f"Eerste fout: {errors[0][1]}")
        all_segments=[seg for i in range(1,total_chunks+1) for seg in results[i]]
        suffix_log=all_suffix_logs
        repair_log=all_repair_logs
        reused_chunks=state["cached"]
        print(f"Alle {total_chunks} batches voltooid; totale verwerking "
              f"{monotonic()-started_at:.1f} s.",flush=True)
    else:
        print("Sequentiële verwerking (één Codex-proces tegelijk).",flush=True)
    if not run_parallel:
        for chunk_idx, at in enumerate(range(0,len(subset),args.chunk_size),1):
            chunk=subset[at:at+args.chunk_size]
            prefix=f"{chunk[0]['id']:04d}-{chunk[-1]['id']:04d}_"
            serialized=VERSION+json.dumps(chunk,ensure_ascii=False,sort_keys=True)
            digest=hashlib.sha256((serialized+codex_prompt(chunk,vid)).encode()).hexdigest()[:16]
            cached=cache_dir/f"{prefix}{digest}.json"
            # Legacy B1 (and other v7.14) batches still work without another Codex run.
            legacy_digest=hashlib.sha256((serialized+legacy_codex_prompt(chunk,vid)).encode()).hexdigest()[:16]
            old_cached=cache_dir/f"{prefix}{legacy_digest}.json"
            if not cached.exists() and old_cached.exists() and not args.retry:
                cached=old_cached
            is_cached = cached.exists() and not args.retry
            # Existing failed batches can be salvaged without an AI request if the
            # only problem was a wrong visible suffix. Never trust them without the
            # full schema+source validation that successful batches receive.
            recovered = None if (is_cached or args.retry) else recover_rejected_batch(
                out/"afgekeurde_batches", prefix, digest, chunk, vid)
            report_progress("batch_started", completed=chunk_idx-1, total=total_chunks,
                            current=chunk_idx, cached=reused_chunks, from_cache=bool(is_cached or recovered))
            if is_cached:
                print(f"Batch {chunk_idx}/{total_chunks} uit cache: {cached.name}",flush=True)
                candidate=json.loads(cached.read_text(encoding="utf-8"))["segments"]
                # Oude geslaagde batches worden niet stilzwijgend overschreven.
                validate_analysis(candidate,chunk,vid)
                reused_chunks += 1
            elif recovered is not None:
                candidate, fixes, rejected_path = recovered
                suffix_log.extend(fixes)
                json_dump_atomic(cached,{"segments":candidate})
                reused_chunks += 1
                print(f"Batch {chunk_idx}/{total_chunks} lokaal hersteld uit {rejected_path.name} "
                      "(geen nieuwe Codex-aanroep).",flush=True)
                for fix in fixes:
                    print(f"  {fix}",flush=True)
            else:
                print(f"Batch {chunk_idx}/{total_chunks} via Codex: fragmenten {chunk[0]['id']+1}–{chunk[-1]['id']+1}...",flush=True)
                candidate=call_codex(chunk,executable,out,args.timeout,video_id=vid)
                max_repairs=getattr(args,"max_repairs",2)
                for repair_nr in range(max_repairs+1):
                    fixes=correct_suffix_displays(candidate)
                    suffix_log.extend(fixes)
                    for fix in fixes:
                        print(f"  Lokaal gecontroleerd: {fix}",flush=True)
                    try:
                        validate_analysis(candidate,chunk,vid)
                        break
                    except (ValueError, KeyError, TypeError, IndexError) as exc:
                        reason=str(exc)
                        rejected=out/"afgekeurde_batches"/(
                            f"{chunk[0]['id']:04d}-{chunk[-1]['id']:04d}_{digest}_poging{repair_nr+1}.json")
                        json_dump_atomic(rejected,{"validation_error":reason,"segments":candidate})
                        print(f"  Codex-uitvoer afgekeurd: {reason}",flush=True)
                        print(f"  Bewaard voor onderzoek: {rejected}",flush=True)
                        if repair_nr >= max_repairs:
                            raise ValueError(
                                f"Batch {chunk_idx} blijft ongeldig na {max_repairs} herstelpogingen; "
                                f"zie {rejected}. Eerdere goede batches zijn bewaard."
                            ) from exc
                        report_progress("repairing", completed=chunk_idx-1, total=total_chunks,
                                        current=chunk_idx, cached=reused_chunks, repair=repair_nr+1)
                        # Corrigeer bij een woordfout alleen het betrokken fragment.
                        # Zo sparen we Codex-limiet en raken andere analyses niet kwijt.
                        match=re.search(r"Zin (\d+)(?: woord (\d+))?",reason)
                        affected_id=int(match.group(1)) if match else None
                        affected=next((s for s in chunk if s["id"]==affected_id),None)
                        if affected is None:
                            print(f"  Herstelpoging {repair_nr+1}: gehele batch opnieuw...",flush=True)
                            candidate=call_codex(chunk,executable,out,args.timeout,repair_context=reason,video_id=vid)
                        else:
                            print(f"  Herstelpoging {repair_nr+1}: alleen fragment {affected_id+1} opnieuw...",flush=True)
                            repaired=call_codex([affected],executable,out,args.timeout,repair_context=reason,video_id=vid)
                            if len(repaired)!=1:
                                raise ValueError("Codex herstelde niet precies één fragment")
                            candidate=[repaired[0] if seg.get("id")==affected_id else seg for seg in candidate]
                        repair_log.append(f"Batch {chunk_idx}, poging {repair_nr+1}: {reason}")
                json_dump_atomic(cached,{"segments":candidate})
            all_segments.extend(candidate)
            report_progress("batch_completed", completed=chunk_idx, total=total_chunks,
                            current=chunk_idx, cached=reused_chunks)
    report_progress("finalizing", completed=total_chunks, total=total_chunks,
                    current=total_chunks, cached=reused_chunks)
    root=validate_analysis(all_segments,subset,vid,title=args.title or f"YouTube-video {vid}")
    full=len(subset)==len(prepared)
    label="VOLLEDIG" if full else "DEELPROEF"
    out_json=out/f"{vid}_codex_{label}_NIET_GECONTROLEERD.json"
    if len(json.dumps(root,ensure_ascii=False).encode("utf8"))>5_000_000:
        raise RuntimeError("JSON is groter dan 5 MB; kan niet in de speler worden geïmporteerd")
    json_dump_atomic(out_json,root)
    write_report(out/"rapport.md",info,root["segments"],len(prepared),partial=not full,vid=vid)
    if suffix_log or repair_log:
        report_file=out/"rapport.md"
        with report_file.open("a",encoding="utf-8") as f:
            if suffix_log:
                f.write("\n## Lokaal gecorrigeerde of weggelaten suffixweergaven\n\n")
                f.write("Controleer deze punten handmatig; de grammatica blijft een concept.\n\n")
                f.write("\n".join("- "+line for line in suffix_log)+"\n")
            if repair_log:
                f.write("\n## Automatisch herstelde validatiefouten via Codex\n\n")
                f.write("\n".join("- "+line for line in repair_log)+"\n")
    report_progress("done", completed=total_chunks, total=total_chunks,
                    current=total_chunks, cached=reused_chunks, fragments=len(root["segments"]))
    print(f"Gereed: {len(root['segments'])} fragmenten; geldig v7-JSON volgens de structurele validator.")
    print("JSON:",out_json)
    print("Rapport:",out/"rapport.md")
    print("NIET automatisch geïmporteerd: controleer eerst transcript en grammaticale inhoud.")
    return 0


def main(argv: list[str] | None=None) -> int:
    p=argparse.ArgumentParser(description="Standalone YouTube -> VTT -> Codex -> grammatica-JSON v7 PROEF")
    act=p.add_mutually_exclusive_group(required=True)
    act.add_argument("--prepare",action="store_true",help="Download of lees VTT; normaliseer en maak zinnenoverzicht (geen Codex)")
    act.add_argument("--run",action="store_true",help="Voer complete proef uit via ingelogde Codex CLI")
    act.add_argument("--check-codex",action="store_true",help="Controleer of standalone Codex aanwezig is")
    p.add_argument("--url",default=DEFAULT_URL,help="YouTube-URL (standaard B1-video Алексей)")
    p.add_argument("--title",default="Алексей: семья и родные",help="Titel voor source.title in het gegenereerde JSON")
    p.add_argument("--from-vtt",type=Path,help="Gebruik bestaand VTT; sla de YouTube-download over")
    p.add_argument("--output-dir",type=Path,default=BASE/"resultaten")
    p.add_argument("--codex",default="codex",help="Pad naar zelfstandige Codex CLI")
    p.add_argument("--limit",type=int,default=0,help="Alleen eerste N fragmenten (0 = alles; ideaal voor eerste proef)")
    p.add_argument("--chunk-size",type=int,default=5,help="Codex-batchgrootte: 1-10, standaard 5")
    p.add_argument("--parallel",type=int,default=3,help="Aantal gelijktijdige Codex-batches (1-3, standaard 3; bij minder dan 3 batches sequentieel)")
    p.add_argument("--timeout",type=int,default=900,help="Maximaal aantal seconden per batch")
    p.add_argument("--refresh",action="store_true",help="VTT opnieuw downloaden")
    p.add_argument("--retry",action="store_true",help="Herbereken ook bestaande Codex-batches")
    p.add_argument("--max-repairs",type=int,default=2,help="Automatische herstelpogingen per ongeldige batch (0-5; standaard 2)")
    a=p.parse_args(argv)
    if a.check_codex:
        try:
            executable=which_codex(a.codex)
            result=subprocess.run([executable,"--version"],capture_output=True,text=True,timeout=20)
            print("Codex gevonden:",executable)
            print((result.stdout or result.stderr).strip())
            return result.returncode
        except (RuntimeError,OSError,subprocess.TimeoutExpired) as exc:
            print("Codex niet beschikbaar:",exc,file=sys.stderr)
            return 2
    try:
        return run(a)
    except (RuntimeError,ValueError,KeyError,TypeError,ImportError,subprocess.SubprocessError) as exc:
        print("PROEF ONDERBROKEN:",exc,file=sys.stderr)
        print("Reeds succesvolle Codex-batches blijven bewaard; probeer opnieuw zonder --retry.",file=sys.stderr)
        return 2


if __name__=="__main__":
    raise SystemExit(main())
