"""Toolbar placement and popup regression checks."""
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class UIv76Test(unittest.TestCase):
    def test_toolbar_follows_reading_row(self):
        text=(ROOT/'overlay.js').read_text()
        self.assertLess(text.index("shell.appendChild(readingRow)"),text.index("shell.appendChild(toolbar); // Below"))
        self.assertIn("window.__roTogglePanel('transcript')",text)
        self.assertIn("window.__roTogglePanel('help')",text)
    def test_popup_no_fixed_page_slots(self):
        text=(ROOT/'player.html').read_text()
        self.assertNotIn('class="import-slot"',text)
        self.assertNotIn('class="notes-slot"',text)
        self.assertIn('window.__roTogglePanel = (which)',text)
        self.assertIn("document.addEventListener('fullscreenchange',positionPopups)",text)
    def test_youtube_caption_preference_handling(self):
        text=(ROOT/'player.html').read_text()
        self.assertIn('cc_load_policy: 0',text)
        self.assertIn("setOption?.('captions','track',{})",text)
if __name__=='__main__':unittest.main()
