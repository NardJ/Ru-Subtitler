"""v7.10: sentence explanations focus on Russian grammar, not UI instructions."""
import json
import unittest
from pathlib import Path
from v7_annotations import validate_v7
ROOT=Path(__file__).resolve().parents[1]
class SentenceDetailTest(unittest.TestCase):
    def test_sentence_dialog_and_help(self):
        script=(ROOT/'overlay.js').read_text(encoding='utf-8')
        self.assertIn('const isBoilerplate', script)
        self.assertIn("{text:isBoilerplate?'':note}",script)
        self.assertNotIn("{text:s.words?.length?'Klik op een Russisch woord",script)
        markup=(ROOT/'player.html').read_text(encoding='utf-8')
        self.assertIn('Klik op elk Russisch woord voor de beschikbare uitleg over naamval',markup)
        self.assertIn('<strong>ⓘ Zin</strong>',markup)
    def test_bundled_babushka(self):
        f=ROOT/'cache/grammar_v7/sF20z8jY1yU.json'
        root=validate_v7(json.loads(f.read_text(encoding='utf-8')))
        self.assertEqual(len(root['segments']),28)
        self.assertTrue(all(s.get('word_order_note') for s in root['segments']))
    def test_three_import_files(self):
        counts={'kurochka_ryaba':24,'kolobok':50,'repka':33}
        for name,expected in counts.items():
            with self.subTest(name=name):
                f=ROOT/'voorbeeld_transcripten'/f'{name}_grammatica_woordvolgorde_v7_10.json'
                root=validate_v7(json.loads(f.read_text(encoding='utf-8')))
                self.assertEqual(len(root['segments']),expected)
                for s in root['segments']:
                    self.assertTrue(s.get('word_order_note'))
                    self.assertNotIn('Naamval, verbuiging en de relatie tussen',s.get('sentence_note',''))
if __name__=='__main__':unittest.main()
