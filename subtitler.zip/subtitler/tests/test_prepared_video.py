import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import app
from v7_annotations import read_v7, merge_v7

class PreparedVideoTest(unittest.TestCase):
    def test_complete_offline_video(self):
        v='sF20z8jY1yU'
        state=app.DataState()
        with patch.object(app,'fetch_subtitles',side_effect=AssertionError('No YouTube request allowed')):
            app.process_video(v,state,model='irrelevant',provider='off')
        data=state.get()
        self.assertEqual(len(data['segments']),28)
        self.assertTrue(all(len(s['tokens'])==len(s['nl']) for s in data['segments']))
        self.assertTrue(all(not s.get('pending') for s in data['segments']))
        self.assertEqual([s['id'] for s in data['segments'] if 'words' in s], list(range(28)))
        for s in data['segments']:
            if s.get('grammar_schema') == 7:
                self.assertTrue(s['words'])
                n=len(s['tokens'])
                for r in s['relations']:
                    self.assertTrue(0 <= r['from'] < n and 0 <= r['to'] < n)
            else:
                for e in s.get('endings', []):
                    self.assertTrue(s['tokens'][e['i']].lower().endswith(e['suffix'].lower()))
                for a in s.get('arrows', []):
                    self.assertTrue(any(e['i']==a['to'] for e in s.get('endings', [])))

    def test_three_part_causal_chain(self):
        root=read_v7(app.CACHE_DIR/'grammar_v7/sF20z8jY1yU.json')
        s=next(s for s in root['segments'] if s['id']==7)
        rel={r['id']:r for r in s['relations']}
        self.assertEqual((rel['7-r2']['from'],rel['7-r2']['to'],rel['7-r2']['label']),(1,2,'richting'))
        self.assertEqual((rel['7-r3']['from'],rel['7-r3']['to'],rel['7-r3']['label']),(2,3,'A'))
        self.assertIn('7-r2',rel['7-r3']['depends_on'])
        s9=next(s for s in root['segments'] if s['id']==9)
        self.assertEqual(s9['words'][3]['inflection']['type'],'zero_change')
        self.assertTrue(any(r['to']==3 and r['show_by_default'] for r in s9['relations']))

    def test_no_wrong_transcript_merge(self):
        root=read_v7(app.CACHE_DIR/'grammar_v7/sF20z8jY1yU.json')
        old=[{'id':7,'text':'Другая фраза','tokens':['Другая','фраза'],
              'start':40,'end':45,'nl':['ander','zin']}]
        result,count=merge_v7(old,root)
        self.assertEqual(count,0)
        self.assertNotIn('words',result[0])

    def test_explicit_reviewed_json_loads_without_network(self):
        state=app.DataState()
        with patch.object(app,'fetch_subtitles',side_effect=AssertionError('No network allowed')):
            app.process_video('abcdefghijk',state,model='any',provider='off',
                annotations=str(app.CACHE_DIR/'grammar_v7/sF20z8jY1yU.json'))
        data=state.get()
        self.assertEqual(len(data['segments']),28)
        self.assertEqual(data['segments'][1]['grammar_schema'],7)

    def test_new_sentences_cover_direction_case_and_agreement(self):
        root=read_v7(app.CACHE_DIR/'grammar_v7/sF20z8jY1yU.json')
        self.assertEqual(len(root['segments']),28)
        self.assertEqual(sum(len(s['words']) for s in root['segments']),105)
        by_id={s['id']:s for s in root['segments']}
        for n in [5,11,13,15]:
            self.assertTrue(any(r['label']=='A' for r in by_id[n]['relations']))
        self.assertEqual(by_id[8]['words'][3]['features']['case'],'A')
        self.assertEqual(by_id[18]['words'][2]['features']['case'],'P')
        self.assertEqual(by_id[21]['words'][1]['features']['gender'],'M')
        self.assertEqual(by_id[27]['words'][6]['features']['gender'],'M')
