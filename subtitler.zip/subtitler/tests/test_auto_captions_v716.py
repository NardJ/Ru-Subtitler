"""v7.16: real YouTube test identified missing automatic subtitle/EJS flags."""
import tempfile
import unittest
from pathlib import Path
from subprocess import CompletedProcess
from unittest.mock import patch

import auto_grammar_cli as cli


VTT = "WEBVTT\n\n00:00:01.000 --> 00:00:03.000\nОн работает.\n"


class AutoCaptionsV716Test(unittest.TestCase):
    def test_command_fetches_manual_and_auto_ru_with_ejs_without_media(self):
        with tempfile.TemporaryDirectory() as d:
            output = Path(d)
            seen = []
            def fake_run(cmd, **kwargs):
                seen.extend(cmd)
                template = cmd[cmd.index('-o') + 1]
                Path(template.replace('%(id)s', 'MnPRchp-CEo').replace('%(ext)s', 'ru.vtt')).write_text(
                    VTT, encoding='utf-8')
                return CompletedProcess(cmd, 0, '[info] Downloading subtitles: ru\n')
            with patch.object(cli.subprocess, 'run', side_effect=fake_run):
                resulting = cli.yt_download('https://www.youtube.com/watch?v=MnPRchp-CEo',output,refresh=True)
            self.assertTrue(resulting.exists())
            self.assertIn('--write-subs',seen)
            self.assertIn('--write-auto-subs',seen)
            self.assertEqual(seen[seen.index('--remote-components') + 1], 'ejs:github')
            self.assertEqual(seen[seen.index('--sub-langs') + 1], 'ru')
            self.assertIn('--skip-download',seen)
            self.assertNotIn('--write-info-json',seen)
            self.assertEqual(len(cli.prepare_vtt(resulting)[0]),1)

    def test_no_subtitles_message_is_accurate_not_secretstorage_guess(self):
        with tempfile.TemporaryDirectory() as d:
            output = Path(d)
            def fake_run(cmd, **kwargs):
                return CompletedProcess(cmd, 0, '[info] There are no subtitles for the requested languages\n')
            with patch.object(cli.subprocess,'run',side_effect=fake_run):
                with self.assertRaisesRegex(RuntimeError,'ook geen automatische'):
                    cli.yt_download('O6hWfgjqpz8',output,refresh=True)
            self.assertTrue((output/'yt_dlp_log.txt').is_file())
            self.assertEqual(list(output.glob('*.vtt')),[])

    def test_existing_vtt_is_reused_without_redownload(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)
            existing=out/'MnPRchp-CEo.ru.vtt'
            existing.write_text(VTT,encoding='utf8')
            with patch.object(cli.subprocess,'run') as run:
                result=cli.yt_download('MnPRchp-CEo',out,refresh=False)
            self.assertEqual(result,existing)
            run.assert_not_called()

    def test_bad_refresh_preserves_previous_vtt(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)
            existing=out/'O6hWfgjqpz8.ru.vtt'
            existing.write_text(VTT,encoding='utf8')
            with patch.object(cli.subprocess,'run',return_value=CompletedProcess([],1,'ERROR: captcha')):
                with self.assertRaisesRegex(RuntimeError,'yt_dlp_log.txt'):
                    cli.yt_download('O6hWfgjqpz8',out,refresh=True)
            self.assertEqual(existing.read_text(encoding='utf8'),VTT)


if __name__=='__main__':
    unittest.main()
