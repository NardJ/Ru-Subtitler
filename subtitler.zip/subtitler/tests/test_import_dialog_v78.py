"""v7.8: import dialog separates analyzed JSON from raw captions and documents schema."""
import json
import re
import tempfile
import threading
import unittest
import urllib.request
import urllib.error
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

import app
from video_library import VideoLibrary
from v7_annotations import validate_v7


class ImportDialogV78Test(unittest.TestCase):
    def test_distinct_tabs_and_explicit_results(self):
        html=(app.HERE/'player.html').read_text(encoding='utf-8')
        for s in ('tab-grammar', 'tab-raw', 'mode-grammar', 'mode-raw',
                  'grammar-import-message', 'caption-file-import',
                  '/FORMAT_GRAMMATICA_JSON_V7.md', 'Import geslaagd:',
                  "active.segments?.length!==result.count"):
            self.assertIn(s,html)
        self.assertIn('id="mode-raw" role="tabpanel" aria-labelledby="tab-raw" hidden',html)
        self.assertIn('grammarButton.disabled=true',html)

    def test_markdown_reference_contains_valid_complete_example(self):
        md=(app.HERE/'FORMAT_GRAMMATICA_JSON_V7.md').read_text(encoding='utf-8')
        sections=re.findall(r'```json\n(.*?)\n```',md,re.S)
        root=json.loads(sections[-1])
        validated=validate_v7(root)
        self.assertEqual(len(validated['segments']),1)
        self.assertEqual(validated['segments'][0]['tokens'][-1],'столом')
        self.assertEqual(validated['segments'][0]['relations'][-1]['depends_on'],['0-r2'])

    def test_raw_grammar_json_rejected_and_docs_downloadable(self):
        with tempfile.TemporaryDirectory() as tmp:
            library=VideoLibrary(Path(tmp)/'videos.json')
            library.add('abcdefghijk','Documentatie proef')
            state=app.DataState();state.video_id='abcdefghijk'
            root=json.loads((app.CACHE_DIR/'grammar_v7/sF20z8jY1yU.json').read_text())
            root['source']['video_id']='abcdefghijk'
            with patch.object(app,'USER_DATA_DIR',Path(tmp)):
                server=ThreadingHTTPServer(('127.0.0.1',0),app.handler_factory(state,'abcdefghijk',library=library,provider='off'))
                thread=threading.Thread(target=server.serve_forever,daemon=True)
                thread.start()
                base=f'http://127.0.0.1:{server.server_port}'
                try:
                    with urllib.request.urlopen(base+'/FORMAT_GRAMMATICA_JSON_V7.md') as response:
                        self.assertIn(b'schema v7',response.read().lower())
                    def post(path,payload):
                        request=urllib.request.Request(base+path,method='POST',
                            data=json.dumps(payload,ensure_ascii=False).encode('utf-8'),
                            headers={'Content-Type':'application/json'})
                        with urllib.request.urlopen(request) as response:return json.load(response)
                    with self.assertRaises(urllib.error.HTTPError) as e:
                        post('/api/import',{'text':json.dumps(root,ensure_ascii=False),'format':'json'})
                    self.assertEqual(e.exception.code,400)
                    self.assertIn('grammatica-JSON',e.exception.read().decode())
                    good=post('/api/import-grammar',{'grammar':root})
                    self.assertEqual(good['video_id'],'abcdefghijk')
                    self.assertEqual(good['count'],28)
                finally:
                    server.shutdown();server.server_close();thread.join(timeout=2)


if __name__=='__main__':unittest.main()
