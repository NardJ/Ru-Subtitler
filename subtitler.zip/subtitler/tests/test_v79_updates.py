"""v7.9 regression: safe library edits, Chrome launcher and word-order notes."""
import copy
import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

import app
from video_library import VideoLibrary
from v7_annotations import validate_v7

class V79Test(unittest.TestCase):
    def test_rename_and_change_url_without_assigning_old_grammar(self):
        with tempfile.TemporaryDirectory() as t:
            data=Path(t)
            lib=VideoLibrary(data/'videos.json')
            old='abcdefghijk';new='lmnopqrstuv'
            lib.add(old,'Oud')
            file=data/'grammar_v7'/f'{old}.json'
            file.parent.mkdir(parents=True)
            file.write_text('ORIGINAL')
            self.assertEqual(lib.edit(old,old,'Nieuwe titel'),old)
            self.assertEqual(lib.get(data)['videos'][0]['title'],'Nieuwe titel')
            self.assertTrue(lib.get(data)['videos'][0]['has_grammar'])
            self.assertEqual(lib.edit(old,'https://www.youtube.com/watch?v='+new,'Andere video'),new)
            self.assertEqual(lib.selected,new)
            self.assertFalse(lib.get(data)['videos'][0]['has_grammar'])
            self.assertEqual(file.read_text(),'ORIGINAL')
            self.assertEqual(VideoLibrary(data/'videos.json').videos,[{'id':new,'title':'Andere video'}])

    def test_duplicate_rejected_and_original_intact(self):
        with tempfile.TemporaryDirectory() as t:
            lib=VideoLibrary(Path(t)/'videos.json')
            lib.add('abcdefghijk','Een')
            lib.add('lmnopqrstuv','Twee')
            with self.assertRaisesRegex(ValueError,'al in je bibliotheek'):
                lib.edit('abcdefghijk','lmnopqrstuv','Overschrijven')
            self.assertEqual(lib.videos[0]['title'],'Een')
            self.assertEqual(len(lib.videos),2)

    def test_edit_api_changes_state_without_fetching_transcript(self):
        with tempfile.TemporaryDirectory() as t:
            data=Path(t)
            lib=VideoLibrary(data/'videos.json')
            lib.add('abcdefghijk','Test')
            state=app.DataState();state.video_id='abcdefghijk'
            with patch.object(app,'USER_DATA_DIR',data), patch.object(app,'fetch_subtitles',side_effect=AssertionError('no scraping')):
                server=ThreadingHTTPServer(('127.0.0.1',0),app.handler_factory(state,state.video_id,library=lib,provider='off'))
                th=threading.Thread(target=server.serve_forever,daemon=True);th.start()
                try:
                    req=urllib.request.Request(f'http://127.0.0.1:{server.server_port}/api/videos',method='POST',headers={'Content-Type':'application/json'},data=json.dumps({'action':'edit','original_id':'abcdefghijk','url':'lmnopqrstuv','title':'Nieuw'}).encode())
                    with urllib.request.urlopen(req) as response:r=json.load(response)
                    self.assertEqual(r['id'],'lmnopqrstuv')
                    self.assertEqual(state.video_id,'lmnopqrstuv')
                finally:
                    server.shutdown();server.server_close();th.join(timeout=2)

    def test_chrome_launcher_no_scraper(self):
        with patch.object(app.shutil,'which',return_value='/usr/bin/google-chrome'), patch.object(app.subprocess,'Popen') as popen:
            result=app.open_local_browser('http://127.0.0.1:45941/','chrome')
        self.assertEqual(result,'Chrome/Chromium: browservenster')
        self.assertEqual(popen.call_args.args[0],['/usr/bin/google-chrome','http://127.0.0.1:45941/'])

    def test_word_order_schema_and_repka(self):
        path=Path(__file__).resolve().parents[1] / 'voorbeeld_transcripten/repka_grammatica_woordvolgorde_v7_10.json'
        root=validate_v7(json.loads(path.read_text(encoding='utf-8')))
        self.assertEqual(len(root['segments']),33)
        self.assertTrue(all(x['word_order_note'] for x in root['segments']))
        self.assertIn('voorop',root['segments'][4]['word_order_note'])
        js=(app.HERE/'overlay.js').read_text(encoding='utf-8')
        self.assertIn('s.word_order_note',js)

if __name__=='__main__':unittest.main()
