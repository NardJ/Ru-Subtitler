"""v7.17 avoids pathological one-piece lyrics and reports heartbeat elapsed time."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import auto_grammar_cli as cli
from auto_grammar_integration import AutoGrammarManager

VID='MnPRchp-CEo'
PHRASE='он живёт в синем доме но его семья сегодня очень далеко'


class SongFragmentLimits(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base=Path(self.tmp.name)

    def make_vtt(self, lines):
        chunks=['WEBVTT','']
        for i,line in enumerate(lines):
            chunks.extend([f'00:00:{i:02d}.000 --> 00:00:{i+1:02d}.000',line,''])
        f=self.base/'test.vtt';f.write_text('\n'.join(chunks),encoding='utf8')
        return f

    def test_22_cues_cannot_merge_to_217_word_run(self):
        vtt=self.make_vtt([PHRASE]*22)
        result,audit=cli.prepare_vtt(vtt,video_id=VID)
        self.assertEqual(audit['input_cues'],22)
        self.assertEqual(audit['words'],22*len(cli.tokenize(PHRASE)))
        self.assertGreater(len(result),5)
        self.assertLessEqual(max(len(x['tokens']) for x in result),cli.MAX_WORDS_PER_FRAGMENT)
        self.assertEqual([t for x in result for t in x['tokens']],cli.tokenize(' '.join([PHRASE]*22)))

    def test_one_long_cue_is_split_without_word_loss_and_with_estimated_times(self):
        big=' '.join([PHRASE]*9)
        vtt=self.base/'long.vtt'
        vtt.write_text('WEBVTT\n\n00:00:01.000 --> 00:00:25.000\n'+big+'\n',encoding='utf8')
        result,audit=cli.prepare_vtt(vtt,video_id=VID)
        self.assertGreater(len(result),1)
        self.assertLessEqual(max(len(x['tokens']) for x in result),22)
        self.assertEqual([t for x in result for t in x['tokens']],cli.tokenize(big))
        self.assertTrue(all(s['estimated_times'] for s in result))
        self.assertEqual(result[0]['start'],1)
        self.assertEqual(result[-1]['end'],25)
        self.assertGreater(audit['estimated_segments'],0)

    def test_normal_short_story_still_joins_lowercase_continuation(self):
        body='WEBVTT\n\n00:00:01.000 --> 00:00:02.000\nОн живёт\n\n00:00:02.000 --> 00:00:03.000\nв доме.\n'
        f=self.base/'normal.vtt';f.write_text(body,encoding='utf8')
        data,audit=cli.prepare_vtt(f,video_id=VID)
        self.assertEqual(len(data),1)
        self.assertEqual(data[0]['text'],'Он живёт в доме.')
        self.assertEqual(audit['merged'],1)

    def test_server_heartbeat_exposes_time_without_claiming_codex_progress(self):
        manager=AutoGrammarManager(self.base,self.base)
        with patch('auto_grammar_integration.monotonic',return_value=200):
            manager.jobs[VID]={'phase':'running','mode':'run','started_at':100,
                               'last_output_at':130,'log':[],
                               'progress':{'stage':'batch_started','completed':0,'total':5,'current':1}}
            status=manager.status(VID)
        self.assertEqual(status['running_seconds'],100)
        self.assertEqual(status['quiet_seconds'],70)
        self.assertEqual(status['progress']['completed'],0)

    def test_progress_ui_includes_elapsed_and_quiet_indicator(self):
        html=(Path(__file__).resolve().parents[1]/'player.html').read_text(encoding='utf8')
        self.assertIn('state.running_seconds',html)
        self.assertIn('zonder nieuw programmabericht',html)
        self.assertIn('YouTube · v7.17',html)


if __name__=='__main__':unittest.main()
