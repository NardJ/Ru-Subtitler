"""Offline acceptance tests for real progress events, cache reuse and server job state."""
from __future__ import annotations

import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import auto_grammar_cli as cli
from auto_grammar_integration import AutoGrammarManager, PROGRESS_PREFIX

VID = 'QpQmw2rxxtQ'
VTT = '''WEBVTT

00:00:02.000 --> 00:00:04.000
Привет!

00:00:05.000 --> 00:00:07.000
Пока!
'''


def fake_analysis(chunk, *args, **kwargs):
    result = []
    for orig in chunk:
        words = []
        for i, form in enumerate(orig['tokens']):
            words.append({'i': i, 'form': form, 'nl': 'hallo', 'lemma': form.lower(),
                          'pos': 'ADV', 'role': 'voorbeeld', 'explanation': 'Simulatie', 'features': {}})
        result.append({key: orig[key] for key in ('id', 'start', 'end', 'text', 'tokens')} |
                      {'nl': ['hallo'] * len(words), 'nl_natural': 'Een voorbeeld.',
                       'sentence_note': 'Simulatie.', 'word_order_note': 'Simulatie.',
                       'words': words, 'relations': []})
    return result


class TestAutoProgress(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.vtt = self.root / 'test.ru.vtt'
        self.vtt.write_text(VTT, encoding='utf-8')

    def run_cli(self):
        out = io.StringIO()
        with patch.object(cli, 'which_codex', return_value='/mock/codex'), \
             patch.object(cli, 'call_codex', side_effect=fake_analysis), \
             contextlib.redirect_stdout(out):
            rc = cli.main(['--run', '--url', 'https://www.youtube.com/watch?v='+VID,
                           '--from-vtt', str(self.vtt), '--output-dir', str(self.root),
                           '--chunk-size', '1', '--title', 'Voortgangtest'])
        self.assertEqual(rc, 0)
        return [json.loads(line.split(cli.AUTO_PROGRESS_PREFIX, 1)[1])
                for line in out.getvalue().splitlines() if line.startswith(cli.AUTO_PROGRESS_PREFIX)]

    def test_progress_per_validated_batch_and_cached_restart(self):
        first = self.run_cli()
        self.assertEqual([v['stage'] for v in first], [
            'prepared', 'batches_ready', 'batch_started', 'batch_completed',
            'batch_started', 'batch_completed', 'finalizing', 'done'])
        self.assertEqual([(e['completed'], e['total']) for e in first if e['stage']=='batch_completed'],
                         [(1, 2), (2, 2)])
        self.assertEqual(first[-1]['cached'], 0)
        second = self.run_cli()
        self.assertEqual([e['from_cache'] for e in second if e['stage']=='batch_started'],[True, True])
        self.assertEqual(second[-1]['cached'], 2)
        self.assertTrue((self.root / VID / f'{VID}_codex_VOLLEDIG_NIET_GECONTROLEERD.json').exists())

    def test_worker_reads_machine_progress_and_marks_ready(self):
        self.run_cli()  # produce a real valid draft
        manager=AutoGrammarManager(self.root, self.root)
        manager.outdir=self.root
        manager.jobs[VID]={'phase':'running','mode':'run','error':'','log':[],
                           'progress': {'stage':'starting','completed':0,'total':0}}
        events=[
            {'stage':'prepared','fragments':2},
            {'stage':'batches_ready','completed':0,'total':2,'cached':0},
            {'stage':'batch_started','completed':0,'total':2,'current':1,'cached':0},
            {'stage':'batch_completed','completed':1,'total':2,'current':1,'cached':0},
            {'stage':'repairing','completed':1,'total':2,'current':2,'cached':0,'repair':1},
            {'stage':'batch_completed','completed':2,'total':2,'current':2,'cached':0},
            {'stage':'finalizing','completed':2,'total':2,'current':2,'cached':0},
            {'stage':'done','completed':2,'total':2,'current':2,'cached':0},
        ]
        class MockProc:
            returncode=0
            def __init__(self):
                self.stdout=iter(['Voorbereid: 2 VTT-regels → 2 grammaticafragmenten\n'] +
                      [PROGRESS_PREFIX+json.dumps(v)+'\n' for v in events] +
                      ['Gereed: 2 fragmenten\n'])
            def wait(self): return 0
        with patch('auto_grammar_integration.subprocess.Popen', return_value=MockProc()):
            manager._worker(VID,'run','Test',False)
        state=manager.status(VID)
        self.assertEqual(state['phase'],'ready')
        self.assertEqual(state['progress']['completed'],2)
        self.assertEqual(state['progress']['total'],2)
        self.assertTrue(state['draft']['available'])
        self.assertFalse(any(line.startswith(PROGRESS_PREFIX) for line in state['log']))
        self.assertIn('Gereed: 2 fragmenten',state['log'][-1])

    def test_worker_error_keeps_last_completed_count(self):
        manager=AutoGrammarManager(self.root, self.root)
        manager.outdir=self.root
        manager.jobs[VID]={'phase':'running','mode':'run','error':'','log':[],'progress': {}}
        event={'stage':'batch_completed','completed':1,'total':3,'current':1,'cached':0}
        class MockProc:
            returncode=1
            def __init__(self):
                self.stdout=iter([PROGRESS_PREFIX+json.dumps(event)+'\n', 'PROEF ONDERBROKEN: test\n'])
            def wait(self): return 1
        with patch('auto_grammar_integration.subprocess.Popen', return_value=MockProc()):
            manager._worker(VID,'run','Test',False)
        status=manager.status(VID)
        self.assertEqual(status['phase'],'error')
        self.assertEqual(status['progress']['completed'],1)
        self.assertEqual(status['progress']['total'],3)

    def test_ui_progress_and_semantics_present(self):
        html=(Path(__file__).resolve().parents[1] / 'player.html').read_text(encoding='utf-8')
        self.assertIn('id="auto-progress-bar"',html)
        self.assertIn('id="auto-progress-text"',html)
        self.assertIn("Math.min(99,Math.round(100*completed/total))",html)
        self.assertIn('Codex verwerkt de grammatica',html)
        self.assertIn('Verwerking onderbroken',html)


if __name__=='__main__':
    unittest.main()
