import unittest
from pathlib import Path
from v7_annotations import read_v7

class DeclensionTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        root=Path(__file__).resolve().parents[1]
        cls.segments=read_v7(root/'cache'/'grammar_v7'/'sF20z8jY1yU.json')['segments']

    def test_all_declined_words_have_paradigms(self):
        for segment in self.segments:
            for w in segment['words']:
                if w['pos'] in ('NOUN','ADJ','DET','PRON'):
                    with self.subTest(word=w['form']):
                        self.assertIn('paradigm',w)

    def test_stolom_is_instrumental(self):
        segment=next(s for s in self.segments if s['text']=='Кот сидит под столом.')
        w=next(w for w in segment['words'] if w['form']=='столом')
        self.assertEqual(w['features']['case'],'I')
        self.assertEqual(w['paradigm']['forms'],{
            'N':'стол','G':'стола','D':'столу',
            'A':'стол','I':'столом','P':'столе'})

    def test_gender_specific_adjective_forms(self):
        adjective=next(w for s in self.segments for w in s['words'] if w['lemma']=='большой')
        a=adjective['paradigm']['rows'][3]
        self.assertEqual(a['F'],'большую')
        self.assertEqual(a['M'],'большой / большого')

if __name__=='__main__':unittest.main()
