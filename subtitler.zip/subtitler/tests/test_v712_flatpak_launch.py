"""Check Flatpak Chrome discovery and no silent tab fallback (v7.12)."""
import unittest
from unittest.mock import Mock, patch
import app


class TestFlatpakChrome(unittest.TestCase):
    def test_flatpak_chrome_app_mode(self):
        def which(binary):
            return '/usr/bin/flatpak' if binary == 'flatpak' else None

        with patch.object(app.os, 'name', 'posix'), \
             patch.object(app.sys, 'platform', 'linux'), \
             patch.object(app.shutil, 'which', side_effect=which), \
             patch.object(app.Path, 'is_file', return_value=False), \
             patch.object(app.subprocess, 'run', return_value=Mock(returncode=0, stdout='org.example.Other\ncom.google.Chrome\n')), \
             patch.object(app.subprocess, 'Popen') as popen, \
             patch.object(app.webbrowser, 'open') as webopen:
            result = app.open_local_browser('http://127.0.0.1:36511/', 'app')
        self.assertEqual(result, 'com.google.Chrome (Flatpak): appvenster')
        self.assertEqual(popen.call_args.args[0], [
            '/usr/bin/flatpak', 'run', 'com.google.Chrome', '--app=http://127.0.0.1:36511/'
        ])
        webopen.assert_not_called()

    def test_flatpak_chromium_app_mode(self):
        def which(binary):
            return '/usr/bin/flatpak' if binary == 'flatpak' else None
        with patch.object(app.os, 'name', 'posix'), \
             patch.object(app.sys, 'platform', 'linux'), \
             patch.object(app.shutil, 'which', side_effect=which), \
             patch.object(app.Path, 'is_file', return_value=False), \
             patch.object(app.subprocess, 'run', return_value=Mock(returncode=0, stdout='org.chromium.Chromium\n')), \
             patch.object(app.subprocess, 'Popen') as popen:
            result = app.open_local_browser('http://127.0.0.1:36511/', 'app')
        self.assertEqual(result, 'org.chromium.Chromium (Flatpak): appvenster')
        self.assertIn('--app=http://127.0.0.1:36511/', popen.call_args.args[0])

    def test_default_mode_explicitly_opens_normal_browser(self):
        with patch.object(app.webbrowser, 'open') as webopen:
            result = app.open_local_browser('http://127.0.0.1:36511/', 'default')
        self.assertEqual(result, 'standaardbrowser')
        webopen.assert_called_once()

    def test_no_installed_flatpak_does_not_open_tab(self):
        with patch.object(app.shutil, 'which', return_value=None), \
             patch.object(app.Path, 'is_file', return_value=False), \
             patch.object(app.webbrowser, 'open') as webopen:
            result = app.open_local_browser('http://127.0.0.1:36511/', 'app')
        self.assertIn('geen Chrome gevonden', result)
        webopen.assert_not_called()


if __name__ == '__main__':
    unittest.main()
