"""v7.15: deterministic relation display, Codex cache reuse and case/all mode."""
import hashlib
import json
import re
import subprocess
import unittest
from pathlib import Path
import auto_grammar_cli as cli

ROOT=Path(__file__).resolve().parents[1]
SAMPLE=Path('/mnt/data/QpQmw2rxxtQ_v7_GENORMALISEERD_CONCEPT.json')


class RelationModeV715Test(unittest.TestCase):
    def test_version_and_visible_control(self):
        html=(ROOT/'player.html').read_text(encoding='utf-8')
        js=(ROOT/'overlay.js').read_text(encoding='utf-8')
        self.assertIn('YouTube · v7.17',html)
        self.assertIn("['cases','Naamvallen']",js)
        self.assertIn("['all','Alle grammatica']",js)
        self.assertIn("localStorage.getItem('ru-grammar-overlay-settings')",js)
        self.assertIn('settings.relationMode=relSelect.value;save();refreshCurrent()',js)
        self.assertIn("const defaults={size:24, alpha:.76, grammar:true, relationMode:'cases'",js)
        self.assertIn("settings.grammar=!settings.grammar",js)  # old hide-all kept
        self.assertNotIn('filter(r=>r.show_by_default!==false)',js)

    def test_real_b1_subject_verb_arrows_visible_in_all_mode(self):
        if not SAMPLE.is_file():
            self.skipTest('B1 input sample not bundled')
        d=json.loads(SAMPLE.read_text(encoding='utf-8'))
        seg=next(s for s in d['segments'] if s['id']==19)
        js=(ROOT/'overlay.js').read_text(encoding='utf-8')
        start=js.index('  function relationSemantic(r){')
        end=js.index('  function sentenceLabel(s){')
        helper=js[start:end]
        program='''const vm=require('node:vm');
const helper=process.argv[1];
const segment=JSON.parse(process.argv[2]);
const functions=vm.runInNewContext(`(function(){${helper};return {relationVisibleForMode,relationDiagramLabel};})()`);
const cases=segment.relations.filter(r=>functions.relationVisibleForMode(r,'cases'));
const all=segment.relations.filter(r=>functions.relationVisibleForMode(r,'all'));
const special=all.filter(r=>r.type==='subject_verb_agreement'&&r.from===1).map(r=>r.to).sort();
console.log(JSON.stringify({cases:cases.length,all:all.length,special,hidden:all.filter(r=>r.show_by_default===false).length,
 label:functions.relationDiagramLabel(all.find(r=>r.type==='subject_verb_agreement'))}));
'''
        result=subprocess.run(['node','-e',program,helper,json.dumps(seg,ensure_ascii=False)],
                              capture_output=True,text=True,check=True)
        out=json.loads(result.stdout)
        self.assertEqual(out['cases'],3)
        self.assertEqual(out['all'],10)
        self.assertEqual(out['special'],[2,6])
        self.assertGreater(out['hidden'],0)
        self.assertEqual(out['label'],'onderw. → ev.')

    def test_new_prompt_requires_grammatical_links(self):
        src=[{'id':0,'start':1,'end':2,'text':'Он работает и отдыхает.',
              'tokens':['Он','работает','и','отдыхает'],'kind':'sentence'}]
        old=cli.legacy_codex_prompt(src)
        new=cli.codex_prompt(src)
        self.assertNotEqual(old,new)
        self.assertIn('ELK bijbehorend vervoegd werkwoord',new)
        self.assertIn('De speler bepaalt zelf welke relaties zichtbaar zijn',new)
        self.assertIn('Wees selectief met zichtbare pijlen',old)
        self.assertNotIn('Wees selectief met zichtbare pijlen',new)

    def test_legacy_cache_compatibility(self):
        src=[{'id':0,'start':1,'end':2,'text':'Он работает.',
              'tokens':['Он','работает'],'kind':'sentence'}]
        serialized=cli.VERSION+json.dumps(src,ensure_ascii=False,sort_keys=True)
        digest_old=hashlib.sha256((serialized+cli.legacy_codex_prompt(src,'QpQmw2rxxtQ')).encode()).hexdigest()[:16]
        digest_new=hashlib.sha256((serialized+cli.codex_prompt(src,'QpQmw2rxxtQ')).encode()).hexdigest()[:16]
        self.assertNotEqual(digest_old,digest_new)
        txt=(ROOT/'auto_grammar_cli.py').read_text(encoding='utf-8')
        self.assertIn('if not cached.exists() and old_cached.exists() and not args.retry:',txt)
        self.assertIn('cached=old_cached',txt)

    def test_deterministic_legacy_flags_in_normalized_json(self):
        s={'words':[], 'relations':[
            {'type':'case_government','show_by_default':False},
            {'type':'subject_verb_agreement','show_by_default':True},
            {'type':'agreement','show_by_default':False},
            {'type':'semantic_context','show_by_default':True}]}
        norm=cli.normalize_codex_segment(s)
        self.assertEqual([r['show_by_default'] for r in norm['relations']],
                         [True,False,True,False])
        self.assertEqual(s['relations'][0]['show_by_default'],False)

    def test_javascript_syntax(self):
        subprocess.run(['node','--check',str(ROOT/'overlay.js')],check=True,capture_output=True)


if __name__=='__main__':
    unittest.main()
