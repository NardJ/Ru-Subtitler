"""v7.11: independent Chrome app-window and consistent grammatical explanation UX."""
import unittest
from pathlib import Path
from unittest.mock import patch
import app

ROOT=Path(__file__).resolve().parents[1]

class V711Test(unittest.TestCase):
    def test_chrome_app_mode_launches_independent_window(self):
        with patch.object(app.shutil, 'which', side_effect=lambda x: '/usr/bin/google-chrome' if x=='google-chrome' else None), \
             patch.object(app.subprocess, 'Popen') as popen:
            result=app.open_local_browser('http://127.0.0.1:45941/', 'app')
        self.assertEqual(result,'Chrome/Chromium: appvenster')
        self.assertEqual(popen.call_args.args[0], ['/usr/bin/google-chrome','--app=http://127.0.0.1:45941/'])
        self.assertTrue(popen.call_args.kwargs['start_new_session'])

    def test_app_falls_back_safely_without_chrome(self):
        with patch.object(app.shutil,'which',return_value=None),patch.object(app.Path,'is_file',return_value=False), \
             patch.object(app.webbrowser,'open') as op:
            result=app.open_local_browser('http://127.0.0.1:45941/', 'app')
        self.assertEqual(result,'geen Chrome gevonden; geen browsertab geopend')
        op.assert_not_called()

    def test_centered_dialog_and_navigation(self):
        js=(ROOT/'overlay.js').read_text(encoding='utf-8')
        html=(ROOT/'player.html').read_text(encoding='utf-8')
        self.assertIn('sentenceButton=navigation',js)
        self.assertIn("readingRow.appendChild(sentenceButton)",js)
        self.assertIn("window.__roShowGrammarDetail(content)",js)
        self.assertIn('Zinsuitleg tonen',js)
        self.assertIn("showSentenceDetail();return;",js)
        self.assertIn('grammar-detail-backdrop',html)
        self.assertIn('window.__roShowGrammarDetail=(content)=>',html)
        self.assertIn('window.__roCloseGrammarDetail=()=>',html)
        self.assertIn('max-height:min(90%,710px)',html)
        self.assertNotIn('v7.9</h1>',html)

if __name__=='__main__': unittest.main()
