"""v7.14: preserve manual grammar; stage Codex drafts separately."""
from __future__ import annotations
import hashlib
import json
import tempfile
import time
import unittest
from pathlib import Path
from threading import Thread
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from unittest.mock import patch

import app
import auto_grammar_cli as cli
from auto_grammar_integration import AutoGrammarManager
from video_library import VideoLibrary
from http.server import ThreadingHTTPServer

ROOT = Path(__file__).resolve().parents[1]
VID = 'sF20z8jY1yU'


class AutoGrammarV713Test(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.data=Path(self.tmp.name)
        self.manager=AutoGrammarManager(ROOT, self.data)
        self.fixture=json.loads((ROOT/'cache/grammar_v7'/f'{VID}.json').read_text(encoding='utf-8'))
        self.fixture.setdefault('source',{})['video_id']=VID
        self.draft=self.manager._draft_file(VID)
        self.draft.parent.mkdir(parents=True,exist_ok=True)
        self.draft.write_text(json.dumps(self.fixture,ensure_ascii=False),encoding='utf-8')
        self.target=self.data/'grammar_v7'/f'{VID}.json'
        self.target.parent.mkdir(parents=True,exist_ok=True)

    def test_generic_video_title_not_discarded(self):
        body='WEBVTT\n\n00:00:00.000 --> 00:00:02.000\nКолобок\n\n00:00:03.000 --> 00:00:05.000\nПривет!\n'
        fn=self.data/'a.vtt';fn.write_text(body,encoding='utf-8')
        segments,info=cli.prepare_vtt(fn,video_id='NlwMtZ0kvX0')
        self.assertEqual([s['text'] for s in segments],['Колобок','Привет!'])
        self.assertEqual(info['words'],2)

    def test_b1_title_can_be_excluded_but_all_spoken_words_preserved(self):
        body='WEBVTT\n\n00:00:00.000 --> 00:00:03.000\nАлексей: семья и родные. В1\n\n00:00:08.000 --> 00:00:10.000\nЭто Алексей.\n'
        fn=self.data/'b.vtt';fn.write_text(body,encoding='utf-8')
        segments,info=cli.prepare_vtt(fn,video_id='QpQmw2rxxtQ')
        self.assertEqual(len(segments),1)
        self.assertEqual(segments[0]['tokens'],['Это','Алексей'])
        self.assertEqual(len(info['title_skipped']),1)

    def test_preview_and_hash_survive_server_restart(self):
        preview=self.manager.status(VID)
        self.assertTrue(preview['draft']['available'])
        self.assertEqual(preview['draft']['count'],len(self.fixture['segments']))
        new=AutoGrammarManager(ROOT,self.data)
        self.assertEqual(preview['draft']['hash'],new.status(VID)['draft']['hash'])

    def test_existing_grammar_needs_explicit_overwrite_and_backup(self):
        self.target.write_text('OLD_GRAMMAR',encoding='utf-8')
        digest=self.manager.status(VID)['draft']['hash']
        with self.assertRaisesRegex(ValueError,'Bevestig expliciet'):
            self.manager.import_confirmed(VID,digest,overwrite=False,currently_selected=VID,target=self.target)
        self.assertEqual(self.target.read_text(),'OLD_GRAMMAR')
        root=self.manager.import_confirmed(VID,digest,overwrite=True,currently_selected=VID,target=self.target)
        self.assertEqual(len(root['segments']),len(self.fixture['segments']))
        self.assertEqual(len(list(self.target.parent.glob(VID+'.backup-*.json'))),1)
        self.assertEqual(list(self.target.parent.glob(VID+'.backup-*.json'))[0].read_text(),'OLD_GRAMMAR')
        self.assertIn('Codex-concept',json.loads(self.target.read_text())['status'])

    def test_wrong_hash_video_and_active_job_rejected(self):
        digest=self.manager.status(VID)['draft']['hash']
        for video,hash_ in [(VID,'0'*64),('NlwMtZ0kvX0',digest)]:
            with self.assertRaises(ValueError):
                self.manager.import_confirmed(video,hash_,overwrite=True,currently_selected=VID,target=self.target)
        with self.manager.lock:
            self.manager.jobs[VID]={'phase':'running','log':[]}
        with self.assertRaisesRegex(ValueError,'Codex'):
            self.manager.import_confirmed(VID,digest,overwrite=True,currently_selected=VID,target=self.target)

    def test_ui_contains_explicit_confirmation_and_separate_tabs(self):
        content=(ROOT/'player.html').read_text(encoding='utf-8')
        for phrase in ('tab-auto','auto-grammar-open','auto-reviewed','auto-overwrite','/api/auto/start','/api/auto/import'):
            self.assertIn(phrase,content)
        self.assertIn('v7.17',content)

    def test_http_status_and_confirmed_import(self):
        library=VideoLibrary(self.data/'videos.json')
        library.add(VID,'Test video')
        state=app.DataState();state.video_id=VID
        with patch.object(app,'USER_DATA_DIR',self.data):
            server=ThreadingHTTPServer(('127.0.0.1',0),app.handler_factory(state,VID,library=library,auto_manager=self.manager))
            th=Thread(target=server.serve_forever,daemon=True);th.start()
            self.addCleanup(server.server_close)
            self.addCleanup(server.shutdown)
            base=f'http://127.0.0.1:{server.server_port}'
            with urlopen(base+'/api/auto/status') as req:
                data=json.load(req)
            self.assertTrue(data['draft']['available'])
            self.assertTrue(data['would_overwrite'])  # De meegeleverde referentiegrammatica bestaat al
            self.target.write_text('OLD',encoding='utf-8')
            def request(overwrite):
                payload={'video_id':VID,'hash':data['draft']['hash'],'overwrite':overwrite}
                headers={'Content-Type':'application/json','Origin':base}
                return Request(base+'/api/auto/import',data=json.dumps(payload).encode(),headers=headers,method='POST')
            with self.assertRaises(HTTPError) as err:
                urlopen(request(False))
            self.assertEqual(err.exception.code,400)
            self.assertEqual(self.target.read_text(),'OLD')
            with urlopen(request(True)) as req:
                result=json.load(req)
            self.assertEqual(result['count'],len(self.fixture['segments']))
            self.assertEqual(len(state.get()['segments']),result['count'])
            with urlopen(base+'/api/auto/status') as req:
                updated=json.load(req)
            self.assertTrue(updated['would_overwrite'])
            with urlopen(base+'/api/auto/draft') as req:
                self.assertEqual(json.load(req)['source']['video_id'],VID)


if __name__=='__main__': unittest.main()
