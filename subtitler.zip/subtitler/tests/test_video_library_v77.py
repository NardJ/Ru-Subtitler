"""V7.7 library, import and restart regression tests (no YouTube access)."""
import copy
import json
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

import app
from video_library import VideoLibrary
from v7_annotations import validate_v7


class LibraryV77Test(unittest.TestCase):
    def test_library_survives_restart_and_no_duplicates(self):
        with tempfile.TemporaryDirectory() as tmp:
            location = Path(tmp)/"videos.json"
            library = VideoLibrary(location)
            library.add('https://www.youtube.com/watch?v=abcdefghijk', 'Test video')
            library.add('abcdefghijk', 'Nieuwe titel')
            library.add('https://youtu.be/lmnopqrstuv', 'Tweede')
            self.assertEqual(len(library.videos), 2)
            reloaded = VideoLibrary(location)
            self.assertEqual(reloaded.selected, 'lmnopqrstuv')
            self.assertEqual(reloaded.videos[0]['title'], 'Nieuwe titel')
            reloaded.choose('abcdefghijk')
            self.assertEqual(VideoLibrary(location).selected, 'abcdefghijk')
            with self.assertRaises(ValueError):
                reloaded.add('https://example.com/watch?v=abcdefghijk')

    def test_import_persists_only_for_selected_video_and_validation(self):
        with tempfile.TemporaryDirectory() as tmp:
            library = VideoLibrary(Path(tmp)/'videos.json')
            library.add('abcdefghijk','Test video')
            state = app.DataState()
            state.video_id = 'abcdefghijk'
            root = json.loads((app.CACHE_DIR/'grammar_v7/sF20z8jY1yU.json').read_text(encoding='utf-8'))
            root['source']['video_id'] = 'abcdefghijk'
            with patch.object(app, 'USER_DATA_DIR', Path(tmp)), patch.object(app, 'fetch_subtitles', side_effect=AssertionError('Youtube may not be scraped')):
                server = ThreadingHTTPServer(('127.0.0.1',0), app.handler_factory(state, state.video_id, library=library, provider='off'))
                worker = threading.Thread(target=server.serve_forever,daemon=True)
                worker.start()
                base = f'http://127.0.0.1:{server.server_port}'
                def post(path, obj):
                    req = urllib.request.Request(base+path, method='POST',
                          headers={'Content-Type':'application/json'},
                          data=json.dumps(obj, ensure_ascii=False).encode('utf-8'))
                    with urllib.request.urlopen(req) as res:
                        return json.load(res)
                try:
                    with urllib.request.urlopen(base+'/api/videos') as response:
                        listing=json.load(response)
                    self.assertEqual(listing['selected'],'abcdefghijk')
                    self.assertFalse(listing['videos'][0]['has_grammar'])
                    bad = copy.deepcopy(root)
                    bad['source']['video_id']='lmnopqrstuv'
                    with self.assertRaises(urllib.error.HTTPError) as cm:
                        post('/api/import-grammar',{'grammar':bad})
                    self.assertEqual(cm.exception.code,400)
                    success = post('/api/import-grammar', {'grammar':root})
                    self.assertEqual(success['count'],28)
                    imported_path=Path(tmp)/'grammar_v7/abcdefghijk.json'
                    self.assertTrue(imported_path.is_file())
                    self.assertEqual(json.loads(imported_path.read_text())['source']['video_id'],'abcdefghijk')
                    with urllib.request.urlopen(base+'/api/data') as response:
                        data=json.load(response)
                    self.assertEqual(len(data['segments']),28)
                    broken=copy.deepcopy(root)
                    broken['segments'][0]['nl']=['broken']
                    with self.assertRaises(urllib.error.HTTPError):
                        post('/api/import-grammar',{'grammar':broken})
                    self.assertEqual(json.loads(imported_path.read_text())['segments'][0]['nl'][0], 'Grootmoeder')
                    listing=json.loads(urllib.request.urlopen(base+'/api/videos').read())
                    self.assertTrue(listing['videos'][0]['has_grammar'])
                    selected=post('/api/videos',{'action':'add','url':'https://youtu.be/lmnopqrstuv','title':'Tweede video'})
                    self.assertEqual(selected['id'],'lmnopqrstuv')
                    self.assertEqual(state.video_id,'lmnopqrstuv')
                    time.sleep(.05)
                    self.assertIn('importeer ChatGPT',state.get()['status'])
                    post('/api/videos', {'action':'select','id':'abcdefghijk'})
                    for _ in range(30):
                        if len(state.get().get('segments',[]))==28:break
                        time.sleep(.01)
                    self.assertEqual(len(state.get()['segments']),28)
                    other_state = app.DataState()
                    app.process_video('abcdefghijk',other_state,model='any',provider='off',allow_fetch=False)
                    self.assertEqual(len(other_state.get()['segments']),28)
                    self.assertEqual(VideoLibrary(Path(tmp)/'videos.json').selected, 'abcdefghijk')
                finally:
                    server.shutdown()
                    server.server_close()
                    worker.join(timeout=2)

    def test_markup_for_library_and_previous_sentence(self):
        html=(app.HERE/'player.html').read_text()
        js=(app.HERE/'overlay.js').read_text()
        for text in ['library-select','save-video-btn','grammar-file','/api/import-grammar','/api/videos']:
            self.assertIn(text,html)
        for text in ['skipPreviousSentence','previousSentenceIndex',"navigation('Vorige zin'"]:
            self.assertIn(text,js)

if __name__=='__main__': unittest.main()
