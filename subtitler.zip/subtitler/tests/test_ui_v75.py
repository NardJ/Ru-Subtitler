"""Smoke tests for the one-status, no-gap layout and background playback toggle."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class UIv75Test(unittest.TestCase):
    def test_duplicate_status_bar_removed(self):
        markup = (ROOT / 'player.html').read_text(encoding='utf-8')
        self.assertNotIn('id="analysis-status"', markup)
        self.assertNotIn('class="import-slot"', markup)
        self.assertIn('id="import-panel"',markup)
        self.assertIn('id="help-panel"',markup)
        self.assertIn('window.__roTogglePlayback', markup)

    def test_clicking_background_toggles_video_but_word_click_opens_detail(self):
        overlay = (ROOT / 'overlay.js').read_text(encoding='utf-8')
        self.assertIn("viewport.addEventListener('click'", overlay)
        self.assertIn("event.target.closest?.('button.ru')", overlay)
        self.assertIn('event.stopPropagation();showWordDetail(i);', overlay)
        self.assertIn('window.__roTogglePlayback()', overlay)

    def test_demo_toggles_playback_too(self):
        demo = (ROOT / 'demo_v7.html').read_text(encoding='utf-8')
        self.assertIn('window.__roTogglePlayback=()=>{playing=!playing;update();return true;};', demo)

if __name__ == '__main__':
    unittest.main()
