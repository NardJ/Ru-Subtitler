"""Offline regression tests for version 5, no Ollama installation required."""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
import unittest
from unittest.mock import patch
import urllib.request

from linguistic import annotate_batch_ollama, select_provider, model_is_installed
from transcript import to_segments, russian_tokens


class TestTranscriptCleaning(unittest.TestCase):
    def test_invisible_breaks_inside_words_are_not_word_boundaries(self):
        self.assertEqual(russian_tokens("Ба\u200bбушка гото\u200bвит бутербро\u200bд"),
                         ["Бабушка", "готовит", "бутерброд"])
        segments = to_segments([{"text":"Бабушка гото\u200bвит бутербро\u200bд.",
                                  "start":28.0, "duration":2.0}])
        self.assertEqual(segments[0]["tokens"], ["Бабушка", "готовит", "бутерброд"])


class TestModelSelection(unittest.TestCase):
    def test_ollama_missing_shows_helpful_message(self):
        with patch('linguistic.available_ollama_models', return_value=[]):
            backend, note = select_provider('auto', api_key='')
        self.assertEqual(backend,'off')
        self.assertIn('ollama pull', note)

    def test_ollama_first_when_local_available(self):
        with patch('linguistic.available_ollama_models', return_value=['qwen2.5:7b']):
            backend, note = select_provider('auto', api_key='some-API-key')
        self.assertEqual(backend,'ollama')
        self.assertIn('loka', note.lower())

    def test_openai_key_if_local_missing(self):
        with patch('linguistic.available_ollama_models', return_value=[]):
            backend, note = select_provider('auto', api_key='example')
        self.assertEqual(backend, 'openai')

    def test_ollama_suffix_latest(self):
        self.assertTrue(model_is_installed('foo', ['foo:latest']))

    def test_ollama_json_response_integration(self):
        # The HTTP mock intercepts requests locally: Ollama itself is not required.
        original_urlopen=urllib.request.urlopen
        class FakeResponse:
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def read(self):
                content={"sentences":[{"id":0, "nl":["in","winkel"],
                    "endings":[{"i":1,"suffix":"е"}],
                    "arrows":[{"from":0,"to":1,"label":"P","side":"top"}],
                    "tags":[{"i":1,"label":"P"}]}]}
                return json.dumps({"response":json.dumps(content,ensure_ascii=False)},ensure_ascii=False).encode()
        def fake_urlopen(req, timeout=0):
            self.assertEqual(req.full_url, 'http://127.0.0.1:11434/api/generate')
            body=json.loads(req.data)
            self.assertFalse(body['stream'])
            self.assertEqual(body['format'],'json')
            self.assertEqual(body['prompt'].split('\n')[-1][-2:], ']}')
            return FakeResponse()
        s={"id":0,"text":"в магазине", "start":4.0,"end":6.0,"tokens":["в","магазине"]}
        with patch('linguistic.urllib.request.urlopen', side_effect=fake_urlopen):
            result=annotate_batch_ollama([s])
        self.assertEqual(result[0]['nl'], ['in','winkel'])
        self.assertEqual(result[0]['arrows'][0]['label'], 'P')
        self.assertFalse(result[0]['pending'])


if __name__=='__main__':unittest.main()
