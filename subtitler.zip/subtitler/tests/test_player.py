import json
from pathlib import Path
import tempfile
import threading
import unittest
import urllib.request
import urllib.error

from app import DataState, handler_factory
from captions import read_caption_file, read_caption_text, read_pasted_transcript, seconds
from transcript import extract_video_id, to_segments
from linguistic import sanitize_annotation
from http.server import ThreadingHTTPServer


class TestTranscript(unittest.TestCase):
    def test_youtube_transcript_copy_with_separate_timestamps(self):
        lines = "Beschrijving\n0:02\nЖила-была бабушка.\n0:06\nУ неё был кот."
        cues=read_pasted_transcript(lines)
        self.assertEqual(len(cues),2)
        self.assertEqual(cues[0]["duration"],4)
        self.assertEqual(cues[1]["start"],6)
        self.assertIn("бабушка", cues[0]["text"])

    def test_youtube_transcript_copy_with_inline_timestamps(self):
        cues=read_pasted_transcript("0:00 Привет!\n0:03 Как дела?\n1:02:05 Поздно.")
        self.assertEqual(len(cues),3)
        self.assertEqual(cues[0]["start"],0)
        self.assertEqual(cues[-1]["start"],3725)
        self.assertEqual(cues[1]["duration"],10)

    def test_plain_transcript_without_timestamps_rejected(self):
        with self.assertRaisesRegex(ValueError, "tijdstempels"):
            read_pasted_transcript("Мама дала младшему брату книгу.")

    def test_read_text_srt(self):
        subs=read_caption_text("1\n00:00:02,000 --> 00:00:04,000\nПривет!\n", ".srt")
        self.assertEqual(subs[0]["start"],2)

    def test_id(self):
        self.assertEqual(extract_video_id("https://www.youtube.com/watch?v=abcdefghijk"), "abcdefghijk")
        self.assertEqual(extract_video_id("https://youtu.be/abcdefghijk"), "abcdefghijk")
        with self.assertRaises(ValueError):
            extract_video_id("https://example.org/watch?v=abcdefghijk")

    def test_read_srt(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d)/"captions.srt"
            f.write_text("1\n00:00:01,500 --> 00:00:02,750\nМама дала книгу.\n\n"
                         "2\n00:00:03,000 --> 00:00:05,000\nВ магазине.\n", encoding="utf8")
            snippets = read_caption_file(str(f))
            self.assertEqual(len(snippets), 2)
            self.assertAlmostEqual(snippets[0]["start"], 1.5)
            self.assertAlmostEqual(snippets[0]["duration"], 1.25)
            self.assertEqual(to_segments(snippets)[1]["tokens"], ["В", "магазине"])

    def test_read_vtt(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d)/"captions.vtt"
            f.write_text("WEBVTT\n\n"
                         "00:02.200 --> 00:04.500 position:50%\n<b>Привет!</b>\n", encoding="utf8")
            result = read_caption_file(str(f))
            self.assertEqual(result[0]["text"], "Привет!")
            self.assertAlmostEqual(result[0]["start"], 2.2)

    def test_read_json(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d)/"captions.json"
            f.write_text(json.dumps([{"start": 1.0, "duration": 2.5,
                                      "text": "Мама"}]), encoding="utf8")
            result = read_caption_file(str(f))
            self.assertEqual(result[0]["duration"], 2.5)

    def test_seconds(self):
        self.assertAlmostEqual(seconds("01:02:03,045"), 3723.045)


class TestAnnotatedData(unittest.TestCase):
    def test_arrow_to_changed_suffix(self):
        source={"id":0,"text":"в магазине","tokens":["в","магазине"],"start":0,"end":2}
        result=sanitize_annotation(source, {
            "nl":["in","winkel"],"endings":[{"i":1,"suffix":"е"}],
            "arrows":[{"from":0,"to":1,"label":"P"}],
            "tags":[{"i":1,"label":"P"}]
        })
        self.assertEqual(result["arrows"][0]["label"],"P")
        self.assertEqual(result["endings"][0]["suffix"],"е")


class TestHTTPServer(unittest.TestCase):
    def test_player_and_data_without_internet(self):
        state=DataState()
        state.video_id="abcdefghijk"
        state.update(segments=[{"start":0,"end":5,"tokens":["Мама"]}], status="geladen")
        server=ThreadingHTTPServer(("127.0.0.1",0),handler_factory(state,state.video_id))
        worker=threading.Thread(target=server.serve_forever,daemon=True)
        worker.start()
        try:
            base=f"http://127.0.0.1:{server.server_port}"
            with urllib.request.urlopen(base+"/") as r:
                html=r.read().decode("utf8")
                self.assertIn("YT.Player",html)
                self.assertIn("abcdefghijk",html)
                self.assertNotIn("playwright",html.lower().replace('geen playwright',''))
            with urllib.request.urlopen(base+"/api/data?version=0") as r:
                info=json.load(r)
                self.assertEqual(info["video_id"],"abcdefghijk")
                self.assertEqual(len(info["segments"]),1)
            with urllib.request.urlopen(base+"/api/data?version="+str(info["version"])) as r:
                diff=json.load(r)
                self.assertNotIn("segments",diff)
            with urllib.request.urlopen(base+"/overlay.js") as r:
                self.assertIn(b"drawArrows",r.read())
            body = json.dumps({"format":"paste", "text":"0:02 Мама дала книгу.\n0:06 В магазине."}).encode("utf8")
            request = urllib.request.Request(base+"/api/import",data=body,
                 headers={"Content-Type":"application/json"},method="POST")
            with urllib.request.urlopen(request) as r:
                ok=json.load(r)
                self.assertTrue(ok["ok"])
                self.assertEqual(ok["count"],2)
            for _ in range(20):
                import time
                time.sleep(.03)
                with urllib.request.urlopen(base+"/api/data") as r:
                    new=json.load(r)
                if new["segments"]:
                    break
            self.assertEqual(new["segments"][0]["tokens"], ["Мама","дала","книгу"])
            self.assertEqual(new["segments"][0]["start"],2.0)
            self.assertIn("import",html)
            bad = urllib.request.Request(base+"/api/import",data=b'{"format":"paste","text":"hello"}',
                 headers={"Content-Type":"application/json"},method="POST")
            with self.assertRaises(urllib.error.HTTPError) as context:
                urllib.request.urlopen(bad)
            self.assertEqual(context.exception.code,400)
        finally:
            server.shutdown()
            server.server_close()
            worker.join(timeout=2)


if __name__ == "__main__":
    unittest.main()
