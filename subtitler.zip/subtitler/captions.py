"""Read user-supplied SRT, WebVTT or JSON captions; no YouTube extraction required."""
from __future__ import annotations

import html
import json
from pathlib import Path
import re

TIMECODE = re.compile(
    r"^(?:(?P<h>\d+):)?(?P<m>\d{1,2}):(?P<s>\d{2})[,.](?P<ms>\d{1,3})$"
)
ARROW = re.compile(r"\s+-->\s+")


def seconds(code: str) -> float:
    m = TIMECODE.fullmatch(code.strip())
    if not m:
        raise ValueError(f"Ongeldige tijdcode: {code}")
    return int(m.group("h") or 0) * 3600 + int(m.group("m")) * 60 + int(m.group("s")) + int(m.group("ms").ljust(3, "0")) / 1000


def read_caption_text(body: str, suffix: str) -> list[dict]:
    """Parse browser-supplied SRT/VTT/JSON as text (no uploaded file written to disk)."""
    if suffix.lower() == ".json":
        data = json.loads(body.lstrip("\ufeff"))
        if isinstance(data, dict) and "segments" in data:
            data = data["segments"]
        if not isinstance(data, list):
            raise ValueError("JSON moet een lijst met start, duration en text bevatten")
        result = []
        for item in data:
            start = float(item["start"])
            duration = float(item.get("duration", float(item.get("end", start+.1))-start))
            if duration > 0 and str(item.get("text","")).strip():
                result.append({"start": start, "duration": duration, "text": str(item["text"])})
        return result

    if suffix.lower() not in {".srt", ".vtt"}:
        raise ValueError("Gebruik .srt, .vtt of .json")
    body = body.lstrip("\ufeff").replace("\r\n", "\n")
    blocks = re.split(r"\n\s*\n", body)
    result = []
    for block in blocks:
        lines = [line.strip() for line in block.split("\n") if line.strip()]
        if not lines:
            continue
        index = next((i for i, line in enumerate(lines) if ARROW.search(line)), None)
        if index is None:
            continue
        bounds = ARROW.split(lines[index], maxsplit=1)
        if len(bounds) != 2:
            continue
        try:
            start = seconds(bounds[0])
            end = seconds(bounds[1].split()[0])  # VTT cue position metadata
        except ValueError:
            continue
        text = " ".join(lines[index+1:]).strip()
        text = re.sub(r"<[^>]+>", "", text)
        text = html.unescape(text)
        if text and end > start:
            result.append({"start": start, "duration": end-start, "text": text})
    if not result:
        raise ValueError("Geen geldige ondertitelregels met tijdcodes gevonden")
    return result


# Transcript panel copies may have the timestamp on a separate line, or at
# the beginning of the same line. With no timestamps we cannot synchronize.
PASTE_TIMESTAMP = re.compile(r"^\s*(?P<time>(?:\d{1,3}:)?\d{1,2}:\d{2}(?:[.,]\d{1,3})?)(?=\s|$)\s*(?P<text>.*)$")


def read_pasted_transcript(body: str) -> list[dict]:
    """Read timestamped text copied from YouTube's 'Show transcript' panel.

    Accepted patterns:
        0:05 Привет!
        0:10
        Как дела?
        1:02:05 ещё текст
    Ignores lines before the first timestamp. Rejects timestamp-free text.
    """
    cues: list[tuple[float, str]] = []
    current_start: float | None = None
    current_lines: list[str] = []

    def finish() -> None:
        if current_start is not None and current_lines:
            text = " ".join(current_lines).strip()
            if text:
                cues.append((current_start, text))

    for original_line in body.replace("\r\n", "\n").split("\n"):
        line = original_line.strip()
        if not line:
            continue
        match = PASTE_TIMESTAMP.match(line)
        if match:
            finish()
            code = match.group("time")
            chunks = code.replace(",", ".").split(":")
            if len(chunks) == 2:
                start = int(chunks[0]) * 60 + float(chunks[1])
            else:
                start = int(chunks[0]) * 3600 + int(chunks[1]) * 60 + float(chunks[2])
            current_start = start
            current_lines = [match.group("text")] if match.group("text") else []
        elif current_start is not None:
            current_lines.append(line)
    finish()
    if not cues:
        raise ValueError("Geen tijdstempels gevonden. Kopieer het YouTube-transcript mét tijdcodes (bijvoorbeeld 0:05).")
    result = []
    for i, (start, text) in enumerate(cues):
        next_start = cues[i+1][0] if i+1 < len(cues) else start + 4
        if next_start <= start:
            continue
        result.append({"start": round(start, 3), "duration": round(min(next_start-start, 10), 3), "text": text})
    if not result:
        raise ValueError("Geen bruikbare oplopende tijdstempels gevonden")
    return result


def read_caption_file(filename: str) -> list[dict]:
    file = Path(filename)
    return read_caption_text(file.read_text(encoding="utf-8-sig"), file.suffix)
